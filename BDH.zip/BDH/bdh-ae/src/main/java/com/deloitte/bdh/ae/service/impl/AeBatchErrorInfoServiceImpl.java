package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.deloitte.bdh.ae.dao.ae.AeBatchErrorInfoMapper;
import com.deloitte.bdh.ae.model.AeBatchErrorInfo;
import com.deloitte.bdh.ae.service.AeBatchErrorInfoService;
import com.deloitte.bdh.common.base.ServiceNoTransactionalImpl;
import com.deloitte.bdh.common.constant.DSConstant;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Service
@DS(DSConstant.AE_DB)
public class AeBatchErrorInfoServiceImpl extends
    ServiceNoTransactionalImpl<AeBatchErrorInfoMapper, AeBatchErrorInfo> implements
    AeBatchErrorInfoService {

  @Override
  public List<AeBatchErrorInfo> selectListByBatchId(String aeBatchId) {
    return baseMapper.selectListByBatchId(aeBatchId);
  }
}
