package com.deloitte.bdh.ae.dao.ae;

import com.deloitte.bdh.engine.runtime.entity.DataLine;
import java.math.BigDecimal;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AeDataMapper {

  /**
   * 加载数据
   *
   * @param sql
   * @return
   */
  List<DataLine> loadData(@Param("sql") String sql);

  /**
   * 插入目标数据
   *
   * @param sql
   */
  void insertData(@Param("sql") String sql);

  /**
   * 删除目标数据
   *
   * @param sql
   */
  void deleteData(@Param("sql") String sql);

  /**
   * 更新目标数据
   *
   * @param sql
   */
  void updateData(@Param("sql") String sql);

  /**
   * 统计数量
   *
   * @param sql
   * @return
   */
  BigDecimal countData(@Param("sql") String sql);
}