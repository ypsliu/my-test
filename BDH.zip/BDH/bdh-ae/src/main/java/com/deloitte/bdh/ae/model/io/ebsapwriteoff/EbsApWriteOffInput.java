package com.deloitte.bdh.ae.model.io.ebsapwriteoff;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

/**
 * @author Ashen
 * @date 21/04/2020
 */
@Data
public class EbsApWriteOffInput {

  @JSONField(name = "APPLY_PREPAY_Input")
  private APPLY_PREPAY_Input APPLY_PREPAY_Input;
}
