package com.deloitte.bdh.engine.config.entity;

import java.math.BigDecimal;
import java.util.List;
import lombok.Data;

/**
 * 日记账类型
 *
 * @author Ashen
 * @date 02/12/2019
 */
@Data
public class JournalRuleLine {

  private String ruleLineId;

  private String ruleId;

  private String type;

  private String sourceId;

  private String setId;

  private String constant;

  private BigDecimal priorityLevel;

  private List<JournalCondition> journalConditionList;
}
