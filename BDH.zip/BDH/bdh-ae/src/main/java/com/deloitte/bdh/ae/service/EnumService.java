package com.deloitte.bdh.ae.service;

import java.util.Map;

/**
 * @author Ashen
 * @date 04/02/2021
 */
public interface EnumService {

  String getSystemEnumValueShow(String enumTypeCode, String enumValue);

  Map<String, String> getSystemEnumValueMap(String enumTypeCode);
}
