package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.CuxGlCoaList;
import com.deloitte.bdh.common.base.Service;
import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface CuxGlCoaListService extends Service<CuxGlCoaList> {

  List<CuxGlCoaList> selectList(String ledgerId, List<CuxGlCoaList> coaValueList);
}
