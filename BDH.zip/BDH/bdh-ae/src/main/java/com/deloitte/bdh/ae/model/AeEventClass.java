package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "AeEventClass对象", description = "")
public class AeEventClass extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableId("EVENT_CLASS_ID")
  private String eventClassId;

  @TableField("APPLICATION_ID")
  private String applicationId;

  @TableField("CLASS_CODE")
  private String classCode;

  @TableField("CLASS_NAME")
  private String className;

  @TableField("ACTIVE_FLAG")
  private Integer activeFlag;

  @TableField("VERIFY_FLAG")
  private BigDecimal verifyFlag;

  @TableField("DESCRIPTION")
  private String description;

  @TableField("SOURCE_TABLE_ID")
  private String sourceTableId;

  @TableField("TARGET_TABLE_ID")
  private String targetTableId;


}
