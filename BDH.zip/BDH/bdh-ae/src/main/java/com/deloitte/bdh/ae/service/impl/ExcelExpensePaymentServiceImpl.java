package com.deloitte.bdh.ae.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.deloitte.bdh.ae.client.FeignClientService;
import com.deloitte.bdh.ae.client.vo.OrganizationClientVo;
import com.deloitte.bdh.ae.model.AeSourceBatch;
import com.deloitte.bdh.ae.model.SourceImportPaymentHead;
import com.deloitte.bdh.ae.model.SourceImportPaymentLine;
import com.deloitte.bdh.ae.model.bo.ExcelModelExpensePayment;
import com.deloitte.bdh.ae.model.vo.CompanyDataPermissionVo;
import com.deloitte.bdh.ae.properties.ApplicationCodeProperties;
import com.deloitte.bdh.ae.service.AeSourceBatchService;
import com.deloitte.bdh.ae.service.SourceImportPaymentHeadService;
import com.deloitte.bdh.ae.service.SourceImportPaymentLineService;
import com.deloitte.bdh.common.context.ThreadContextHolder;
import com.deloitte.bdh.common.exception.BizException;
import com.deloitte.bdh.common.util.StringUtil;
import com.deloitte.bdh.excel.context.ExcelModelServiceContext;
import com.deloitte.bdh.excel.model.ExcelData;
import com.deloitte.bdh.excel.service.AbstractExcelModelService;
import com.deloitte.bdh.excel.service.ExcelModelService;
import com.deloitte.bdh.excel.service.ExcelService;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

/**
 * @author Ashen
 * @date 26/11/2020
 */
@Component
public class ExcelExpensePaymentServiceImpl {

  @Autowired
  private ExcelService excelService;

  @Autowired
  private FeignClientService feignClientService;

  @Autowired
  private AeSourceBatchService aeSourceBatchService;

  @Autowired
  private ApplicationCodeProperties applicationCodeProperties;

  @Autowired
  private SourceImportPaymentHeadService sourceImportPaymentHeadService;

  @Autowired
  private SourceImportPaymentLineService sourceImportPaymentLineService;

  private final String TEMP_FIELD_ORGANIZATION_ID = "TEMP_FIELD_ORGANIZATION_ID";

  @Bean("AE_IMPORT_EXPENSE_PAYMENT" + ExcelModelServiceContext.SERVICE_SUFFIX)
  public ExcelModelService<ExcelModelExpensePayment> employeeModelService() {
    return new AbstractExcelModelService<ExcelModelExpensePayment>() {

      @Override
      public void verifyUploadData(ExcelData<ExcelModelExpensePayment> excelData) {
        List<CompanyDataPermissionVo> companyDataPermissionVoList = feignClientService
            .getUserDataPermissions();
        if (companyDataPermissionVoList.size() == 0) {
          throw new BizException("您没有授权公司信息，不能进行导入操作！");
        }
        Set<String> organizationIdSet = companyDataPermissionVoList.stream()
            .map(CompanyDataPermissionVo::getOrganizationId).collect(Collectors.toSet());

        for (int rowIndex = 0; rowIndex < excelData.getRows().size(); rowIndex++) {
          verifyUploadOneData(excelData, rowIndex, organizationIdSet);
        }
      }

      public void verifyUploadOneData(ExcelData<ExcelModelExpensePayment> excelData, int rowIndex,
          Set<String> organizationIdSet) {
        ExcelModelExpensePayment excelModelExpensePayment = excelData.getRows().get(rowIndex);
        String organizationId = null;
        try {
          OrganizationClientVo organizationClientVo = feignClientService
              .selectOrganizationByCode(excelModelExpensePayment.getOrganizationNumber());
          if (organizationClientVo == null) {
            excelService.addErrorMessage(excelData, rowIndex, "[{}]匹配公司失败",
                excelService.getTitleName(excelData, "organizationNumber"));
          }
          if (organizationClientVo != null) {
            if (!"2".equals(organizationClientVo.getOrganizationTypeEnumVal())) {
              excelService.addErrorMessage(excelData, rowIndex, "{}[{}]匹配公司失败",
                  excelService.getTitleName(excelData, "organizationNumber"),
                  excelModelExpensePayment.getOrganizationNumber());
            } else if (StringUtil.isNotEmpty(organizationId)
                && !organizationId.equals(organizationClientVo.getOrganizationId())) {
              excelService.addErrorMessage(excelData, rowIndex, "同一批次不能导入多个公司数据");
            } else if (!organizationIdSet.contains(organizationClientVo.getOrganizationId())) {
              excelService.addErrorMessage(excelData, rowIndex, "没有公司[{}]数据权限",
                  excelModelExpensePayment.getOrganizationNumber());
            }
            organizationId = organizationClientVo.getOrganizationId();
            excelData.getTempRows().get(rowIndex).put(TEMP_FIELD_ORGANIZATION_ID, organizationId);
          }
        } catch (BizException e) {
          excelService.addErrorMessage(excelData, rowIndex, e.getMessage());
        }
      }


      @Override
      public void saveUploadData(ExcelData<ExcelModelExpensePayment> excelData) {
        String sourceBatchId = aeSourceBatchService.getSequence();
        String organizationId = excelData.getTempRows().get(0).get(TEMP_FIELD_ORGANIZATION_ID);
        List<ExcelModelExpensePayment> list = excelData.getRows();
        for (int rowIndex = 0; list != null && rowIndex < list.size(); rowIndex++) {
          saveUploadOneData(excelData, rowIndex, sourceBatchId);
        }
        AeSourceBatch aeSourceBatch = new AeSourceBatch();
        aeSourceBatch.setAeBatchId(sourceBatchId);
        aeSourceBatch.setSourceBatchId(sourceBatchId);
        aeSourceBatch.setActiveFlag(1);
        aeSourceBatch.setApplicationCode(
            applicationCodeProperties.getApplicationCodeImportExpensePayment());
        aeSourceBatch.setTenantId(ThreadContextHolder.getTenantId());
        aeSourceBatch.setOrganizationId(organizationId);
        aeSourceBatch.setAeBatchCode(aeSourceBatchService.selectAeBatchCode());
        aeSourceBatchService.save(aeSourceBatch);
      }

      public void saveUploadOneData(ExcelData<ExcelModelExpensePayment> excelData, int rowIndex,
          String sourceBatchId) {
        try {
          ExcelModelExpensePayment excelModelExpensePayment = excelData.getRows().get(rowIndex);
          String sourceOrganizationId = excelData.getTempRows().get(rowIndex)
              .get(TEMP_FIELD_ORGANIZATION_ID);
          List<SourceImportPaymentHead> list = sourceImportPaymentHeadService
              .list(new LambdaQueryWrapper<SourceImportPaymentHead>()
                  .eq(SourceImportPaymentHead::getSourceBatchId, sourceBatchId)
                  .eq(SourceImportPaymentHead::getPaymentNumber,
                      excelModelExpensePayment.getPaymentNumber()));
          SourceImportPaymentHead sourceImportPaymentHead = null;
          if (list.size() == 1) {
            //保存头信息
            sourceImportPaymentHead = list.get(0);
          } else if (list.size() > 1) {
            throw new BizException("导入多个头数据,系统异常");
          } else {
            sourceImportPaymentHead = new SourceImportPaymentHead();
            BeanUtils.copyProperties(excelModelExpensePayment, sourceImportPaymentHead);
            sourceImportPaymentHead.setSourceHeadId(sourceImportPaymentHeadService.getSequence());
            sourceImportPaymentHead.setSourceBatchId(sourceBatchId);
            sourceImportPaymentHead.setOrganizationId(sourceOrganizationId);
            sourceImportPaymentHeadService.save(sourceImportPaymentHead);
          }
          //保存行信息
          SourceImportPaymentLine sourceImportPaymentLine = new SourceImportPaymentLine();
          BeanUtils.copyProperties(excelModelExpensePayment, sourceImportPaymentLine);
          sourceImportPaymentLine.setSourceBatchId(sourceBatchId);
          sourceImportPaymentLine.setSourceHeadId(sourceImportPaymentHead.getSourceHeadId());
          sourceImportPaymentLine.setSourceLineId(sourceImportPaymentLineService.getSequence());
          sourceImportPaymentLineService.save(sourceImportPaymentLine);
        } catch (BizException e) {
          excelService.addErrorMessage(excelData, rowIndex, e.getMessage());
        }
      }
    };
  }

}
