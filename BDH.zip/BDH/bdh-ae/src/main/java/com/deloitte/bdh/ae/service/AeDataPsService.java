package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.dto.PsDto;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.RetResult;

/**
 * @author Ashen
 * @date 06/03/2020
 */
public interface AeDataPsService {

  RetResult<PsDto> putData(RetRequest<PsDto> psDtoRetRequest);
}
