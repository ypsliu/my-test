package com.deloitte.bdh.common.constant;

/**
 * @author Ashen
 * @date 27/09/2020
 */
public class DlaConstant {

  // 流程状态：处理中
  public static final String PROCESS_ING = "ING";
  // 流程状态：完成
  public static final String PROCESS_OK = "OK";
  // 流程状态：取消
  public static final String PROCESS_CANCEL = "CANCEL";

  //性别 1:男性 0:女性
  public static final String GENDER_MAN = "1";
  public static final String GENDER_WOMAN = "0";

  // 流程节点状态：进行中
  public static final String PROCESS_NODE_ING = "ING";
  // 流程节点状态：已完成
  public static final String PROCESS_NODE_OK = "OK";
  // 流程节点状态：已跳过
  public static final String PROCESS_NODE_JUMP = "JUMP";


  //职业阶段HR状态:离职
  public static final String HR_STATUS_QUIT = "QUIT";
  //职业阶段HR状态：在职
  public static final String HR_STATUS_ON_JOB = "ON_THE_JOB";
  //职业阶段HR状态：保留劳动关系，退出工作岗位
  public static final String HR_STATUS_STAY = "STAY";

  //入职相关流程
  //借调人员入职
  public static final String PROCESS_CLASS_ENTRY_LOAN_EMPLOYEE = "ENTRY_LOAN_EMPLOYEE";
  //外籍人员本地雇佣
  public static final String PROCESS_CLASS_ENTRY_ABROAD_CHINA = "ENTRY_ABROAD_CHINA";
  //外包人员
  public static final String PROCESS_CLASS_ENTRY_OUTSOURCE_PERSON = "ENTRY_OUTSOURCE_PERSON";
  //劳务人员
  public static final String PROCESS_CLASS_ENTRY_LABOR_SERVICE = "ENTRY_LABOR_SERVICE";


  //在职相关流程
  //职业阶段小分类：专业技术培训
  public static final String PROCESS_CLASS_WORK_TRAIN_PROFESSIONAL = "WORK_TRAIN_PROFESSIONAL";
  //职业阶段小分类：职业病
  public static final String PROCESS_CLASS_WORK_OCC_DISEASE = "WORK_OCC_DISEASE";
  //职业阶段小分类：医疗期
  public static final String PROCESS_CLASS_WORK_TREATMENT = "WORK_TREATMENT";
  //职业阶段小分类：工伤
  public static final String PROCESS_CLASS_WORK_INJURY = "WORK_INJURY";
  //职业阶段小分类：三期
  public static final String PROCESS_CLASS_WORK_THREE_PREGNANT = "WORK_THREE_PREGNANT";
  //在职-续签
  public static final String PROCESS_CLASS_WORK_RENEWAL = "WORK_RENEWAL";
  //在职-员工借调
  public static final String PROCESS_CLASS_WORK_EMPLOYEE_LOAN = "WORK_EMPLOYEE_LOAN";
  //在职-岗位调整
  public static final String PROCESS_CLASS_WORK_JOB_ADJUST = "WORK_JOB_ADJUST";
  //在职-竞业限制
  public static final String PROCESS_CLASS_WORK_JOB_LIMIT = "WORK_JOB_LIMIT";
  //在职-纪律处分
  public static final String PROCESS_CLASS_WORK_LETTER_WARN = "WORK_LETTER_WARN";
  //在职-其他变动流程
  public static final String PROCESS_CLASS_WORK_OTHER_CHANGE = "WORK_OTHER_CHANGE";


  //离职相关流程
  //劳动合同到期不续签
  public static final String PROCESS_CLASS_DEPARTURE_RENEWAL = "DEPARTURE_RENEWAL";
  //离职流程-单方解除40-1
  public static final String PROCESS_CLASS_DEPARTURE_SINGLE_40_1 = "DEPARTURE_SINGLE_40_1";
  //离职流程-单方解除40-1
  public static final String PROCESS_CLASS_DEPARTURE_DISPATCH_BACK_40_1 = "DEPARTURE_DISPATCH_BACK_40_1";
  //离职流程-单方解除40-2
  public static final String PROCESS_CLASS_DEPARTURE_SINGLE_40_2 = "DEPARTURE_SINGLE_40_2";
  //离职流程-劳务派遣单方解除40-2
  public static final String PROCESS_CLASS_DEPARTURE_DISPATCH_BACK_40_2 = "DEPARTURE_DISPATCH_BACK_40_2";
  //经济性裁员（劳动合同法第41条）
  public static final String PROCESS_CLASS_DEPARTURE_SINGLE_41 = "DEPARTURE_SINGLE_41";
  //经济性裁员子流程（劳动合同法第41条）
  public static final String PROCESS_CLASS_DEPARTURE_CHILD_SINGLE_41 = "DEPARTURE_CHILD_SINGLE_41";
  //因用工单位的经济性裁员，退回劳务派遣人员（劳动合同法第41条）
  public static final String PROCESS_CLASS_DEPARTURE_DISPATCH_BACK_41 = "DEPARTURE_DISPATCH_BACK_41";
  //因用工单位的经济性裁员，退回劳务派遣人员子流程（劳动合同法第41条）
  public static final String PROCESS_CLASS_DEPARTURE_CHILD_DISPATCH_BACK_41 = "DEPARTURE_CHILD_DISPATCH_BACK_41";


  /**
   * 生产
   */
  public static final String DELIVERY = "DELIVERY";
  /**
   * 流产
   */
  public static final String ABORTION = "ABORTION";

  //员工类型
  //全日制员工
  public static final String EMPLOYEE_TYPE_FULL_TIME = "FULL_TIME_EMPLOYEES";
  //非全日制员工
  public static final String EMPLOYEE_TYPE_PART_TIME = "PART_TIME_EMPLOYEES";
  //实习生
  public static final String EMPLOYEE_TYPE_TRAINEE = "TRAINEE";
  //退休返聘
  public static final String EMPLOYEE_TYPE_REEMP_AFT_RE = "REEMP_AFT_RE";
  //劳务派遣
  public static final String EMPLOYEE_TYPE_LABOR_DISPATCH = "LABOR_DISPATCH";
  //跨国公司派遣
  public static final String EMPLOYEE_TYPE_MUL_COM_DIS = "MUL_COM_DIS";
  //借调人员
  public static final String EMPLOYEE_TYPE_LOAN_EMPLOYEE = "LOAN_EMPLOYEE";
  //外包人员
  public static final String EMPLOYEE_TYPE_OUTSOURCE_PERSON = "OUTSOURCE_PERSON";
  //劳务人员
  public static final String EMPLOYEE_TYPE_LABOR_SERVICE = "LABOR_SERVICE";

  //居留证类型 DLA_RESIDENCE_PERMIT_TYPE
  //普通
  public static final String FOREIGN_PERMIT_TYPE_ORDINARY = "ORDINARY";
  //永居
  public static final String FOREIGN_PERMIT_TYPE_PERM_RES = "PERM_RES";

  //证件类型
  //身份证
  public static final String CERTIFICATE_TYPE_ID = "ID";
  //护照
  public static final String CERTIFICATE_TYPE_PASSPORT = "PASSPORT";
  //来往内地通行证
  public static final String CERTIFICATE_TYPE_PASS_H_A_T = "PASS_H_A_T";


  //检查类型
  //上岗前检查
  public static final String CHECK_TYPE_PRE_JOB_INSPECTION = "PRE_JOB_INSPECTION";
  //定期检查
  public static final String CHECK_TYPE_PERIODIC_INSPECTION = "PERIODIC_INSPECTION";
  //离职前检查
  public static final String CHECK_TYPE_PRE_RESIGNATION_INSPECTION = "PRE_RESIGNATION_INSPECTION";

  //派遣岗位类型 DLA_JOB_TYP
  //替代性
  public static final String LABOR_POSITION_TYPE_SUBSTITUTABILITY = "SUBSTITUTABILITY";
  //辅助性
  public static final String LABOR_POSITION_TYPE_AUXILIARY = "AUXILIARY";
  //临时性
  public static final String LABOR_POSITION_TYPE_TEMPORARY = "TEMPORARY";


  //人员类型
  //工会主席
  public static final String DLA_PSTION_TYP_TRA_UNI_CHA = "TRA_UNI_CHA";
  //工会副主席
  public static final String DLA_PSTION_TYP_VIC_CHA_TRA = "VIC_CHA_TRA";
  //工会委员
  public static final String DLA_PSTION_TYP_TRA_UNI_MEM = "TRA_UNI_MEM";

  //地址类型
  //公司地址
  public static final String DLA_ADDRESS_TYPE_COMPANY_ADDRESS = "COMPANY_ADDRESS";
  //联系地址
  public static final String DLA_ADDRESS_TYPE_CONTACT_ADDRESS = "CONTACT_ADDRESS";
  //户籍地址
  public static final String DLA_ADDRESS_TYPE_RESIDENCE_ADDRESS = "RESIDENCE_ADDRESS";
  //居住地址
  public static final String DLA_ADDRESS_TYPE_RESIDENTIAL_ADDRESS = "RESIDENTIAL_ADDRESS";
  //家庭地址
  public static final String DLA_ADDRESS_TYPE_FAMILY_ADDRESS = "FAMILY_ADDRESS";

  //伤残等级
  //一级
  public static final String DLA_DISABILITY_LEAVEL_GRADE_1 = "GRADE 1";
  //二级
  public static final String DLA_DISABILITY_LEAVEL_GRADE_2 = "GRADE 2";
  //三级
  public static final String DLA_DISABILITY_LEAVEL_GRADE_3 = "GRADE 3";
  //四级
  public static final String DLA_DISABILITY_LEAVEL_GRADE_4 = "GRADE 4";
  //五级
  public static final String DLA_DISABILITY_LEAVEL_GRADE_5 = "GRADE 5";
  //六级
  public static final String DLA_DISABILITY_LEAVEL_GRADE_6 = "GRADE 6";
  //七级
  public static final String DLA_DISABILITY_LEAVEL_GRADE_7 = "GRADE 7";
  //八级
  public static final String DLA_DISABILITY_LEAVEL_GRADE_8 = "GRADE 8";
  //九级
  public static final String DLA_DISABILITY_LEAVEL_GRADE_9 = "GRADE 9";
  //十级
  public static final String DLA_DISABILITY_LEAVEL_GRADE_10 = "GRADE 10";

  //流程类型

  /**
   * 在职
   */
  public static final String PROCESS_TYPE_CODE_WORK = "WORK";
  /**
   * 入职
   */
  public static final String PROCESS_TYPE_CODE_ENTRY = "ENTRY";
  /**
   * 离职
   */
  public static final String PROCESS_TYPE_CODE_DEPARTURE = "DEPARTURE";

  //流程类型

  /**
   * 入职
   */
  public static final String PROCESS_TYPE_ID_ENTRY = "1";
  /**
   * 在职
   */
  public static final String PROCESS_TYPE_ID_WORK = "2";
  /**
   * 离职
   */
  public static final String PROCESS_TYPE_ID_DEPARTURE = "3";

  /**
   * 文书类型CODE
   */
  //劳务派遣
  public static final String FILE_TYPE_CODE_AGREEMENT_DISPATCH = "FILE_AGREEMENT_DISPATCH";
  //竞业限制相关协议
  public static final String FILE_TYPE_CODE_AGREEMENT_COMPETITION_RESTRICTION = "FILE_AGREEMENT_COMPETITION_RESTRICTION";
  //劳动手册
  public static final String FILE_TYPE_CODE_HANDBOOK_LABOR = "FILE_HANDBOOK_LABOR";
  //借调合作协议
  public static final String FILE_TYPE_CODE_AGREEMENT_COOPERATION_SECONDMENT = "FILE_AGREEMENT_COOPERATION_SECONDMENT";
  //借调协议
  public static final String FILE_TYPE_CODE_AGREEMENT_SECONDMENT = "FILE_AGREEMENT_SECONDMENT";
  //借出企业营业执照
  public static final String FILE_TYPE_CODE_LICENSE_LEND = "FILE_LICENSE_LEND";
  //出生证明
  public static final String FILE_TYPE_CODE_CERTIFICATE_BIRTH = "FILE_CERTIFICATE_BIRTH";
  //计划生育服务证
  public static final String FILE_TYPE_CODE_CERTIFICATE_FAMILYPLANNING = "FILE_CERTIFICATE_FAMILYPLANNING";
  //警告函
  public static final String FILE_TYPE_CODE_LETTER_WARNING = "FILE_LETTER_WARNING";

  // 流程日期类型
  /**
   * 竞业限制支付日期
   */
  public static final String PROCESS_DATE_TYPE_JOB_LIMIT_PAY_DATE = "JOB_LIMIT_PAY_DATE";
  /**
   * 竞业限制履行证明日期
   */
  public static final String PROCESS_DATE_TYPE_JOB_LIMIT_PERFORM_PROOF_DATE = "JOB_LIMIT_PERFORM_PROOF_DATE";
  /**
   * 医疗期请假日期
   */
  public static final String PROCESS_DATE_TYPE_TREATMENT_LEAVE = "TREATMENT_LEAVE";
  /**
   * 工伤请假日期
   */
  public static final String PROCESS_DATE_TYPE_INJURY_LEAVE = "INJURY_LEAVE";
  /**
   * 职业病停工留薪
   */
  public static final String PROCESS_DATE_TYPE_OCC_TREATMENT = "OCC_TREATMENT";

  /**
   * 节点变量模块
   */
  // 是否展示存在试用期字段
  public static final String NODE_VARIABLES_PROBATION_SHOW = "probationShow";
  // 任然在试用期内
  public static final String NODE_VARIABLES_IN_PROBATION_FLAG = "inProbationFlag";
  // 伤残等级
  public static final String NODE_VARIABLES_DISEASE_DISABLE_LEVEL = "diseaseDisableLevel";
  // 是否展示字段：是否履行竞业限制标识
  public static final String NODE_VARIABLES_JOB_LIMIT_PERFORM_FLAG_SHOW = "jobLimitPerformFlagShow";
  // 节点默认的竞业限制到期日
  public static final String NODE_VARIABLES_DEFAULT_JOB_LIMIT_END_DATE = "defaultJobLimitEndDate";
  // 是否展示字段：是否履行竞业限制标识
  public static final String NODE_VARIABLES_TRANSFER_NEW_POSITION_ABLE_FLAG_SHOW = "transferNewPositionAbleFlagShow";
  // 是否展示字段：工会主席
  public static final String NODE_VARIABLES_TRADE_UNION_CHAIRMAN_FLAG_SHOW = "tradeUnionChairmanFlagShow";
  // 是否展示字段：工会委员
  public static final String NODE_VARIABLES_TRADE_UNION_COMMITTEE_FLAG_SHOW = "tradeUnionCommitteeFlagShow";
  // 是否展示字段：协商代表
  public static final String NODE_VARIABLES_EMPLOYEE_NEGOTIATE_REPRESENT_FLAG_SHOW = "employeeNegotiateRepresentFlagShow";
  // 是否展示字段：职工董
  public static final String NODE_VARIABLES_DIRECTOR_SUPERVISOR_FLAG_SHOW = "directorSupervisorFlagShow";
  // 是否展示字段：纪律处分数量
  public static final String NODE_VARIABLES_LETTER_WARN_COUNT = "letterWarnCount";

  // 无数据时，赋值给查询条件的值
  public static final String NO_DATA_ID = "-1111";


  /**
   * 国籍
   */
  //中国大陆
  public static final String CHINA_MAINLAND = "CHINA_MAINLAND";
  //香港、澳门、台湾
  public static final String HONG_KONG = "HONG_KONG";
  public static final String MACAO_CHINA = "MACAO_CHINA";
  public static final String TAIWAN_CHINA = "TAIWAN_CHINA";
  //外籍
  public static final String NATIONALITY_FOREIGN = "FOREIGN_NATIONALITY";

}
