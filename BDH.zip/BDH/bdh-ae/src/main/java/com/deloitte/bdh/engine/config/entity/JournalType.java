package com.deloitte.bdh.engine.config.entity;

import java.util.List;
import lombok.Data;

/**
 * 日记账类型
 *
 * @author Ashen
 * @date 02/12/2019
 */
@Data
public class JournalType {

  private String journalTypeId;

  private String typeCode;

  private String typeName;

  private String sideCode;

  private Integer switchSideFlag;

  private String mergeLine;

  private List<JournalCondition> journalConditionList;

  private List<JournalTypeAttribute> journalTypeAttributeList;
}
