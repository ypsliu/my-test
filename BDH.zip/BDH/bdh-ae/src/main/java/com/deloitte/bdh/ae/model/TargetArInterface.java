package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "TargetArInterface对象", description = "")
public class TargetArInterface extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableField("ORG_NAME")
  private String orgName;

  @TableField("SOURCE_NAME")
  private String sourceName;

  @TableField("CLASS_MEANING")
  private String classMeaning;

  @TableField("TRX_NUMBER")
  private String trxNumber;

  @TableField("TRX_TYPE_NAME")
  private String trxTypeName;

  @TableField("TRX_DATE")
  private LocalDate trxDate;

  @TableField("ACCOUNTING_DATE")
  private LocalDate accountingDate;

  @TableField("CURRENCY_CODE")
  private String currencyCode;

  @TableField("RATE_DATE")
  private LocalDate rateDate;

  @TableField("RATE_TYPE")
  private String rateType;

  @TableField("RATE_RATE")
  private BigDecimal rateRate;

  @TableField("CUSTOMER_NUMBER")
  private String customerNumber;

  @TableField("CUSTOMER_NAME")
  private String customerName;

  @TableField("ADDRESS_NAME")
  private String addressName;

  @TableField("ADDRESS_LINE1")
  private String addressLine1;

  @TableField("TERM_NAME")
  private String termName;

  @TableField("DESCRIPTION")
  private String description;

  @TableField("EN_COMMENTS")
  private String enComments;

  @TableField("VAT_TYPE")
  private String vatType;

  @TableField("LINE_NUMBER")
  private String lineNumber;

  @TableField("MEMO_LINE")
  private String memoLine;

  @TableField("QUANTITY")
  private BigDecimal quantity;

  @TableField("PRICE")
  private BigDecimal price;

  @TableField("AMOUNT")
  private BigDecimal amount;

  @TableField("TAX_CODE")
  private String taxCode;

  @TableField("SALE_NUM")
  private BigDecimal saleNum;

  @TableField("SEGMENT1")
  private String segment1;

  @TableField("SEGMENT2")
  private String segment2;

  @TableField("SEGMENT3")
  private String segment3;

  @TableField("SEGMENT4")
  private String segment4;

  @TableField("SEGMENT5")
  private String segment5;

  @TableField("SEGMENT6")
  private String segment6;

  @TableField("SEGMENT7")
  private String segment7;

  @TableField("SEGMENT8")
  private String segment8;

  @TableField("SEGMENT9")
  private String segment9;

  @TableField("SEGMENT10")
  private String segment10;

  @TableField("SEGMENT11")
  private String segment11;

  @TableField("SEGMENT12")
  private String segment12;

  @TableField("SEGMENT13")
  private String segment13;

  @TableField("SEGMENT14")
  private String segment14;

  @TableField("SEGMENT15")
  private String segment15;

  @TableField("SEGMENT16")
  private String segment16;

  @TableField("SEGMENT17")
  private String segment17;

  @TableField("SEGMENT18")
  private String segment18;

  @TableField("SEGMENT19")
  private String segment19;

  @TableField("SEGMENT20")
  private String segment20;

  @TableField("SEGMENT21")
  private String segment21;

  @TableField("SEGMENT22")
  private String segment22;

  @TableField("SEGMENT23")
  private String segment23;

  @TableField("SEGMENT24")
  private String segment24;

  @TableField("SEGMENT25")
  private String segment25;

  @TableField("SEGMENT26")
  private String segment26;

  @TableField("SEGMENT27")
  private String segment27;

  @TableField("SEGMENT28")
  private String segment28;

  @TableField("SEGMENT29")
  private String segment29;

  @TableField("SEGMENT30")
  private String segment30;

  @TableField("REFERENCE1")
  private String reference1;

  @TableField("REFERENCE2")
  private String reference2;

  @TableField("REFERENCE3")
  private String reference3;

  @TableField("REFERENCE4")
  private String reference4;

  @TableField("REFERENCE5")
  private String reference5;

  @TableField("REFERENCE6")
  private String reference6;

  @TableField("REFERENCE7")
  private String reference7;

  @TableField("REFERENCE8")
  private String reference8;

  @TableField("REFERENCE9")
  private String reference9;

  @TableField("REFERENCE10")
  private String reference10;

  @TableField("REFERENCE11")
  private String reference11;

  @TableField("REFERENCE12")
  private String reference12;

  @TableField("REFERENCE13")
  private String reference13;

  @TableField("REFERENCE14")
  private String reference14;

  @TableField("REFERENCE15")
  private String reference15;

  @TableField("SET_OF_BOOKS_ID")
  private String setOfBooksId;

  @TableField("AE_HEAD_DESCRIPTION")
  private String aeHeadDescription;

  @TableField("AE_LINE_DESCRIPTION")
  private String aeLineDescription;

  @TableField("AE_SOURCE_SYSTEM")
  private String aeSourceSystem;

  @TableField("AE_STATUS")
  private String aeStatus;

  @TableField("AE_MERGE_FLAG")
  private String aeMergeFlag;

  @TableField("AE_SIDE_CODE")
  private String aeSideCode;

  @TableField("SOURCE_BATCH_ID")
  private String sourceBatchId;

  @TableField("SOURCE_HEAD_ID")
  private String sourceHeadId;

  @TableField("SOURCE_LINE_ID")
  private String sourceLineId;

  @TableField("AE_ROW_ID")
  private String aeRowId;

  @TableField("AE_MERGE_ROW_ID")
  private String aeMergeRowId;

  @TableField("AE_LINE_NUM")
  private BigDecimal aeLineNum;

  @TableField("AE_CREATE_TIME")
  private LocalDate aeCreateTime;

  @TableField("AE_BATCH_ID")
  private String aeBatchId;

  @TableField("AE_EBS_HEAD_ID")
  private String aeEbsHeadId;

  @TableField("AE_EBS_LINE_ORDER")
  private String aeEbsLineOrder;

  @TableField("AE_EBS_NUMBER")
  private String aeEbsNumber;

  @TableField("AE_REVERSE_STATUS")
  private String aeReverseStatus;

  @TableField("AE_JOURNAL_TYPE_ID")
  private String aeJournalTypeId;

  @TableField("AE_SEGMENT_DESCRIPTION_CH")
  private String aeSegmentDescriptionCh;

  @TableField("AE_SEGMENT_DESCRIPTION_EN")
  private String aeSegmentDescriptionEn;

  @TableField("LINE_TYPE")
  private String lineType;

  @TableField("ITEM_NUMBER")
  private String itemNumber;


}
