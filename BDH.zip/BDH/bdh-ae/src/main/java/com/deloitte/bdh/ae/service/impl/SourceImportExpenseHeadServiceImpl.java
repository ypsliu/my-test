package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.ae.model.SourceImportExpenseHead;
import com.deloitte.bdh.ae.dao.ae.SourceImportExpenseHeadMapper;
import com.deloitte.bdh.ae.service.SourceImportExpenseHeadService;
import com.deloitte.bdh.common.base.ServiceTransactionalImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 员工费用报销申请头 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2021-03-24
 */
@Service
@DS(DSConstant.AE_DB)
public class SourceImportExpenseHeadServiceImpl extends
    ServiceTransactionalImpl<SourceImportExpenseHeadMapper, SourceImportExpenseHead> implements
    SourceImportExpenseHeadService {

}
