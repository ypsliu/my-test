package com.deloitte.bdh.engine.cache;

/**
 * @author Ashen
 * @date 21/11/2019
 */
public interface Cache {

  void writeCache(String key, String value);

  void readCache(String key, String value);

  void removeCache(String applicationId);
}
