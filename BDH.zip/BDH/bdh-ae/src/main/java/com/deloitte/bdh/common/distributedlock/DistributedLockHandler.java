package com.deloitte.bdh.common.distributedlock;

import com.deloitte.bdh.common.redis.RedisClusterUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

/**
 * 分布式锁处理类
 *
 * @author dahpeng
 * @date 2019/05/14
 */
@Component
public class DistributedLockHandler {

  private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory
      .getLogger(DistributedLockHandler.class);
  /**
   * 单个业务持有锁的时间30s，防止死锁
   */
  private final static int LOCK_EXPIRE = 30;

  @Autowired
  private RedisClusterUtil redisClusterUtil;

  /**
   * 尝试获取全局锁
   *
   * @param lockName  锁的名称
   * @param lockValue 锁值
   * @return true 获取成功，false获取失败
   */
  public boolean tryLock(String lockName, String lockValue) {
    return getLock(lockName, lockValue, LOCK_EXPIRE);
  }


  /**
   * 尝试获取全局锁
   *
   * @param lockName       锁的名称
   * @param lockValue      锁值
   * @param lockExpireTime 锁的过期
   * @return true 获取成功，false获取失败
   */
  public boolean tryLock(String lockName, String lockValue, int lockExpireTime) {
    return getLock(lockName, lockValue, lockExpireTime);
  }

  /**
   * 操作redis获取全局锁
   *
   * @param lockName       锁的名称
   * @param lockValue      锁值
   * @param lockExpireTime 获取成功后锁的过期时间
   * @return true 获取成功，false获取失败
   */
  public boolean getLock(String lockName, String lockValue, int lockExpireTime) {
    try {
      if (StringUtils.isEmpty(lockName) || StringUtils.isEmpty(lockValue)) {
        return false;
      }
      if (redisClusterUtil.KEYS.exists(lockName)) {
        logger.error("lock is exist!！！");
        return false;
      } else {
        redisClusterUtil.STRINGS.setEx(lockName, lockExpireTime, lockValue);
        return true;
      }
    } catch (Exception e) {
      logger.error(e.getMessage());
      return false;
    }
  }

  /**
   * 释放锁
   */
  public void releaseLock(String lockName) {
    if (!StringUtils.isEmpty(lockName)) {
      redisClusterUtil.KEYS.del(lockName);
      logger.debug("完成操作,释放锁！");
    }
  }

}
