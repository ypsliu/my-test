package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "AeMappingSetValues对象", description = "")
public class AeMappingSetValues extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableId("SET_VALUE_ID")
  private String setValueId;

  @TableField("SET_ID")
  private String setId;

  @TableField("INPUT_VALUE1")
  private String inputValue1;

  @TableField("INPUT_VALUE2")
  private String inputValue2;

  @TableField("INPUT_VALUE3")
  private String inputValue3;

  @TableField("INPUT_VALUE4")
  private String inputValue4;

  @TableField("INPUT_VALUE5")
  private String inputValue5;

  @TableField("ACTIVE_FLAG")
  private Integer activeFlag;

  @TableField("DESCRIPTION")
  private String description;

  @TableField("OUTPUT_VALUE")
  private String outputValue;

  @TableField("OUTPUT_VALUE_DESCRIPTION")
  private String outputValueDescription;


}
