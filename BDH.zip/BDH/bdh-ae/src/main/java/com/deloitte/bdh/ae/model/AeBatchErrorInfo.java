package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "AeBatchErrorInfo对象", description = "")
public class AeBatchErrorInfo extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableField("AE_BATCH_ID")
  private String aeBatchId;

  @TableField("SOURCE_HEAD_ID")
  private String sourceHeadId;

  @TableField("SOURCE_LINE_ID")
  private String sourceLineId;

  @TableField("SOURCE_BATCH_ID")
  private String sourceBatchId;

  @TableField("MESSAGE")
  private String message;

  @TableField("DOCUMENT_HEAD_NUMBER")
  private String documentHeadNumber;

  @TableField("DOCUMENT_HEAD_TYPE")
  private String documentHeadType;

  @TableField("DOCUMENT_LINE_ORDER")
  private String documentLineOrder;

  @TableField("DESCRIPTION")
  private String description;

  @TableField("ACTIVE_FLAG")
  private Integer activeFlag;

  @TableField("TYPE")
  private String type;


}
