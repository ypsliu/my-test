package com.deloitte.bdh.ae.model.io.ebsar;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

/**
 * @author Ashen
 * @date 21/04/2020
 */
@Data
public class CREATE_TRXS_Input {

  @JSONField(name = "InputParameters")
  private com.deloitte.bdh.ae.model.io.ebsar.InputParameters InputParameters;
}
