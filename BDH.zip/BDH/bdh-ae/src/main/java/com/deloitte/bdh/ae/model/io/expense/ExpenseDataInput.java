package com.deloitte.bdh.ae.model.io.expense;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.Data;

/**
 * @author Ashen
 * @date 28/02/2020
 */

@Data
@ApiModel(description = "报销数据会计引擎接口入口参数")
public class ExpenseDataInput {

  @ApiModelProperty(value = "报销头")
  private List<ExpExpenseRequestHeadersInput> headerList;

  @ApiModelProperty(value = "报销行")
  private List<ExpExpenseCommonLinesInput> expenseLineList;

  @ApiModelProperty(value = "核销行")
  private List<ExpReceivableApplLinesInput> receivableLineList;

  @ApiModelProperty(value = "会计引擎：应用产品代码")
  private String applicationCode;

  @ApiModelProperty(value = "租户ID")
  private String tenantId;

  @ApiModelProperty(value = "公司ID")
  private String organizationId;
}
