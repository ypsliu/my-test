package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.io.segment.SourceInput;
import com.deloitte.bdh.ae.model.io.segment.SourceOutput;

/**
 * @author Ashen
 * @date 24/04/2020
 */
public interface AeSegmentService {

  /**
   * 获取目标段信息
   *
   * @param sourceInput
   * @return
   */
  SourceOutput getSegment(SourceInput sourceInput);
}
