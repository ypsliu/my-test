package com.deloitte.bdh.ae.model.io.ebsgl;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

/**
 * @author Ashen
 * @date 24/02/2021
 */
@Data
public class IMPORT_ACCOUNTING {

  @JSONField(name = "INPUTPARAMETERS")
  private InputParameters InputParameters;
}
