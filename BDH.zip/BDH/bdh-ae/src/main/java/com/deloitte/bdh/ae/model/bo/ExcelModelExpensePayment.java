package com.deloitte.bdh.ae.model.bo;

import com.deloitte.bdh.excel.annotation.ExcelColumn;
import com.deloitte.bdh.excel.annotation.ExcelModel;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.Data;

/**
 * @author Ashen
 * @date 25/11/2020
 */
@Data
@ExcelModel("AE_IMPORT_EXPENSE_PAYMENT")
public class ExcelModelExpensePayment {

  @ExcelColumn(title = "付款编号", order = 1, required = true)
  private String paymentNumber;
  @ExcelColumn(title = "公司编码", order = 2, required = true)
  private String organizationNumber;
  @ExcelColumn(title = "公司", order = 3, required = true)
  private String organizationName;

  @ExcelColumn(title = "付款类型", order = 4, required = false)
  private String paymentType;
  @ExcelColumn(title = "付款人", order = 5, required = false)
  private String paymentUserName;
  @ExcelColumn(title = "付款日期", order = 6, required = true,formats = {"yyyy/MM/dd","yyyy-MM-dd"})
  private LocalDate paymentDate;
  @ExcelColumn(title = "付款方式", order = 7, required = false)
  private String paymentMethod;
  @ExcelColumn(title = "付款银行", order = 8, required = true)
  private String paymentBank;
  @ExcelColumn(title = "币种", order = 9, required = true)
  private String currencyCode;
  @ExcelColumn(title = "汇率", order = 20, required = true)
  private BigDecimal currencyRate;
  @ExcelColumn(title = "付款总金额", order = 21, required = true)
  private BigDecimal totalAmount;

  @ExcelColumn(title = "申请单据编号", order = 22, required = false)
  private String documentNumber;
  @ExcelColumn(title = "申请人", order = 23, required = false)
  private String requestUserName;
  @ExcelColumn(title = "申请日期", order = 24, required = false,formats = {"yyyy/MM/dd","yyyy-MM-dd"})
  private LocalDate lineDate;
  @ExcelColumn(title = "付款申请金额", order = 25, required = false)
  private BigDecimal lineAmount;
  @ExcelColumn(title = "备注", order = 26, required = false)
  private String lineComments;
}
