package com.deloitte.bdh.common.util;

import com.deloitte.bdh.engine.DataException;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Ashen
 * @date 16/01/2020
 */
public class DataConvertUtil {

  public static Date convertDate(Object value) {
    if (value instanceof Date) {
      return (Date) value;
    }
    throw new DataException("转换数据异常：不能将【" + value + "】转换为日期！");
  }

  public static BigDecimal convertNumber(Object value) {
    if (value instanceof BigDecimal) {
      return (BigDecimal) value;
    }
    if (value instanceof String) {
      try {
        return new BigDecimal((String) value);
      } catch (Exception e) {
        e.printStackTrace();
        throw new DataException("转换数据异常：不能将【" + value + "】转换为数值！");
      }
    }
    throw new DataException("转换数据异常：不能将【" + value + "】转换为数值！");
  }

  public static String conventString(Object value) {
    if (value instanceof String) {
      return (String) value;
    }
    throw new DataException("转换数据异常：不能将【" + value + "】转换为字符串！");
  }

}
