package com.deloitte.bdh.ae.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotEmpty;
import lombok.Data;

/**
 * @author Ashen
 * @date 20/02/2020
 */
@Data
@ApiModel(description = "应用产品信息")
public class ApplicationDto {

  @ApiModelProperty(value = "应用产品CODE")
  @NotEmpty(message = "应用产品CODE不能为空")
  private String applicationCode;
}
