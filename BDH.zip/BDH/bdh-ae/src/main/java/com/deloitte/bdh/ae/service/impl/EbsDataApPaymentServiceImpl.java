package com.deloitte.bdh.ae.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.baomidou.dynamic.datasource.annotation.DS;
import com.deloitte.bdh.ae.model.TargetSourceBasicInfo;
import com.deloitte.bdh.ae.model.io.ebsap.EbsApResponse;
import com.deloitte.bdh.ae.model.io.ebsappayment.CREATE_PAYMENTS_Input;
import com.deloitte.bdh.ae.model.io.ebsappayment.EbsApPaymentInput;
import com.deloitte.bdh.ae.model.io.ebsappayment.EbsApPaymentResponseErrorDetail;
import com.deloitte.bdh.ae.model.io.ebsappayment.InputParameters;
import com.deloitte.bdh.ae.model.io.ebsappayment.P_PAYMENTS_TBL;
import com.deloitte.bdh.ae.model.io.ebsappayment.P_PAYMENTS_TBL_ITEM;
import com.deloitte.bdh.ae.service.AeSourceBatchService;
import com.deloitte.bdh.ae.service.EbsDataApPaymentService;
import com.deloitte.bdh.ae.service.TargetApPaymentInterfaceService;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.common.exception.BizException;
import com.deloitte.bdh.common.http.HttpClientUtil;
import com.deloitte.bdh.engine.runtime.ErrorMessageService;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Ashen
 * @date 09/05/2020
 */
@Service
@RefreshScope
@DS(DSConstant.AE_DB)
@Transactional(rollbackFor = Exception.class)
public class EbsDataApPaymentServiceImpl implements EbsDataApPaymentService {

  @Autowired
  private TargetApPaymentInterfaceService targetApPaymentInterfaceService;

  @Autowired
  private AeSourceBatchService aeSourceBatchService;

  @Autowired
  private ErrorMessageService errorMessageService;

  @Value("${ebs.ap.payment.host.url}")
  private String ebsApPaymentHostUrl;

  @Value("${ebs.auth}")
  private String ebsAuth;


  @Override
  public void putDataToEbsApPayment(String aeBatchId) {
    try {
      List<P_PAYMENTS_TBL_ITEM> itemList = targetApPaymentInterfaceService
          .queryPaymentsItem(aeBatchId);
      if (itemList.isEmpty()) {
        throw new BizException("支付信息不能为空！");
      }
      EbsApPaymentInput ebsApPaymentInput = new EbsApPaymentInput();
      CREATE_PAYMENTS_Input create_payments_input = new CREATE_PAYMENTS_Input();
      ebsApPaymentInput.setCREATE_PAYMENTS_Input(create_payments_input);
      InputParameters inputParameters = new InputParameters();
      create_payments_input.setInputParameters(inputParameters);
      P_PAYMENTS_TBL p_payments_tbl = new P_PAYMENTS_TBL();
      inputParameters.setP_PAYMENTS_TBL(p_payments_tbl);
      p_payments_tbl.setP_PAYMENTS_TBL_ITEM(itemList);
      Map<String, Object> header = new HashMap<>();
      byte[] authBytes = new byte[0];
      authBytes = ebsAuth.getBytes("UTF-8");
      String baseAuth = Base64.encodeBase64String(authBytes);
      header.put("Authorization", "Basic " + baseAuth);
      String payload = JSON.toJSONString(ebsApPaymentInput, SerializerFeature.WriteMapNullValue);
      CloseableHttpResponse response = HttpClientUtil
          .httpPostRequestByJsonAndReturnResponse(ebsApPaymentHostUrl, header, payload);
      if (null != response) {
        if (response.getStatusLine().getStatusCode() != 200) {
          throw new BizException("返回错误的接口状态");
        }
        HttpEntity entity = response.getEntity();
        if (entity != null) {
          String result = EntityUtils.toString(entity);
          response.close();
          EbsApResponse ebsApResponse = JSON.parseObject(result, EbsApResponse.class);
          if ("S".equals(ebsApResponse.getOutputParameters().getX_RETURN_STATUS())) {
            aeSourceBatchService
                .updateBatchEbsStatus(aeBatchId, "FINAL_ACCOUNT", "DOING",
                    "OK");
            return;
          } else {
            String data = ebsApResponse.getOutputParameters().getX_MSG_DATA();
            try {
              //如果能解析为数组
              List<EbsApPaymentResponseErrorDetail> list = JSON
                  .parseArray(data, EbsApPaymentResponseErrorDetail.class);
              Set<String> apGrpNumSet = new HashSet<>();
              list.forEach(ebsApPaymentResponseErrorDetail -> {
                apGrpNumSet.add(ebsApPaymentResponseErrorDetail.getAp_grp_num());
              });
              List<TargetSourceBasicInfo> sourceBasicInfoList = targetApPaymentInterfaceService
                  .selectByLineNumberSet(apGrpNumSet, aeBatchId);
              Map<String, EbsApPaymentResponseErrorDetail> errorDetailMap = list.stream().collect(
                  Collectors
                      .toMap(EbsApPaymentResponseErrorDetail::getAp_grp_num, Function.identity()));
              sourceBasicInfoList.forEach(targetSourceBasicInfo -> {
                EbsApPaymentResponseErrorDetail errorDetail = errorDetailMap
                    .get(targetSourceBasicInfo.getAeRowId());
                if (errorDetail == null && targetSourceBasicInfo.getAeRowId() == null) {
                  errorDetail = errorDetailMap.get("");
                }
                if (errorDetail == null) {
                  errorMessageService
                      .insertErrorMessage(aeBatchId, "调用EBS返回错误信息");
                } else {
                  errorMessageService
                      .insertErrorMessage(aeBatchId, targetSourceBasicInfo.getSourceBatchId(),
                          targetSourceBasicInfo.getSourceHeadId(),
                          targetSourceBasicInfo.getSourceLineId(),
                          errorDetail.getErr_msg());
                }
              });
            } catch (Exception e) {
              //不能解析为数据，则为错误信息
              throw new BizException(ebsApResponse.getOutputParameters().getX_MSG_DATA());
            }
          }
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
      throw new BizException("调用EBS接口异常：" + e.getMessage());
    }
    throw new BizException("调用EBS接口异常");
  }
}
