package com.deloitte.bdh.ae.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.math.BigDecimal;
import java.time.LocalDate;
import javax.validation.constraints.NotNull;
import lombok.Data;

/**
 * @author Ashen
 * @date 14/04/2020
 */
@Data
@ApiModel(description = "报表模板参数")
public class ReportRunDto {

  @ApiModelProperty(value = "应用产品")
  @NotNull(message = "应用产品不能为空")
  private BigDecimal applicationId;

  @ApiModelProperty(value = "报表Id")
  @NotNull(message = "报表不能为空")
  private String reportId;

  @ApiModelProperty(value = "公司")
  @NotNull(message = "公司不能为空")
  private String organizationId;

  @ApiModelProperty(value = "GL日期从")
  private LocalDate glDateFrom;

  @ApiModelProperty(value = "GL日期至")
  private LocalDate glDateTo;

  @ApiModelProperty(value = "批次号")
  private String aeBatchCode;

  @ApiModelProperty(value = "会计科目类型")
  private String entryType;
}
