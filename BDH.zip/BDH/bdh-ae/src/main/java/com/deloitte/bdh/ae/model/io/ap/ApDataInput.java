package com.deloitte.bdh.ae.model.io.ap;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.Data;

/**
 * @author Ashen
 * @date 20/04/2020
 */
@Data
@ApiModel(description = "AP数据-会计引擎接口入口参数")
public class ApDataInput {

  @ApiModelProperty(value = "AP头列表")
  private List<SourceApInvoiceHeadInput> headList;

  @ApiModelProperty(value = "AP行列表")
  private List<SourceApInvoiceLineInput> lineList;

  @ApiModelProperty(value = "会计引擎：应用产品代码")
  private String applicationCode;

  @ApiModelProperty(value = "租户ID")
  private String tenantId;

  @ApiModelProperty(value = "公司ID")
  private String organizationId;

}
