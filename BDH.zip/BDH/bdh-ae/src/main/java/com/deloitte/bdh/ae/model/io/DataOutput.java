package com.deloitte.bdh.ae.model.io;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Ashen
 * @date 28/02/2020
 */
@Data
@ApiModel(description = "会计引擎接口返回参数")
public class DataOutput {

  @ApiModelProperty(value = "返回状态")
  private String status;

  @ApiModelProperty(value = "返回信息")
  private String message;

  @ApiModelProperty(value = "批次信息")
  private String aeBatchId;
}
