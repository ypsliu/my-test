package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "AeSourceLoadTableField对象", description = "")
public class AeSourceLoadTableField extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableId("FIELD_ID")
  private String fieldId;

  @TableField("TABLE_ID")
  private String tableId;

  @TableField("STATUS")
  private Integer status;

  @TableField("FAIL_REASON")
  private String failReason;

  @TableField("DESCRIPTION")
  private String description;

  @TableField("ACTIVE_FLAG")
  private Integer activeFlag;

  @TableField("COLUMN_NAME")
  private String columnName;

  @TableField("DATA_TYPE")
  private String dataType;

  @TableField("DATA_LENGTH")
  private String dataLength;

  @TableField("NULLABLE")
  private String nullable;

  @TableField("COLUMN_ORDER")
  private BigDecimal columnOrder;


}
