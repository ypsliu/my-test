package com.deloitte.bdh.ae.model.io.preparepayment;

import com.deloitte.bdh.ae.model.SourcePreparePaymentLine;

/**
 * @author Ashen
 * @date 20/04/2020
 */
public class SourcePreparePaymentLineInput extends SourcePreparePaymentLine {

}
