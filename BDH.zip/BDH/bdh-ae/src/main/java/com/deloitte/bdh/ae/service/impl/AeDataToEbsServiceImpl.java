package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.deloitte.bdh.ae.properties.ApplicationCodeProperties;
import com.deloitte.bdh.ae.service.AeDataToEbsService;
import com.deloitte.bdh.ae.service.EbsDataApPaymentService;
import com.deloitte.bdh.ae.service.EbsDataApService;
import com.deloitte.bdh.ae.service.EbsDataApWriteOffService;
import com.deloitte.bdh.ae.service.EbsDataArService;
import com.deloitte.bdh.ae.service.EbsDataGlService;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.common.exception.BizException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Ashen
 * @date 09/03/2020
 */
@Service
@DS(DSConstant.AE_DB)
@Transactional(rollbackFor = Exception.class)
public class AeDataToEbsServiceImpl implements AeDataToEbsService {

  @Autowired
  private EbsDataGlService ebsDataGlService;

  @Autowired
  private EbsDataApService ebsDataApService;

  @Autowired
  private EbsDataApWriteOffService ebsDataApWriteOffService;

  @Autowired
  private EbsDataArService ebsDataArService;

  @Autowired
  private EbsDataApPaymentService ebsDataApPaymentService;

  @Autowired
  private ApplicationCodeProperties applicationCodeProperties;


  @Override
  public void putDataToEbs(String aeBatchId, String applicationCode) {
    if (applicationCode.equalsIgnoreCase(applicationCodeProperties.getApplicationCodeExpense()) ||
        applicationCode.equalsIgnoreCase(applicationCodeProperties.getApplicationCodePayment()) ||
        applicationCode.equalsIgnoreCase(applicationCodeProperties.getApplicationCodePsSalary()) ||
        applicationCode.equalsIgnoreCase(
            applicationCodeProperties.getApplicationCodeImportExpense()) ||
        applicationCode.equalsIgnoreCase(
            applicationCodeProperties.getApplicationCodeImportExpensePayment())) {
      //总账接口
      ebsDataGlService.putDataToEbsGl(aeBatchId);
    } else if (applicationCode.equalsIgnoreCase(applicationCodeProperties.getApplicationCodeScmAp())
        || applicationCode
        .equalsIgnoreCase(applicationCodeProperties.getApplicationCodeScmPreparePayment())) {
      //AP接口
      ebsDataApService.putDataToEbsAp(aeBatchId);
    } else if (applicationCode
        .equalsIgnoreCase(applicationCodeProperties.getApplicationCodeScmApWriteOff())) {
      //AP核销接口
      ebsDataApWriteOffService.putDataToEbsApWriteOff(aeBatchId);
    } else if (applicationCode
        .equalsIgnoreCase(applicationCodeProperties.getApplicationCodeScmAr())) {
      //AR接口
      ebsDataArService.putDataToEbsAr(aeBatchId);
    } else if (applicationCode
        .equalsIgnoreCase(applicationCodeProperties.getApplicationCodeScmPublicPayment())) {
      //AP支付接口
      ebsDataApPaymentService.putDataToEbsApPayment(aeBatchId);
    } else {
      throw new BizException("通过应用代码匹配EBS对象失败！");
    }
  }

  @Override
  public void getDataFromEbs(String aeBatchId, String applicationCode) {
    if (applicationCode.equalsIgnoreCase(applicationCodeProperties.getApplicationCodeExpense()) ||
        applicationCode.equalsIgnoreCase(applicationCodeProperties.getApplicationCodePayment()) ||
        applicationCode.equalsIgnoreCase(applicationCodeProperties.getApplicationCodePsSalary()) ||
        applicationCode.equalsIgnoreCase(
            applicationCodeProperties.getApplicationCodeImportExpense()) ||
        applicationCode.equalsIgnoreCase(
            applicationCodeProperties.getApplicationCodeImportExpensePayment())) {
      ebsDataGlService.getDataFromEbsGl(aeBatchId);
    } else {
      throw new BizException("通过应用代码匹配EBS对象失败！");
    }
  }

}
