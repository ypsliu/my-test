package com.deloitte.bdh.ae.model.io.segment;

import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.Data;

/**
 * @author Ashen
 * @date 24/04/2020
 */
@Data
public class SourceOutput {

  @ApiModelProperty(value = "返回状态")
  private String status;

  @ApiModelProperty(value = "返回信息")
  private String message;

  private List<SourceDetail> list;

}
