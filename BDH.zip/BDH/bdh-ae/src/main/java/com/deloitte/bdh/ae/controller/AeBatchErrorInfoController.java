package com.deloitte.bdh.ae.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.deloitte.bdh.ae.model.AeApplication;
import com.deloitte.bdh.ae.model.AeBatchErrorInfo;
import com.deloitte.bdh.ae.model.AeSource;
import com.deloitte.bdh.ae.model.AeSourceBatch;
import com.deloitte.bdh.ae.model.AeSourceLoadTable;
import com.deloitte.bdh.ae.model.dto.BatchDto;
import com.deloitte.bdh.ae.service.AeApplicationService;
import com.deloitte.bdh.ae.service.AeBatchErrorInfoService;
import com.deloitte.bdh.ae.service.AeDataService;
import com.deloitte.bdh.ae.service.AeSourceBatchService;
import com.deloitte.bdh.ae.service.AeSourceLoadTableService;
import com.deloitte.bdh.ae.service.AeSourceService;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.RetResponse;
import com.deloitte.bdh.common.base.RetResult;
import com.deloitte.bdh.common.exception.BizException;
import com.deloitte.bdh.engine.runtime.entity.DataLine;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author dahpeng
 * @Description: AeBatchErrorInfoController类
 * @date 2020/02/21 18:09
 */
@RestController
@Api(tags = "错误信息")
@RequestMapping("/aeBatchErrorInfo")
public class AeBatchErrorInfoController {

  @Autowired
  private AeBatchErrorInfoService aeBatchErrorInfoService;

  @Autowired
  private AeApplicationService aeApplicationService;

  @Autowired
  private AeSourceBatchService aeSourceBatchService;

  @Autowired
  private AeSourceService aeSourceService;

  @Autowired
  private AeSourceLoadTableService aeSourceLoadTableService;

  @Autowired
  private AeDataService aeDataService;

  @PostMapping("/queryList")
  @ApiOperation(value = "查看错误信息")
  public RetResult<List<AeBatchErrorInfo>> errorInfo(
      @RequestBody @Validated RetRequest<BatchDto> batchDtoRetRequest) {
    AeSourceBatch aeSourceBatch = aeSourceBatchService
        .getById(batchDtoRetRequest.getData().getAeBatchId());

    List<AeApplication> aeApplicationList = aeApplicationService.list(
        new LambdaQueryWrapper<AeApplication>()
            .eq(AeApplication::getApplicationCode, aeSourceBatch.getApplicationCode()));
    if (aeApplicationList.size() != 1) {
      throw new BizException("查询批次的产品信息失败！");
    }
    List<AeBatchErrorInfo> list = aeBatchErrorInfoService
        .selectListByBatchId(batchDtoRetRequest.getData().getAeBatchId());
    // 更新下面3个列信息
    List<AeSource> sourceList = aeSourceService.list(new LambdaQueryWrapper<AeSource>()
        .in(AeSource::getDisplayCode, "DOCUMENT_HEAD_NUMBER", "DOCUMENT_HEAD_TYPE",
            "DOCUMENT_LINE_ORDER")
        .eq(AeSource::getApplicationId, aeApplicationList.get(0).getApplicationId()));

    ArrayList<AeSource> headColumn = new ArrayList<>();
    sourceList.forEach(aeSource -> {
      if ("DOCUMENT_HEAD_NUMBER".equalsIgnoreCase(aeSource.getDisplayCode()) || "DOCUMENT_HEAD_TYPE"
          .equalsIgnoreCase(aeSource.getDisplayCode())) {
        // 头字段
        headColumn.add(aeSource);
      } else {
        // 行字段
        updateLineOrder(list, aeSource, aeSourceBatch.getSourceBatchId());
      }
    });
    // 行字段
    updateHeadColumn(list, headColumn, aeSourceBatch.getSourceBatchId());
    return RetResponse.makeOKRsp(list);
  }

  /**
   * 更新头上字段
   */
  private void updateHeadColumn(List<AeBatchErrorInfo> list, ArrayList<AeSource> headColumn,
      String sourceBatchId) {
    if (headColumn.size() > 2) {
      throw new BizException("配置来源的单据头输出字段大于2个,查询失败！");
    }
    if (headColumn.size() == 0) {
      return;
    }
    if (headColumn.size() == 2) {
      if (!headColumn.get(0).getTableId().equals(headColumn.get(1).getTableId())) {
        throw new BizException("配置来源的单据头输出字段必须在同一张表中！");
      }
    }

    AeSourceLoadTable aeSourceLoadTable = null;
    aeSourceLoadTable = aeSourceLoadTableService.getById(headColumn.get(0).getTableId());

    StringBuffer sql = new StringBuffer();
    sql.append("SELECT ");
    sql.append("SOURCE_HEAD_ID,");
    headColumn.forEach(aeSource -> {
      sql.append(aeSource.getSourceName()).append(" AS ").append(aeSource.getDisplayCode())
          .append(",");
    });
    //删除一个多余逗号
    sql.deleteCharAt(sql.length() - 1);
    sql.append(" FROM ").append(aeSourceLoadTable.getTableName());
    sql.append(" WHERE ");
    sql.append("SOURCE_BATCH_ID = '").append(sourceBatchId).append("'");
    List<DataLine> dataLineList = aeDataService.loadData(sql.toString());
    Map<String, DataLine> dataMap = new HashMap<>();
    dataLineList.forEach(dataLine -> {
      String sourceHeadId = (String) dataLine.get("SOURCE_HEAD_ID");
      dataMap.put(sourceHeadId, dataLine);
    });
    list.forEach(aeBatchErrorInfo -> {
      if (aeBatchErrorInfo.getSourceHeadId() != null) {
        DataLine dataLine = dataMap.get(aeBatchErrorInfo.getSourceHeadId());
        String documentHeadNumber = (String) dataLine.get("DOCUMENT_HEAD_NUMBER");
        String documentHeadType = (String) dataLine.get("DOCUMENT_HEAD_TYPE");
        aeBatchErrorInfo.setDocumentHeadNumber(documentHeadNumber);
        aeBatchErrorInfo.setDocumentHeadType(documentHeadType);
      }
    });
  }

  /**
   * 根据来源上的字段更新排序字段
   */
  private void updateLineOrder(List<AeBatchErrorInfo> list, AeSource aeSource,
      String sourceBatchId) {
    AeSourceLoadTable aeSourceLoadTable = new AeSourceLoadTable();
    if (aeSource != null && aeSource.getTableId() != null) {
      aeSourceLoadTable = aeSourceLoadTableService.getById(aeSource.getTableId());
    }
    StringBuffer sql = new StringBuffer();
    sql.append("SELECT ");
    sql.append("SOURCE_HEAD_ID,SOURCE_LINE_ID,");
    sql.append(aeSource.getSourceName()).append(" AS ").append(" DOCUMENT_LINE_ORDER ");
    sql.append(" FROM ").append(aeSourceLoadTable.getTableName());
    sql.append(" WHERE ");
    sql.append("SOURCE_BATCH_ID = '").append(sourceBatchId).append("'");
    List<DataLine> dataLineList = aeDataService.loadData(sql.toString());
    Map<String, DataLine> dataMap = new HashMap<>();
    dataLineList.forEach(dataLine -> {
      String sourceHeadId = (String) dataLine.get("SOURCE_HEAD_ID");
      String sourceLineId = (String) dataLine.get("SOURCE_LINE_ID");
      dataMap.put(sourceHeadId + "@" + sourceLineId, dataLine);
    });
    list.forEach(aeBatchErrorInfo -> {
      if (aeBatchErrorInfo.getSourceHeadId() != null
          && aeBatchErrorInfo.getSourceLineId() != null) {
        String key = aeBatchErrorInfo.getSourceHeadId() + "@" + aeBatchErrorInfo.getSourceLineId();
        DataLine dataLine = dataMap.get(key);
        Object value = dataLine.get("DOCUMENT_LINE_ORDER");
        String result = (value != null ? String.valueOf(value) : null);
        aeBatchErrorInfo.setDocumentLineOrder(result);
      }
    });
  }

}