package com.deloitte.bdh.common.interceptor;

import com.deloitte.bdh.common.annotation.Log;
import java.lang.reflect.Method;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * @author Ashen
 * @date 15/01/2020
 */
@Aspect
@Component
public class LogAspect {

  private static final Logger logger = LoggerFactory.getLogger(LogAspect.class);

  @Pointcut("@annotation(com.deloitte.bdh.common.annotation.Log)")
  public void logPointCut() {
  }

  @Around("logPointCut()")
  public Object doAround(ProceedingJoinPoint pjp) throws Throwable {
    // 获取方法签名
    MethodSignature methodSignature = (MethodSignature) pjp.getSignature();
    // 获取方法
    Method method = methodSignature.getMethod();
    Log log = method.getAnnotation(Log.class);
    // 获取操作描述的属性值
    String operate = log.operate();
    long start = System.currentTimeMillis();
    logger.info(operate + " --> 开始....");
    Object value = pjp.proceed();
    long end = System.currentTimeMillis();
    logger.info(operate + " --> 结束，耗时[" + (end - start) + "ms]...");
    return value;
  }
}
