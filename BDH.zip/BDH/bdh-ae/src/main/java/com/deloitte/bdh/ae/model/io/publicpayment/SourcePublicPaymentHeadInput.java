package com.deloitte.bdh.ae.model.io.publicpayment;

import com.deloitte.bdh.ae.model.SourcePublicPaymentHead;

/**
 * @author Ashen
 * @date 20/04/2020
 */
public class SourcePublicPaymentHeadInput extends SourcePublicPaymentHead {

}
