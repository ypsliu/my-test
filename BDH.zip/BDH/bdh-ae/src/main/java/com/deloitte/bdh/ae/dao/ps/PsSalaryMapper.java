package com.deloitte.bdh.ae.dao.ps;

import com.deloitte.bdh.ae.model.SourcePsSalaryHead;
import com.deloitte.bdh.ae.model.SourcePsSalaryLine;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * @author Ashen
 * @date 27/04/2020
 */
public interface PsSalaryMapper {

  /**
   * 查询头信息
   *
   * @param psCompanyId
   * @param period
   * @param version
   * @return
   */
  List<SourcePsSalaryHead> selectHeadDataFromPs(@Param("psCompanyId") String psCompanyId,
      @Param("period") String period, @Param("version") String version);


  /**
   * 查询行信息
   *
   * @param psCompanyId
   * @param period
   * @param version
   * @return
   */
  List<SourcePsSalaryLine> selectLineDataFromPs(
      @Param("psCompanyId") String psCompanyId,
      @Param("period") String period,
      @Param("version") String version);


  /**
   * 查询PS系统中的一条最大明细数据
   *
   * @param psCompanyId
   * @param period
   * @return
   */
  SourcePsSalaryLine selectOneDataMaxVersionFromPs(@Param("psCompanyId") String psCompanyId,
      @Param("period") String period);
}
