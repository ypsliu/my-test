package com.deloitte.bdh.common.interceptor;

import cn.hutool.core.util.ArrayUtil;
import com.alibaba.fastjson.JSON;
import com.deloitte.bdh.ae.model.BaseTenant;
import com.deloitte.bdh.ae.service.BaseTenantService;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.context.ThreadContextHolder;
import com.deloitte.bdh.common.util.AssertUtils;
import java.util.Objects;
import javax.servlet.http.HttpServletRequest;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * 提取参数中的操作人
 *
 * @author jinqwang
 */
@Aspect
@Order(2)
@Component
public class RetRequestAspect {

  private static final Logger logger = LoggerFactory.getLogger(RetRequestAspect.class);

  @Autowired
  private BaseTenantService baseTenantService;

  @Pointcut("execution(public * com.deloitte.bdh..controller.*.*(..))")
  public void pointCut() {
  }

  @Pointcut("execution(public * com.deloitte.bdh..controller.*.*(..))"
      + "&& !@annotation(com.deloitte.bdh.common.annotation.NoTenantCode)")
  public void tenantPointCut() {

  }

  @Around("tenantPointCut()")
  public Object aroundTenantPoint(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
    setTenant();
    try {
      return proceedingJoinPoint.proceed();
    } finally {
      ThreadContextHolder.remove();
    }
  }

  @Around("pointCut()")
  public Object around(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
    ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder
        .getRequestAttributes();
    HttpServletRequest request = attributes.getRequest();
    Object[] args = proceedingJoinPoint.getArgs();
    if (ArrayUtil.isNotEmpty(args) && args[0] instanceof RetRequest) {
      setRequest(args[0]);
    } else if (ArrayUtil.isNotEmpty(args)) {
      RetRequest retRequest = new RetRequest();
      retRequest.setLang(request.getParameter("lang"));
      retRequest.setOperator(request.getParameter("operator"));
      retRequest.setSource(request.getParameter("source"));
      retRequest.setVersion(request.getParameter("version"));
      retRequest.setSid(request.getParameter("sid"));
      setRequest(retRequest);
      logger.info("请求参数不是标准的RetRequest对象,智能组合为：" + JSON.toJSONString(retRequest));
    }
    setIp();
    setLang();
    /*
     * 不进行任何异常拦截，最后需要将数据remove掉
     */
    try {
      return proceedingJoinPoint.proceed();
    } finally {
      ThreadContextHolder.remove();
    }
  }

  private void setLang() {
    ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder
        .getRequestAttributes();
    String lang = attributes.getRequest().getParameter("lang");
    ThreadContextHolder.setLang(lang);
  }


  private void setRequest(Object parameter) {
    RetRequest<?> retRequest = (RetRequest<?>) parameter;
    ThreadContextHolder.setRetRequest(retRequest);
  }


  private void setIp() {
    // 接收到请求，记录请求内容
    ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder
        .getRequestAttributes();
    String ip = "";
    if (Objects.nonNull(attributes)) {
      HttpServletRequest request = attributes.getRequest();
      ip = request.getRemoteAddr();
    }
    ThreadContextHolder.setIp(ip);
  }

  private void setTenant() {
    // 接收到请求，记录请求内容
    HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder
        .getRequestAttributes()).getRequest();
    String tenantCode = request.getHeader("x-bdh-tenant-code");
    AssertUtils.assertNotEmpty(tenantCode, "Header参数[x-bdh-tenant-code]不能为空！");
    BaseTenant baseTenant = baseTenantService.getTenantByCode(tenantCode);
    AssertUtils.assertNotNull(baseTenant, "根据租户Code[{}]匹配租户失败！", tenantCode);
    ThreadContextHolder.setTenantThreadLocal(baseTenant);
  }

}
