package com.deloitte.bdh.ae.client.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import javax.validation.constraints.NotNull;
import lombok.Data;

@ApiModel(description = "公司部门查询接口请求参数")
@Data
public class CompanyDepartmentDto implements Serializable {

  @ApiModelProperty(value = "公司id")
  @NotNull(message = "公司ID不能为空")
  private String organizationId;
}
