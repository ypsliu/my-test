package com.deloitte.bdh.ae.client.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2020-08-18
 */
@ApiModel(value = "查询组织信息请求视图")
@Data
public class FndPortalOrganizationDto implements Serializable {

  private static final long serialVersionUID = 1L;

  @ApiModelProperty(value = "组织ID")
  private String organizationId;

  @ApiModelProperty(value = "组织Code")
  private String organizationCode;

}
