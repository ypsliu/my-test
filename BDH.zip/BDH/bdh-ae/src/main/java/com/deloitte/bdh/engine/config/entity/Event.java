package com.deloitte.bdh.engine.config.entity;

import java.util.List;
import lombok.Data;

/**
 * 事件分类 & 事件类型
 *
 * @author Ashen
 * @date 02/12/2019
 */
@Data
public class Event {

  /**
   * 事件类型ID
   */
  private String eventTypeId;

  /**
   * 事件类型CODE
   */
  private String typeCode;

  /**
   * 事件类型名称
   */
  private String typeName;

  /**
   * 说明ID
   */
  private String explainId;

  private JournalExplain journalExplain;

  /**
   * 来源表ID
   */
  private String sourceTableId;

  /**
   * 目标表ID
   */
  private String targetTableId;

  /**
   * 日记账列表
   */
  private List<Journal> journalList;

}
