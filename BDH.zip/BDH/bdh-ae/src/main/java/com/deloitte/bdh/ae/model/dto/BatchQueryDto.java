package com.deloitte.bdh.ae.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.LocalDate;
import javax.validation.constraints.NotEmpty;
import lombok.Data;

/**
 * @author Ashen
 * @date 20/02/2020
 */
@Data
@ApiModel(description = "查询批次条件信息")
public class BatchQueryDto {

  @ApiModelProperty(value = "应用产品CODE")
  @NotEmpty(message = "应用产品CODE不能为空")
  private String applicationCode;

  @ApiModelProperty(value = "批号")
  private String aeBatchCode;

  @ApiModelProperty(value = "入账人")
  private String entryUserId;

  @ApiModelProperty(value = "数据同步时间从")
  private LocalDate createDateFrom;

  @ApiModelProperty(value = "数据同步时间至")
  private LocalDate createDateTo;

  @ApiModelProperty(value = "公司ID")
  private String organizationId;

  @ApiModelProperty(value = "入账状态")
  private String aeStatus;

  @ApiModelProperty(value = "入账日期从")
  private LocalDate entryDateFrom;

  @ApiModelProperty(value = "入账日期至")
  private LocalDate entryDateTo;

  @ApiModelProperty(value = "会计科目类型")
  private String entryType;

}
