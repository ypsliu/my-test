package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.deloitte.bdh.ae.client.FeignClientService;
import com.deloitte.bdh.ae.client.vo.OrganizationClientVo;
import com.deloitte.bdh.ae.dao.ae.AeBatchSyncLogMapper;
import com.deloitte.bdh.ae.model.AeBatchSyncLog;
import com.deloitte.bdh.ae.model.vo.CompanyDataPermissionVo;
import com.deloitte.bdh.ae.service.AeBatchSyncLogService;
import com.deloitte.bdh.ae.service.EnumService;
import com.deloitte.bdh.ae.service.LocaleMessageSourceService;
import com.deloitte.bdh.common.base.PageRequest;
import com.deloitte.bdh.common.base.ServiceTransactionalImpl;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.common.util.StringUtil;
import com.github.pagehelper.PageHelper;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Service
@DS(DSConstant.AE_DB)
public class AeBatchSyncLogServiceImpl extends
    ServiceTransactionalImpl<AeBatchSyncLogMapper, AeBatchSyncLog> implements
    AeBatchSyncLogService {

  @Autowired
  private LocaleMessageSourceService localeMessageSourceService;

  @Autowired
  private FeignClientService feignClientService;

  @Autowired
  private EnumService enumService;

  @Override
  public void insertSyncLog(String aeBatchId, String userId, String period, LocalDateTime startTime,
      LocalDateTime endTime, String status, String failReason) {
    AeBatchSyncLog aeBatchSyncLog = new AeBatchSyncLog();
    aeBatchSyncLog.setLogId(this.getSequence());
    aeBatchSyncLog.setAeBatchId(aeBatchId);
    aeBatchSyncLog.setUserId(userId);
    aeBatchSyncLog.setPeriod(period);
    aeBatchSyncLog.setStartTime(startTime);
    aeBatchSyncLog.setEndTime(endTime);
    aeBatchSyncLog.setStatus(status);
    aeBatchSyncLog.setFailReason(failReason);
    this.save(aeBatchSyncLog);
  }

  @Override
  public List<AeBatchSyncLog> selectList(
      PageRequest<Void> pageRequest) {
    List<CompanyDataPermissionVo> companyDataPermissionVoList = feignClientService
        .getUserDataPermissions();
    List<String> orgIdList = companyDataPermissionVoList.stream()
        .map(CompanyDataPermissionVo::getOrganizationId).collect(Collectors.toList());
    if (orgIdList.size() == 0) {
      return new ArrayList<>();
    }
    PageHelper.startPage(pageRequest.getPage(), pageRequest.getSize());
    List<AeBatchSyncLog> list = baseMapper.selectListByOrganizationList(orgIdList);
    Set<String> userIdSet = new HashSet<>();
    Set<String> organizationIdSet = new HashSet<>();
    list.forEach(aeBatchSyncLog -> {
      if (StringUtil.isEmpty(aeBatchSyncLog.getUserId())) {
        userIdSet.add(aeBatchSyncLog.getUserId());
      }
      if (StringUtil.isEmpty(aeBatchSyncLog.getOrganizationId())) {
        organizationIdSet.add(aeBatchSyncLog.getOrganizationId());
      }
    });

    Map<String, String> userNameMap = feignClientService.getUserNameMapByIdSet(userIdSet);
    List<OrganizationClientVo> tenantOrganizationList = feignClientService.getTenantCompanyList();

    Map<String, String> organizationMap = tenantOrganizationList.stream().collect(
        Collectors.toMap(OrganizationClientVo::getOrganizationId,
            OrganizationClientVo::getOrganizationName));
    Map<String, String> sourceEnumValueMap = enumService
        .getSystemEnumValueMap("AE_EVENT_SOURCE_TARGET");

    list.forEach(aeBatchSyncLog -> {
      aeBatchSyncLog.setSourceShow(sourceEnumValueMap.get(aeBatchSyncLog.getSource()));
      aeBatchSyncLog.setUserName(userNameMap.get(aeBatchSyncLog.getUserId()));
      aeBatchSyncLog.setOrganizationName(organizationMap.get(aeBatchSyncLog.getOrganizationId()));
      if (aeBatchSyncLog.getStartTime() != null && aeBatchSyncLog.getEndTime() != null) {
        Duration duration = Duration
            .between(aeBatchSyncLog.getStartTime(), aeBatchSyncLog.getEndTime());
        aeBatchSyncLog.setUsedTime(duration.getSeconds());
      }
      aeBatchSyncLog.setStatusShow(localeMessageSourceService
          .getMessage("ae.batch.sync.status." + aeBatchSyncLog.getStatus(), pageRequest.getLang()));
    });
    return list;
  }
}
