package com.deloitte.bdh.ae.client;

import com.deloitte.bdh.ae.client.dto.CompanyDepartmentDto;
import com.deloitte.bdh.ae.client.vo.BiDataCompanySystemVo;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.RetResult;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * @author Ashen
 * @date 17/12/2020
 */
@FeignClient(value = "bdh-platform", contextId = "companySystem-client")
@Component
public interface BiDataCompanySystemClient {

  /**
   * 获取公司列表
   *
   * @param retRequest
   * @return
   */
  @PostMapping("/platform/biDataCompanySystem/getSystemByCompanyId")
  RetResult<List<BiDataCompanySystemVo>> getSystemByCompanyId(
      RetRequest<CompanyDepartmentDto> retRequest);
}
