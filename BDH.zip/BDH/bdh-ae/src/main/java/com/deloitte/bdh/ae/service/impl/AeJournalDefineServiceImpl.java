package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.deloitte.bdh.ae.dao.ae.AeJournalDefineMapper;
import com.deloitte.bdh.ae.model.AeJournalDefine;
import com.deloitte.bdh.ae.service.AeJournalDefineService;
import com.deloitte.bdh.common.base.ServiceTransactionalImpl;
import com.deloitte.bdh.common.constant.DSConstant;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Service
@DS(DSConstant.AE_DB)
public class AeJournalDefineServiceImpl extends
    ServiceTransactionalImpl<AeJournalDefineMapper, AeJournalDefine> implements
    AeJournalDefineService {

}
