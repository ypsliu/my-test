package com.deloitte.bdh.ae.dao.ae;

import com.deloitte.bdh.ae.model.TargetApInterface;
import com.deloitte.bdh.ae.model.TargetSourceBasicInfo;
import com.deloitte.bdh.ae.model.io.ebsap.P_INVOICES_TBL_ITEM;
import com.deloitte.bdh.common.base.Mapper;
import java.util.List;
import java.util.Set;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface TargetApInterfaceMapper extends Mapper<TargetApInterface> {

  /**
   * 查询AP 发票信息
   *
   * @param aeBatchId
   * @return
   */
  List<P_INVOICES_TBL_ITEM> queryInvoicesItem(@Param("aeBatchId") String aeBatchId);

  /**
   * 根据LineNo 查询目标数据的来源基本信息
   *
   * @param lineNumberSet
   * @return
   */
  List<TargetSourceBasicInfo> selectByLineNumberSet(
      @Param("lineNumberSet") Set<String> lineNumberSet);
}
