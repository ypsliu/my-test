package com.deloitte.bdh.ae.model;

import java.math.BigDecimal;
import com.deloitte.bdh.common.base.BaseModel;
import java.time.LocalDate;
import com.baomidou.mybatisplus.annotation.TableField;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 借款付款行信息
 * </p>
 *
 * @author Ashen
 * @since 2021-03-24
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "SourceImportPaymentHead对象", description = "借款付款行信息")
public class SourceImportPaymentHead extends BaseModel {

  private static final long serialVersionUID = 1L;

  @ApiModelProperty(value = "付款编号")
  @TableField("PAYMENT_NUMBER")
  private String paymentNumber;

  @ApiModelProperty(value = "公司ID")
  @TableField("ORGANIZATION_ID")
  private String organizationId;

  @ApiModelProperty(value = "公司编号")
  @TableField("ORGANIZATION_NUMBER")
  private String organizationNumber;

  @ApiModelProperty(value = "公司名称")
  @TableField("ORGANIZATION_NAME")
  private String organizationName;

  @ApiModelProperty(value = "付款类型")
  @TableField("PAYMENT_TYPE")
  private String paymentType;

  @ApiModelProperty(value = "付款人")
  @TableField("PAYMENT_USER_NAME")
  private String paymentUserName;

  @ApiModelProperty(value = "付款日期")
  @TableField("PAYMENT_DATE")
  private LocalDate paymentDate;

  @ApiModelProperty(value = "付款方式")
  @TableField("PAYMENT_METHOD")
  private String paymentMethod;

  @ApiModelProperty(value = "币种")
  @TableField("CURRENCY_CODE")
  private String currencyCode;

  @ApiModelProperty(value = "汇率")
  @TableField("CURRENCY_RATE")
  private BigDecimal currencyRate;

  @ApiModelProperty(value = "付款总金额")
  @TableField("TOTAL_AMOUNT")
  private BigDecimal totalAmount;

  @ApiModelProperty(value = "付款银行")
  @TableField("PAYMENT_BANK")
  private String paymentBank;

  @TableField("SOURCE_BATCH_ID")
  private String sourceBatchId;

  @TableField("SOURCE_HEAD_ID")
  private String sourceHeadId;

  @TableField("AE_ROW_ID")
  private String aeRowId;

  @TableField("AE_STATUS")
  private String aeStatus;


}
