package com.deloitte.bdh.ae.dao.ae;

import com.deloitte.bdh.ae.model.SourceImportExpenseLine;
import com.deloitte.bdh.common.base.Mapper;

/**
 * <p>
 * 费用报销其他行 Mapper 接口
 * </p>
 *
 * @author Ashen
 * @since 2021-03-24
 */
public interface SourceImportExpenseLineMapper extends Mapper<SourceImportExpenseLine> {

}
