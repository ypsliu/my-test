package com.deloitte.bdh.ae.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotNull;
import lombok.Data;

/**
 * @author Ashen
 * @date 20/02/2020
 */
@Data
@ApiModel(description = "批次单据信息")
public class BatchDocumentDto {

  @ApiModelProperty(value = "批次Id信息")
  @NotNull(message = "批次ID不能为空")
  private String aeBatchId;

  @ApiModelProperty(value = "单据头ID信息")
  @NotNull(message = "单据头ID不能为空")
  private String sourceHeadId;
}
