package com.deloitte.bdh.ae.controller;

import com.deloitte.bdh.ae.model.io.OneDataInput;
import com.deloitte.bdh.ae.model.io.expense.ExpenseDataInput;
import com.deloitte.bdh.ae.model.io.expense.ExpenseDataOutput;
import com.deloitte.bdh.ae.model.io.target.TargetDataOutput;
import com.deloitte.bdh.ae.service.SourceExpenseHeadService;
import com.deloitte.bdh.common.exception.BizException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Ashen
 * @date 28/02/2020
 */
@RestController
@Api(tags = "数据同步:报销核销")
@RequestMapping("/aeDataExpense")
public class AeDataExpenseController {

  @Autowired
  private SourceExpenseHeadService sourceExpenseHeadService;

  /**
   * @Description: 接口数据
   * @Reutrn
   */
  @PostMapping("putData")
  @ApiOperation(value = "报销数据同步接口")
  public ExpenseDataOutput putData(
      @RequestBody ExpenseDataInput expenseDataInput) {
    try {
      ExpenseDataOutput expenseDataOutput = sourceExpenseHeadService.putData(expenseDataInput);
      return expenseDataOutput;
    } catch (BizException e) {
      e.printStackTrace();
      ExpenseDataOutput expenseDataOutput = new ExpenseDataOutput();
      expenseDataOutput.setStatus("FAIL");
      expenseDataOutput.setMessage("同步数据失败：" + e.getMessage());
      return expenseDataOutput;
    }
  }

  /**
   * @Description: 接口数据
   * @Reutrn
   */
  @PostMapping("getTargetDate")
  @ApiOperation(value = "获取最终的科目信息")
  public TargetDataOutput getTargetDate(
      @RequestBody OneDataInput oneDataInput) {
    try {
      TargetDataOutput targetDataOutput = sourceExpenseHeadService.getTargetDate(oneDataInput);
      return targetDataOutput;
    } catch (BizException e) {
      e.printStackTrace();
      TargetDataOutput targetDataOutput = new TargetDataOutput();
      targetDataOutput.setStatus("FAIL");
      targetDataOutput.setMessage("获取目标数据失败：" + e.getMessage());
      return targetDataOutput;
    }
  }
}
