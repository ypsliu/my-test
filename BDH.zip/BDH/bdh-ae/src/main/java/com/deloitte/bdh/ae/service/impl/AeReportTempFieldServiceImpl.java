package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.deloitte.bdh.ae.dao.ae.AeReportTempFieldMapper;
import com.deloitte.bdh.ae.model.AeReportTempField;
import com.deloitte.bdh.ae.model.AeReportTemplate;
import com.deloitte.bdh.ae.model.AeTarget;
import com.deloitte.bdh.ae.service.AeReportTempFieldService;
import com.deloitte.bdh.ae.service.AeTargetService;
import com.deloitte.bdh.common.base.ServiceTransactionalImpl;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.common.exception.BizException;
import com.deloitte.bdh.common.util.StringUtil;
import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.annotation.Resource;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Service
@DS(DSConstant.AE_DB)
public class AeReportTempFieldServiceImpl extends
    ServiceTransactionalImpl<AeReportTempFieldMapper, AeReportTempField> implements
    AeReportTempFieldService {

  @Resource
  private AeReportTempFieldService aeReportTempFieldService;

  @Resource
  private AeTargetService aeTargetService;

  @Override
  public List<AeReportTempField> queryToSelectFieldList(AeReportTemplate dto) {
    if (dto.getApplicationId() == null) {
      throw new BizException("查询的应用产品ID不能为空");
    }
    List<AeReportTempField> allFieldList = queryAllFieldList(dto.getApplicationId());
    if (StringUtil.isEmpty(dto.getReportId())) {
      dto.setReportId("-1");
    }
    List<AeReportTempField> selectedList = aeReportTempFieldService
        .list(new LambdaQueryWrapper<AeReportTempField>()
            .eq(AeReportTempField::getReportId, dto.getReportId()));
    Map<String, AeReportTempField> selectedTargetMap = selectedList.stream()
        .collect(Collectors.toMap(AeReportTempField::getTargetId, Function.identity()));
    Iterator<AeReportTempField> allFieldIter = allFieldList.iterator();
    while (allFieldIter.hasNext()) {
      AeReportTempField aeReportTempField = allFieldIter.next();
      if (aeReportTempField.getFlexFlag()
          || selectedTargetMap.get(aeReportTempField.getTargetId()) != null) {
        //如果为固定字段、已选字段则显示在右侧；左侧删除
        allFieldIter.remove();
      }
    }
    return allFieldList;
  }

  @Override
  public List<AeReportTempField> querySelectedFieldList(AeReportTemplate dto) {
    if (dto.getApplicationId() == null) {
      throw new BizException("查询的应用产品ID不能为空");
    }
    List<AeReportTempField> allFieldList = queryAllFieldList(dto.getApplicationId());
    if (StringUtil.isEmpty(dto.getReportId())) {
      dto.setReportId("-1");
    }
    List<AeReportTempField> selectedList = aeReportTempFieldService
        .list(new LambdaQueryWrapper<AeReportTempField>()
            .eq(AeReportTempField::getReportId, dto.getReportId()));
    Map<String, AeReportTempField> selectedTargetMap = selectedList.stream()
        .collect(Collectors.toMap(AeReportTempField::getTargetId, Function.identity()));
    Iterator<AeReportTempField> allFieldIter = allFieldList.iterator();
    while (allFieldIter.hasNext()) {
      AeReportTempField aeReportTempField = allFieldIter.next();
      AeReportTempField selected = selectedTargetMap.get(aeReportTempField.getTargetId());

      if (!aeReportTempField.getFlexFlag()
          && selected == null) {
        //如果不为固定字段且没有被选字段则显示在左侧侧；右侧删除
        allFieldIter.remove();
      } else {
        if (selected != null) {
          aeReportTempField.setFieldName(selected.getFieldName());
          aeReportTempField.setWidth(selected.getWidth());
          aeReportTempField.setPriorityLevel(selected.getPriorityLevel());
        }
      }
    }
    allFieldList.sort((AeReportTempField o1, AeReportTempField o2) -> {
      if (o1.getPriorityLevel() == null) {
        return 1;
      }
      return o1.getPriorityLevel().compareTo(o2.getPriorityLevel());
    });
    return allFieldList;
  }


  /**
   * 根据应用产品查询所有的目标字段
   *
   * @param applicationId
   * @return
   */
  private List<AeReportTempField> queryAllFieldList(String applicationId) {
    List<AeTarget> targetList = aeTargetService.list(new LambdaQueryWrapper<AeTarget>()
        .eq(AeTarget::getApplicationId, applicationId));
    List<AeReportTempField> aeReportTempFieldList = targetList.stream().map(aeTarget -> {
      AeReportTempField aeReportTempField = new AeReportTempField();
      aeReportTempField.setTargetId(aeTarget.getTargetId());
      aeReportTempField.setFieldName(aeTarget.getDisplayName());
      aeReportTempField.setDisplayCode(aeTarget.getDisplayCode());
      aeReportTempField.setDisplayName(aeTarget.getDisplayName());
      aeReportTempField.setTargetDataType(aeTarget.getTargetDataType());
      if (new BigDecimal("1").equals(aeTarget.getReportFlag())) {
        aeReportTempField.setFlexFlag(true);
      }
      return aeReportTempField;
    }).collect(Collectors.toList());
    return aeReportTempFieldList;
  }

}
