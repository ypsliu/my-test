package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "SourcePreparePaymentLine对象", description = "")
public class SourcePreparePaymentLine extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableField("PAYMENT_AP_LINE_ID_T1")
  private BigDecimal paymentApLineIdT1;

  @TableField("AP_PAY_LINE_ID_T1")
  private BigDecimal apPayLineIdT1;

  @TableField("AP_PAY_HEAD_ID_T1")
  private BigDecimal apPayHeadIdT1;

  @TableField("PAYMENT_ID_T1")
  private BigDecimal paymentIdT1;

  @TableField("PAY_AMOUNT_T1")
  private BigDecimal payAmountT1;

  @TableField("TOTAL_AMOUNT_T1")
  private BigDecimal totalAmountT1;

  @TableField("CREATE_USER_T1")
  private BigDecimal createUserT1;

  @TableField("CREATE_DATE_T1")
  private LocalDate createDateT1;

  @TableField("MODIFY_USER_T1")
  private BigDecimal modifyUserT1;

  @TableField("MODIFY_DATE_T1")
  private LocalDate modifyDateT1;

  @TableField("LINE_ID_T2")
  private BigDecimal lineIdT2;

  @TableField("REQUEST_HEADER_ID_T2")
  private BigDecimal requestHeaderIdT2;

  @TableField("LINE_NUMBER_T2")
  private BigDecimal lineNumberT2;

  @TableField("EXPENSE_TYPE_T2")
  private String expenseTypeT2;

  @TableField("SOURCE_DOC_TYPE_T2")
  private String sourceDocTypeT2;

  @TableField("SOURCE_DOC_ID_T2")
  private BigDecimal sourceDocIdT2;

  @TableField("SOURCE_DOC_LINE_ID_T2")
  private BigDecimal sourceDocLineIdT2;

  @TableField("COMMENTS_T2")
  private String commentsT2;

  @TableField("CREATE_DATE_T2")
  private LocalDate createDateT2;

  @TableField("CREATE_USER_T2")
  private BigDecimal createUserT2;

  @TableField("MODIFIED_DATE_T2")
  private LocalDate modifiedDateT2;

  @TableField("MODIFIED_USER_T2")
  private BigDecimal modifiedUserT2;

  @TableField("IP_T2")
  private String ipT2;

  @TableField("TAX_CODE_T2")
  private String taxCodeT2;

  @TableField("STARD_TAX_IN_AMOUNT_T2")
  private BigDecimal stardTaxInAmountT2;

  @TableField("STARD_TAX_FREE_AMOUNT_T2")
  private BigDecimal stardTaxFreeAmountT2;

  @TableField("STARD_TAX_AMOUNT_T2")
  private BigDecimal stardTaxAmountT2;

  @TableField("ORIGL_TAX_IN_AMOUNT_T2")
  private BigDecimal origlTaxInAmountT2;

  @TableField("ORIGL_TAX_FREE_AMOUNT_T2")
  private BigDecimal origlTaxFreeAmountT2;

  @TableField("ORIGL_TAX_AMOUNT_T2")
  private BigDecimal origlTaxAmountT2;

  @TableField("SOURCE_DOC_NUMBER_T2")
  private String sourceDocNumberT2;

  @TableField("AE_ROW_ID")
  private String aeRowId;

  @TableField("AE_STATUS")
  private String aeStatus;

  @TableField("SOURCE_BATCH_ID")
  private String sourceBatchId;

  @TableField("SOURCE_HEAD_ID")
  private String sourceHeadId;

  @TableField("SOURCE_LINE_ID")
  private String sourceLineId;


}
