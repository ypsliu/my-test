package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "AeReportTempOrg对象", description = "")
public class AeReportTempOrg extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableId("REPORT_ORGANIZATION_ID")
  private String reportOrganizationId;

  @TableField("REPORT_ID")
  private String reportId;

  @TableField("ORGANIZATION_ID")
  private String organizationId;

  @TableField("ACTIVE_FLAG")
  private Integer activeFlag;


}
