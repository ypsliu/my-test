package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.deloitte.bdh.ae.dao.ae.TargetApInterfaceMapper;
import com.deloitte.bdh.ae.model.TargetApInterface;
import com.deloitte.bdh.ae.model.TargetSourceBasicInfo;
import com.deloitte.bdh.ae.model.io.ebsap.P_INVOICES_TBL_ITEM;
import com.deloitte.bdh.ae.service.TargetApInterfaceService;
import com.deloitte.bdh.common.base.ServiceTransactionalImpl;
import com.deloitte.bdh.common.constant.DSConstant;
import java.util.List;
import java.util.Set;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Service
@DS(DSConstant.AE_DB)
public class TargetApInterfaceServiceImpl extends
    ServiceTransactionalImpl<TargetApInterfaceMapper, TargetApInterface> implements
    TargetApInterfaceService {

  @Override
  public List<P_INVOICES_TBL_ITEM> queryInvoicesItem(String aeBatchId) {
    return baseMapper.queryInvoicesItem(aeBatchId);
  }

  @Override
  public List<TargetSourceBasicInfo> selectByLineNumberSet(Set<String> lineNumberSet) {
    return baseMapper.selectByLineNumberSet(lineNumberSet);
  }
}
