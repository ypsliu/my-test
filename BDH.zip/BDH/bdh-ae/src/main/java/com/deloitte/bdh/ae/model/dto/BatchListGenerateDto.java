package com.deloitte.bdh.ae.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.LocalDate;
import java.util.List;
import javax.validation.constraints.NotEmpty;
import lombok.Data;

/**
 * @author Ashen
 * @date 19/02/2020
 */
@Data
@ApiModel(description = "批次列表生成类")
public class BatchListGenerateDto {

  @ApiModelProperty(value = "批次列表")
  @NotEmpty(message = "批次列表不能为空")
  private List<BatchDto> batchList;

  @ApiModelProperty(value = "入账类型：FINAL_ACCOUNT:最终入账、DRAFT_ACCOUNT:拟定")
  @NotEmpty(message = "入账类型不能为空")
  private String entryType;

  @ApiModelProperty(value = "GL日期")
  @JsonFormat(pattern = "yyyy/MM/dd")
  private LocalDate accountingDate;
}
