package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "AeJournalRuleLineCondition对象", description = "")
public class AeJournalRuleLineCondition extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableId("LINE_CONDITION_ID")
  private String lineConditionId;

  @TableField("OPERATOR")
  private String operator;

  @TableField("SOURCE_ID")
  private String sourceId;

  @TableField("VALUE_TYPE")
  private String valueType;

  @TableField("LOV_CODE")
  private String lovCode;

  @TableField("ACTIVE_FLAG")
  private Integer activeFlag;

  @TableField("VALUE_DATA")
  private String valueData;

  @TableField("DESCRIPTION")
  private String description;

  @TableField("PRIORITY_LEVEL")
  private BigDecimal priorityLevel;

  @TableField("RULE_LINE_ID")
  private String ruleLineId;


}
