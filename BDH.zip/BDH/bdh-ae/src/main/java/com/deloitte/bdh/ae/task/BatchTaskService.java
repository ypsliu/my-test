package com.deloitte.bdh.ae.task;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.deloitte.bdh.ae.model.AeSourceBatch;
import com.deloitte.bdh.ae.service.AeSourceBatchService;
import com.deloitte.bdh.common.annotation.Log;
import com.deloitte.bdh.common.context.ThreadContextHolder;
import com.deloitte.bdh.common.distributedlock.DistributedLockHandler;
import com.deloitte.bdh.engine.runtime.RunService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Ashen
 * @date 19/02/2020
 */
@Service
public class BatchTaskService {

  private static final String AE_DATA_RUNNING_KEY = "aeDataRunningTask";
  private static final String AE_DATA_RUNNING_VALUE = "aeDataRunningTask";

  @Autowired
  private AeSourceBatchService aeSourceBatchService;

  @Autowired
  private DistributedLockHandler distributedLockHandler;

  @Autowired
  private RunService runService;

  @Log(operate = "自动跑批生成科目数据")
  public void runBatchTask() {
    boolean lock = distributedLockHandler
        .tryLock(AE_DATA_RUNNING_KEY + ThreadContextHolder.getTenant().getTenantCode(),
            AE_DATA_RUNNING_VALUE + ThreadContextHolder.getTenant().getTenantCode());
    if (lock) {
      try {
        runTask();
      } catch (Exception e) {
        e.printStackTrace();
      } finally {
        // 使用完释放锁
        distributedLockHandler
            .releaseLock(AE_DATA_RUNNING_KEY + ThreadContextHolder.getTenant().getTenantCode());
      }
    }
  }

  public void runTask() {
    String aeBatchId = null;
    try {
      List<AeSourceBatch> aeSourceBatchList = aeSourceBatchService
          .list(new LambdaQueryWrapper<AeSourceBatch>()
              .eq(AeSourceBatch::getAeStatus, "TO_DO"));
      if (aeSourceBatchList != null && aeSourceBatchList.size() > 0) {
        AeSourceBatch aeSourceBatch = aeSourceBatchList.get(0);
        aeBatchId = aeSourceBatch.getAeBatchId();
        if (aeSourceBatchService
            .updateBatchStatus(aeBatchId, "TO_DO", "DOING")) {
          runService.run(aeBatchId);
        }
        aeSourceBatchService
            .updateBatchStatus(aeBatchId, "DOING", "OK");
      }
    } catch (Exception e) {
      if (aeBatchId != null) {
        aeSourceBatchService
            .updateBatchStatus(aeBatchId, "DOING", "FAIL");
      }
      e.printStackTrace();
    }
  }


}
