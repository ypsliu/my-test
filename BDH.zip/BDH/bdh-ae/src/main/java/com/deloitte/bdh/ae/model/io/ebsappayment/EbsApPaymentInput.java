package com.deloitte.bdh.ae.model.io.ebsappayment;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

/**
 * @author Ashen
 * @date 21/04/2020
 */
@Data
public class EbsApPaymentInput {

  @JSONField(name = "CREATE_PAYMENTS_Input")
  private CREATE_PAYMENTS_Input CREATE_PAYMENTS_Input;

}
