package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.AeReportTempField;
import com.deloitte.bdh.ae.model.AeReportTemplate;
import com.deloitte.bdh.common.base.Service;
import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface AeReportTempFieldService extends Service<AeReportTempField> {

  /**
   * 查询待选字段列表
   *
   * @param aeReportTemplate
   * @return
   */
  List<AeReportTempField> queryToSelectFieldList(AeReportTemplate aeReportTemplate);

  /**
   * 查询已选字段列表
   *
   * @param aeReportTemplate
   * @return
   */
  List<AeReportTempField> querySelectedFieldList(AeReportTemplate aeReportTemplate);
}
