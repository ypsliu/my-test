package com.deloitte.bdh.common.util;

import com.deloitte.bdh.common.constant.LanguageConstant;
import com.deloitte.bdh.common.context.ThreadContextHolder;
import com.deloitte.bdh.common.exception.BizException;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * 语言国际化
 *
 * @author pengdh
 * @date 2018/10/11
 */
public class MessageUtil {

  /**
   * @param key  对应 MESSAGE 配置的 KEY.
   * @param lang 语言标识
   * @return String
   */
  public static String getMessage(String key, String lang) {
    try {
      if (LanguageConstant.CN.getLanguage().equals(lang)) {
        ResourceBundle bundle = ResourceBundle.getBundle("messages_zh_CN");
        return bundle.getString(key);
      } else {
        ResourceBundle bundle = ResourceBundle.getBundle("messages_en_US");
        return bundle.getString(key);
      }
    } catch (MissingResourceException e) {
      return null;
    }
  }

  public static String getMessage(String key) {
    String lang = ThreadContextHolder.getLang();
    if (StringUtil.isEmpty(lang)) {
      throw new BizException("获取当前的语言参数失败");
    }
    try {
      if (LanguageConstant.CN.getLanguage().equals(lang)) {
        ResourceBundle bundle = ResourceBundle.getBundle("messages_zh_CN");
        return bundle.getString(key);
      } else {
        ResourceBundle bundle = ResourceBundle.getBundle("messages_en_US");
        return bundle.getString(key);
      }
    } catch (MissingResourceException e) {
      return null;
    }
  }
}
