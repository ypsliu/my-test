package com.deloitte.bdh.ae.controller;

import com.deloitte.bdh.ae.model.io.OneDataInput;
import com.deloitte.bdh.ae.model.io.payment.PaymentDataInput;
import com.deloitte.bdh.ae.model.io.payment.PaymentDataOutput;
import com.deloitte.bdh.ae.model.io.target.TargetDataOutput;
import com.deloitte.bdh.ae.service.SourcePaymentHeadService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author dahpeng
 * @Description: SourcePaymentLineController类
 * @date 2020/03/25 15:27
 */
@RestController
@Api(tags = "数据同步:支付数据")
@RequestMapping("/aeDataPayment")
public class AeDataPaymentController {

  @Autowired
  private SourcePaymentHeadService sourcePaymentHeadService;

  /**
   * @Description: 接口数据
   * @Reutrn
   */
  @PostMapping("putData")
  @ApiOperation(value = "支付数据同步接口")
  public PaymentDataOutput putData(
      @RequestBody PaymentDataInput paymentDataInput) {
    try {
      PaymentDataOutput paymentDataOutput = sourcePaymentHeadService.putData(paymentDataInput);
      return paymentDataOutput;
    } catch (Exception e) {
      e.printStackTrace();
      PaymentDataOutput paymentDataOutput = new PaymentDataOutput();
      paymentDataOutput.setStatus("FAIL");
      paymentDataOutput.setMessage("同步数据失败：" + e.getMessage());
      return paymentDataOutput;
    }
  }

  /**
   * @Description: 接口数据
   * @Reutrn
   */
  @PostMapping("getTargetDate")
  @ApiOperation(value = "获取最终的科目信息")
  public TargetDataOutput getTargetDate(
      @RequestBody OneDataInput oneDataInput) {
    try {
      TargetDataOutput targetDataOutput = sourcePaymentHeadService.getTargetDate(oneDataInput);
      return targetDataOutput;
    } catch (Exception e) {
      e.printStackTrace();
      TargetDataOutput targetDataOutput = new TargetDataOutput();
      targetDataOutput.setStatus("FAIL");
      targetDataOutput.setMessage("查询目标数据：" + e.getMessage());
      return targetDataOutput;
    }
  }

}