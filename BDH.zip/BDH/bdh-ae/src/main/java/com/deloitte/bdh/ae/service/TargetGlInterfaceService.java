package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.AeTarget;
import com.deloitte.bdh.ae.model.TargetGlInterface;
import com.deloitte.bdh.ae.model.dto.SourceQueryDto;
import com.deloitte.bdh.ae.model.io.ebsgl.P_PROCESS_DATA_DEL_ITEM;
import com.deloitte.bdh.ae.model.io.target.TargetDataHeadOutput;
import com.deloitte.bdh.ae.model.io.target.TargetDataLineOutput;
import com.deloitte.bdh.ae.model.io.target.TargetSegmentDetail;
import com.deloitte.bdh.ae.model.vo.DocumentVo;
import com.deloitte.bdh.ae.model.vo.TargetAccountVo;
import com.deloitte.bdh.common.base.Service;
import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface TargetGlInterfaceService extends Service<TargetGlInterface> {

  /**
   * 查询账务信息
   */
  List<TargetAccountVo> queryAccountingByParam(String sourceBatchId, String sourceHeadId,
      String applicationCode, String lang);

  /**
   * 查询单据信息
   */
  List<DocumentVo> queryDocumentBySql(String sql);

  /**
   * 导出账务信息
   */
  List<TargetAccountVo> exportAccountingByParam(List<String> batchList,
      String type, String applicationCode, String lang);

  /**
   * 更新目标数据中EBS的总账信息
   *
   * @param aeBatchId
   * @param sourceHeadId
   * @param sourceLineId
   * @param aeRowId
   * @param aeEbsHeadId
   * @param aeEbsLineOrder
   * @param aeEbsNumber
   */
  void updateTarget(String aeBatchId, String sourceHeadId, String sourceLineId, String aeRowId,
      String aeEbsHeadId,
      String aeEbsLineOrder, String aeEbsNumber);

  /**
   * 查询单据的凭证头信息
   *
   * @param aeBatchId
   * @param sourceHeadId
   * @return
   */
  List<TargetDataHeadOutput> queryTargetHeadList(String aeBatchId, String sourceHeadId);

  /**
   * 查询单据的凭证行信息
   *
   * @param aeBatchId
   * @param sourceHeadId
   * @return
   */
  List<TargetDataLineOutput> queryTargetLineList(String aeBatchId, String sourceHeadId);

  /**
   * 删除批次的目标总账数据
   *
   * @param aeBatchId
   */
  void deleteTargetByBatchId(String aeBatchId);

  /**
   * 查询单据行的目标段信息
   *
   * @param queryDtoList
   * @param aeTargetList
   * @return
   */
  List<TargetSegmentDetail> queryTargetSegmentList(List<SourceQueryDto> queryDtoList,
      List<AeTarget> aeTargetList);

  List<P_PROCESS_DATA_DEL_ITEM> queryGlItem(String aeBatchId);
}
