package com.deloitte.bdh.common.config;

import com.baomidou.dynamic.datasource.DynamicRoutingDataSource;
import com.baomidou.dynamic.datasource.provider.DynamicDataSourceProvider;
import com.baomidou.dynamic.datasource.spring.boot.autoconfigure.DynamicDataSourceProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author Ashen
 * @date 04/08/2020
 */
@Configuration
@EnableConfigurationProperties({DynamicDataSourceProperties.class})
public class DataSourceConfig {

  private final DynamicDataSourceProperties properties;

  public DataSourceConfig(DynamicDataSourceProperties properties) {
    this.properties = properties;
  }

  @RefreshScope
  @Bean("dataSource")
  public DynamicRoutingDataSource dataSource(DynamicDataSourceProvider dynamicDataSourceProvider) {
    DynamicRoutingDataSource dataSource = new DynamicRoutingDataSource();
    dataSource.setPrimary(this.properties.getPrimary());
    dataSource.setStrict(this.properties.getStrict());
    dataSource.setStrategy(this.properties.getStrategy());
    dataSource.setProvider(dynamicDataSourceProvider);
    dataSource.setP6spy(this.properties.getP6spy());
    dataSource.setSeata(this.properties.getSeata());
    return dataSource;
  }
}
