package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "SourceApInvoiceLine对象", description = "")
public class SourceApInvoiceLine extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableField("LINE_ID")
  private String lineId;

  @TableField("AP_INVOICE_HEADER_ID")
  private String apInvoiceHeaderId;

  @TableField("PO_HEADER_ID")
  private String poHeaderId;

  @TableField("PO_LINE_ID")
  private String poLineId;

  @TableField("DELIVER_HEADER_ID")
  private String deliverHeaderId;

  @TableField("DELIVER_LINE_ID")
  private String deliverLineId;

  @TableField("QUANTITY")
  private BigDecimal quantity;

  @TableField("UNIT_PRICE")
  private BigDecimal unitPrice;

  @TableField("PO_NUMBER")
  private String poNumber;

  @TableField("TAX_CODE")
  private String taxCode;

  @TableField("STARD_TAX_IN_AMOUNT")
  private BigDecimal stardTaxInAmount;

  @TableField("STARD_TAX_FREE_AMOUNT")
  private BigDecimal stardTaxFreeAmount;

  @TableField("STARD_TAX_AMOUNT")
  private BigDecimal stardTaxAmount;

  @TableField("ORIGL_TAX_IN_AMOUNT")
  private BigDecimal origlTaxInAmount;

  @TableField("ORIGL_TAX_FREE_AMOUNT")
  private BigDecimal origlTaxFreeAmount;

  @TableField("ORIGL_TAX_AMOUNT")
  private BigDecimal origlTaxAmount;

  @TableField("BUSINESS_CLASS_ID")
  private String businessClassId;

  @TableField("MATCH_TYPE")
  private String matchType;

  @TableField("MATCH_SUB_TYPE")
  private String matchSubType;

  @TableField("MATCH_VALUE")
  private String matchValue;

  @TableField("DELIVER_NUMBER")
  private String deliverNumber;

  @TableField("ITEM_ID")
  private String itemId;

  @TableField("AE_ROW_ID")
  private String aeRowId;

  @TableField("AE_STATUS")
  private String aeStatus;

  @TableField("SOURCE_BATCH_ID")
  private String sourceBatchId;

  @TableField("SOURCE_HEAD_ID")
  private String sourceHeadId;

  @TableField("SOURCE_LINE_ID")
  private String sourceLineId;

  @TableField("PROJECT_NUMBER")
  private String projectNumber;

  @TableField("ITEM_NUMBER")
  private String itemNumber;

  @TableField("ITEM_DESC")
  private String itemDesc;

  @TableField("EBS_ITEM_NUM")
  private String ebsItemNum;

  @TableField("CATEGORY_SEGMENT1")
  private String categorySegment1;

  @TableField("CATEGORY_SEGMENT2")
  private String categorySegment2;

  @TableField("CATEGORY_SEGMENT3")
  private String categorySegment3;

  @TableField("CATEGORY_SEGMENT1_NAME")
  private String categorySegment1Name;

  @TableField("CATEGORY_SEGMENT2_NAME")
  private String categorySegment2Name;

  @TableField("CATEGORY_SEGMENT3_NAME")
  private String categorySegment3Name;

  @TableField("BUSINESS_CLASS_NAME")
  private String businessClassName;


}
