package com.deloitte.bdh.ae.model.vo;

import java.io.Serializable;
import lombok.Data;

/**
 * 公共数据权限封装
 *
 * @author pengdh
 * @date 2018/06/25
 */
@Data
public class CompanyDataPermissionVo implements Serializable {

  private static final long serialVersionUID = 8714322000834762060L;
  private String tenantId;
  private String tenantName;
  private String organizationId;
  private String organizationName;

  private Boolean selectedFlag = false;
}
