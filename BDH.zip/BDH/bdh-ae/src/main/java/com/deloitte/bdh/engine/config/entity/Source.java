package com.deloitte.bdh.engine.config.entity;

import lombok.Data;

/**
 * @author Ashen
 * @date 12/12/2019
 */
@Data
public class Source {

  private String sourceId;

  private String tableId;

  private String displayCode;

  private String displayName;

  private String dbFunctionName;

  private String sourceType;

  private String sourceName;

  private String sourceDataType;
}
