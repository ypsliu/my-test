package com.deloitte.bdh.ae.model;

import java.math.BigDecimal;
import com.deloitte.bdh.common.base.BaseModel;
import java.time.LocalDate;
import com.baomidou.mybatisplus.annotation.TableField;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 费用报销其他行
 * </p>
 *
 * @author Ashen
 * @since 2021-03-24
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "SourceImportExpenseLine对象", description = "费用报销其他行")
public class SourceImportExpenseLine extends BaseModel {

  private static final long serialVersionUID = 1L;

  @ApiModelProperty(value = "费用大类CODE")
  @TableField("EXPENSE_ITEM_CODE")
  private String expenseItemCode;

  @ApiModelProperty(value = "费用大类名称")
  @TableField("EXPENSE_ITEM_NAME")
  private String expenseItemName;

  @ApiModelProperty(value = "费用小类CODE")
  @TableField("EXPENSE_CLASS_CODE")
  private String expenseClassCode;

  @ApiModelProperty(value = "费用小类名称")
  @TableField("EXPENSE_CLASS_NAME")
  private String expenseClassName;

  @ApiModelProperty(value = "部门编码")
  @TableField("ORGANIZATION_DEPT_CODE")
  private String organizationDeptCode;

  @ApiModelProperty(value = "部门名称")
  @TableField("ORGANIZATION_DEPT_NAME")
  private String organizationDeptName;

  @ApiModelProperty(value = "币种")
  @TableField("CURRENCY_CODE")
  private String currencyCode;

  @ApiModelProperty(value = "汇率")
  @TableField("CURRENCY_RATE")
  private BigDecimal currencyRate;

  @ApiModelProperty(value = "报销行金额")
  @TableField("LINE_AMOUNT")
  private BigDecimal lineAmount;

  @ApiModelProperty(value = "税码")
  @TableField("TAX_CODE")
  private String taxCode;

  @ApiModelProperty(value = "税率")
  @TableField("TAX_RATE")
  private BigDecimal taxRate;

  @ApiModelProperty(value = "税金额")
  @TableField("TAX_AMOUNT")
  private BigDecimal taxAmount;

  @ApiModelProperty(value = "不含税金额")
  @TableField("AMOUNT_EXCLUDE_TAX")
  private BigDecimal amountExcludeTax;

  @ApiModelProperty(value = "项目编号")
  @TableField("PROJECT_NUMBER")
  private String projectNumber;

  @ApiModelProperty(value = "项目名称")
  @TableField("PROJECT_NAME")
  private String projectName;

  @ApiModelProperty(value = "开始日期")
  @TableField("START_DATE")
  private LocalDate startDate;

  @ApiModelProperty(value = "结束日期")
  @TableField("END_DATE")
  private LocalDate endDate;

  @ApiModelProperty(value = "每日单价")
  @TableField("DAY_AMOUNT")
  private BigDecimal dayAmount;

  @ApiModelProperty(value = "城市")
  @TableField("CITY")
  private String city;

  @ApiModelProperty(value = "航班号/火车车次")
  @TableField("VEHICLE_NUMBER")
  private String vehicleNumber;

  @ApiModelProperty(value = "舱位等级/座位类型/酒店星级")
  @TableField("VEHICLE_CLASS")
  private String vehicleClass;

  @ApiModelProperty(value = "出发地")
  @TableField("FROM_LOC")
  private String fromLoc;

  @ApiModelProperty(value = "目的地")
  @TableField("TO_LOC")
  private String toLoc;

  @ApiModelProperty(value = "酒店名称")
  @TableField("HOTEL_NAME")
  private String hotelName;

  @ApiModelProperty(value = "天数")
  @TableField("DAYS")
  private BigDecimal days;

  @ApiModelProperty(value = "备注")
  @TableField("COMMENTS")
  private String comments;

  @ApiModelProperty(value = "系统字段：会计引擎ID")
  @TableField("AE_ROW_ID")
  private String aeRowId;

  @ApiModelProperty(value = "系统字段：会计引擎中的状态")
  @TableField("AE_STATUS")
  private String aeStatus;

  @ApiModelProperty(value = "系统字段：来源产品批次ID")
  @TableField("SOURCE_BATCH_ID")
  private String sourceBatchId;

  @ApiModelProperty(value = "系统字段：来源产品头ID")
  @TableField("SOURCE_HEAD_ID")
  private String sourceHeadId;

  @ApiModelProperty(value = "系统字段：来源产品行ID")
  @TableField("SOURCE_LINE_ID")
  private String sourceLineId;


}
