package com.deloitte.bdh.ae.model.io.ebsapwriteoff;

import lombok.Data;

/**
 * @author Ashen
 * @date 21/04/2020
 */
@Data
public class EbsApWriteOffOutput {

  private OutputParameters OutputParameters;
}
