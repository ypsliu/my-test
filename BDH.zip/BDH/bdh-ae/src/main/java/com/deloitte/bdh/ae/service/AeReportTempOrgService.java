package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.AeReportTempOrg;
import com.deloitte.bdh.ae.model.dto.ReportDto;
import com.deloitte.bdh.ae.model.vo.CompanyDataPermissionVo;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.Service;
import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface AeReportTempOrgService extends Service<AeReportTempOrg> {

  List<CompanyDataPermissionVo> querySelectOrganizationList(RetRequest<ReportDto> retRequest);
}
