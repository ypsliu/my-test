package com.deloitte.bdh.ae.model.io.ebsgl;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

/**
 * @author Ashen
 * @date 09/02/2021
 */
@Data
public class InputParameters {

  @JSONField(name = "P_PROCESS_BATCH_ID")
  private String P_PROCESS_BATCH_ID;

  @JSONField(name = "P_PROCESS_DATA_DEL")
  private P_PROCESS_DATA_DEL pProcessDataDel;
}
