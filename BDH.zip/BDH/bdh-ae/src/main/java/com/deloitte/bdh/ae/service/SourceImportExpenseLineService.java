package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.SourceImportExpenseLine;
import com.deloitte.bdh.common.base.Service;

/**
 * <p>
 * 费用报销其他行 服务类
 * </p>
 *
 * @author Ashen
 * @since 2021-03-24
 */
public interface SourceImportExpenseLineService extends Service<SourceImportExpenseLine> {

}
