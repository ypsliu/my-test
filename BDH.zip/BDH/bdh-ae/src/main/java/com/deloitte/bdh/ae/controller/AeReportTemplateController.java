package com.deloitte.bdh.ae.controller;

import com.deloitte.bdh.ae.model.AeReportTempField;
import com.deloitte.bdh.ae.model.AeReportTemplate;
import com.deloitte.bdh.ae.model.dto.ReportDto;
import com.deloitte.bdh.ae.model.dto.ReportRunDto;
import com.deloitte.bdh.ae.model.vo.CompanyDataPermissionVo;
import com.deloitte.bdh.ae.model.vo.HeadProperty;
import com.deloitte.bdh.ae.service.AeReportTempFieldService;
import com.deloitte.bdh.ae.service.AeReportTempOrgService;
import com.deloitte.bdh.ae.service.AeReportTemplateService;
import com.deloitte.bdh.common.base.PageHeadResult;
import com.deloitte.bdh.common.base.PageRequest;
import com.deloitte.bdh.common.base.PageResult;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.RetResponse;
import com.deloitte.bdh.common.base.RetResult;
import com.deloitte.bdh.common.exception.BizException;
import com.deloitte.bdh.common.util.DateUtils;
import com.deloitte.bdh.common.util.ExcelData;
import com.deloitte.bdh.common.util.ExcelUtil;
import com.deloitte.bdh.engine.runtime.entity.DataLine;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author dahpeng
 * @Description: AeReportTemplateController类
 * @date 2020/04/13 16:39
 */
@Api(tags = "自定义报表")
@RestController
@RequestMapping("/aeReport")
public class AeReportTemplateController {

  @Autowired
  private AeReportTemplateService aeReportTemplateService;

  @Autowired
  private AeReportTempOrgService aeReportTempOrgService;

  @Autowired
  private AeReportTempFieldService aeReportTempFieldService;

  @PostMapping("insert")
  @ApiOperation(value = "新增报表信息")
  public RetResult<Integer> insert(@RequestBody RetRequest<AeReportTemplate> retRequest) {
    aeReportTemplateService.insertData(retRequest);
    return RetResponse.makeOKRsp();
  }

  @PostMapping("update")
  @ApiOperation(value = "更新报表信息")
  public RetResult<Integer> update(@RequestBody RetRequest<AeReportTemplate> retRequest) {
    aeReportTemplateService.updateData(retRequest);
    return RetResponse.makeOKRsp();
  }

  @PostMapping("detail")
  @ApiOperation(value = "查看一个报表明细信息")
  public RetResult<AeReportTemplate> detail(@RequestBody RetRequest<ReportDto> retRequest) {
    ReportDto reportDto = retRequest.getData();
    aeReportTemplateService.checkPermission(retRequest);
    AeReportTemplate aeReportTemplate = aeReportTemplateService.getById(reportDto.getReportId());
    return RetResponse.makeOKRsp(aeReportTemplate);
  }

  @PostMapping("active")
  @ApiOperation(value = "生效失效报表")
  public RetResult<Integer> active(@RequestBody RetRequest<AeReportTemplate> retRequest) {
    AeReportTemplate aeReportTemplate = retRequest.getData();
    if (aeReportTemplate.getReportId() == null) {
      throw new BizException("参数有误！");
    }
    AeReportTemplate update = new AeReportTemplate();
    update.setReportId(aeReportTemplate.getReportId());
    if (aeReportTemplate.getActiveFlag() == null) {
      update.setActiveFlag(0);
    } else {
      update.setActiveFlag(aeReportTemplate.getActiveFlag());
    }
    aeReportTemplateService.updateById(update);
    return RetResponse.makeOKRsp();
  }

  @PostMapping("delete")
  @ApiOperation(value = "删除报表信息")
  public RetResult<Integer> deleteById(@RequestBody RetRequest<ReportDto> retRequest) {
    ReportDto reportDto = retRequest.getData();
    if (reportDto == null || reportDto.getReportId() == null) {
      throw new BizException("没有传报表ID");
    }
    aeReportTemplateService.deleteData(reportDto.getReportId());
    return RetResponse.makeOKRsp();
  }

  /**
   * @Description: 分页查询
   */
  @PostMapping("queryPage")
  @ApiOperation(value = "分页查询-报表信息")
  public RetResult<PageResult<AeReportTemplate>> queryPage(
      @RequestBody @Validated PageRequest<AeReportTemplate> pageRequest) {
    List<AeReportTemplate> list = aeReportTemplateService.selectByPage(pageRequest);
    PageInfo<AeReportTemplate> pageInfo = new PageInfo<AeReportTemplate>(list);
    PageResult pageResult = new PageResult(pageInfo);
    return RetResponse.makeOKRsp(pageResult);
  }

  /**
   * @Description: 搜索条件-报表列表
   */
  @PostMapping("queryConditionReportList")
  @ApiOperation(value = "搜索条件-报表列表")
  public RetResult<List<AeReportTemplate>> queryConditionReportList(
      @RequestBody @Validated RetRequest<AeReportTemplate> retRequest) {
    List<AeReportTemplate> list = aeReportTemplateService.queryConditionReportList(retRequest);
    return RetResponse.makeOKRsp(list);
  }


  @PostMapping("querySelectOrganizationList")
  @ApiOperation(value = "待选公司列表")
  public RetResult<List<CompanyDataPermissionVo>> querySelectOrganizationList(
      @RequestBody @Validated RetRequest<ReportDto> retRequest) {
    List<CompanyDataPermissionVo> organizationList = aeReportTempOrgService
        .querySelectOrganizationList(retRequest);
    return RetResponse.makeOKRsp(organizationList);
  }


  @PostMapping("queryToSelectFieldList")
  @ApiOperation(value = "待选字段列表")
  public RetResult<List<AeReportTempField>> queryToSelectFieldList(
      @RequestBody @Validated RetRequest<AeReportTemplate> retRequest) {
    List<AeReportTempField> fieldList = aeReportTempFieldService
        .queryToSelectFieldList(retRequest.getData());
    return RetResponse.makeOKRsp(fieldList);
  }

  @PostMapping("querySelectedFieldList")
  @ApiOperation(value = "已选字段列表")
  public RetResult<List<AeReportTempField>> querySelectedFieldList(
      @RequestBody @Validated RetRequest<AeReportTemplate> retRequest) {
    List<AeReportTempField> fieldList = aeReportTempFieldService
        .querySelectedFieldList(retRequest.getData());
    return RetResponse.makeOKRsp(fieldList);
  }


  @PostMapping("reportResult")
  @ApiOperation(value = "运行报表结果")
  public RetResult<PageHeadResult<DataLine>> reportResult(
      @RequestBody @Validated PageRequest<ReportRunDto> pageRequest) {
    PageHeadResult<DataLine> pageHeadResult = aeReportTemplateService
        .reportResult(pageRequest);
    return RetResponse.makeOKRsp(pageHeadResult);
  }

  @PostMapping("reportResult/export")
  @ApiOperation(value = "导出报表结果")
  public void reportResultExport(
      @RequestBody @Validated RetRequest<ReportRunDto> retRequest,
      HttpServletResponse response) throws Exception {
    ReportRunDto reportRunDto = retRequest.getData();
    PageHeadResult<DataLine> pageHeadResult = aeReportTemplateService
        .reportResultExport(reportRunDto);
    ExcelData excelData = new ExcelData();
    List<String> titles = pageHeadResult.getHeadList().stream().map(HeadProperty::getName).collect(
        Collectors.toList());
    excelData.setTitles(titles);
    List<List<Object>> rows = new ArrayList();
    pageHeadResult.getList().stream().forEach(dataLine -> {
      List<Object> row = convertData(dataLine, pageHeadResult.getHeadList());
      rows.add(row);
    });
    excelData.setRows(rows);
    ExcelUtil.exportExcel(response, "文件名", excelData);
  }

  private List<Object> convertData(DataLine dataLine, List<HeadProperty> headList) {
    List<Object> dataList = new ArrayList<>();
    headList.forEach(headProperty -> {
      Object value = dataLine.get(headProperty.getProperty());
      if (value != null && value instanceof Date) {
        value = DateUtils.formatShortSlashDateTime((Date) value);
      }
      dataList.add(value);
    });
    return dataList;
  }

}