package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.deloitte.bdh.ae.dao.ps.PsSalaryMapper;
import com.deloitte.bdh.ae.model.SourcePsSalaryHead;
import com.deloitte.bdh.ae.model.SourcePsSalaryLine;
import com.deloitte.bdh.ae.service.PsSalaryService;
import com.deloitte.bdh.common.constant.DSConstant;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Ashen
 * @date 08/02/2021
 */
@Service
@DS(DSConstant.PS_DB)
@Transactional(propagation = Propagation.NOT_SUPPORTED)
public class PsSalaryServiceImpl implements PsSalaryService {

  @Resource
  private PsSalaryMapper psSalaryMapper;

  @Override
  public List<SourcePsSalaryHead> selectHeadDataFromPs(String psCompanyId, String period,
      String version) {
    return psSalaryMapper.selectHeadDataFromPs(psCompanyId, period, version);
  }

  @Override
  public List<SourcePsSalaryLine> selectLineDataFromPs(String psCompanyId, String period,
      String version) {
    return psSalaryMapper.selectLineDataFromPs(psCompanyId, period, version);
  }

  @Override
  public SourcePsSalaryLine selectOneDataMaxVersionFromPs(String psCompanyId, String period) {
    return psSalaryMapper.selectOneDataMaxVersionFromPs(psCompanyId, period);
  }
}
