package com.deloitte.bdh.ae.dao.ae;

import com.deloitte.bdh.ae.model.SourceImportPaymentLine;
import com.deloitte.bdh.common.base.Mapper;

/**
 * <p>
 * 借款付款行信息 Mapper 接口
 * </p>
 *
 * @author Ashen
 * @since 2021-03-24
 */
public interface SourceImportPaymentLineMapper extends Mapper<SourceImportPaymentLine> {

}
