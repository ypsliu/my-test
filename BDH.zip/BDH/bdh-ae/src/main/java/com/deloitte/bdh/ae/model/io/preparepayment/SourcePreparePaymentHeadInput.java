package com.deloitte.bdh.ae.model.io.preparepayment;

import com.deloitte.bdh.ae.model.SourcePreparePaymentHead;

/**
 * @author Ashen
 * @date 20/04/2020
 */
public class SourcePreparePaymentHeadInput extends SourcePreparePaymentHead {

}
