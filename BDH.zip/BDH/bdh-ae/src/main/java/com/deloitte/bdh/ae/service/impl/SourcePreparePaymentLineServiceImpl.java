package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.deloitte.bdh.ae.dao.ae.SourcePreparePaymentLineMapper;
import com.deloitte.bdh.ae.model.AeSourceBatch;
import com.deloitte.bdh.ae.model.SourcePreparePaymentLine;
import com.deloitte.bdh.ae.model.TargetApInterface;
import com.deloitte.bdh.ae.model.io.DataOutput;
import com.deloitte.bdh.ae.model.io.OneDataInput;
import com.deloitte.bdh.ae.model.io.preparepayment.PreparePaymentDataInput;
import com.deloitte.bdh.ae.model.io.preparepayment.SourcePreparePaymentHeadInput;
import com.deloitte.bdh.ae.model.io.preparepayment.SourcePreparePaymentLineInput;
import com.deloitte.bdh.ae.model.io.target.TargetDataOutput;
import com.deloitte.bdh.ae.properties.ApplicationCodeProperties;
import com.deloitte.bdh.ae.service.AeSourceBatchService;
import com.deloitte.bdh.ae.service.AeTenantMethodService;
import com.deloitte.bdh.ae.service.SourcePreparePaymentHeadService;
import com.deloitte.bdh.ae.service.SourcePreparePaymentLineService;
import com.deloitte.bdh.ae.service.TargetApInterfaceService;
import com.deloitte.bdh.common.base.ServiceTransactionalImpl;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.common.exception.BizException;
import java.util.List;
import javax.annotation.Resource;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Service
@DS(DSConstant.AE_DB)
public class SourcePreparePaymentLineServiceImpl extends
    ServiceTransactionalImpl<SourcePreparePaymentLineMapper, SourcePreparePaymentLine> implements
    SourcePreparePaymentLineService {

  @Autowired
  private AeTenantMethodService aeTenantMethodService;

  @Autowired
  private ApplicationCodeProperties applicationCodeProperties;

  @Autowired
  private AeSourceBatchService aeSourceBatchService;

  @Resource
  private SourcePreparePaymentHeadService sourcePreparePaymentHeadService;

  @Resource
  private SourcePreparePaymentLineService sourcePreparePaymentLineService;

  @Resource
  private TargetApInterfaceService targetApInterfaceService;


  @Override
  @Transactional(rollbackFor = Exception.class)
  public DataOutput putData(PreparePaymentDataInput preparePaymentDataInput) {
    aeTenantMethodService
        .verifyTenantApplication(preparePaymentDataInput.getTenantId(),
            preparePaymentDataInput.getApplicationCode(),
            applicationCodeProperties.getApplicationCodeScmPreparePayment());
    DataOutput dataOutput = new DataOutput();
    if (preparePaymentDataInput == null || preparePaymentDataInput.getHeadList() == null
        || preparePaymentDataInput.getHeadList().size() == 0) {
      throw new BizException("头信息不能为空");
    }
    if (preparePaymentDataInput.getLineList() == null
        || preparePaymentDataInput.getLineList().size() == 0) {
      throw new BizException("行信息不能为空");
    }
    String aeBatchCode = aeSourceBatchService.selectAeBatchCode();
    String aeBatchId = this.getSequence();
    insertHeadList(preparePaymentDataInput.getHeadList(), aeBatchId);
    insertLineList(preparePaymentDataInput.getLineList(), aeBatchId);
    AeSourceBatch aeSourceBatch = new AeSourceBatch();
    aeSourceBatch.setAeBatchId(aeBatchId);
    aeSourceBatch.setSourceBatchId(aeBatchId);
    aeSourceBatch.setActiveFlag(1);
    aeSourceBatch.setApplicationCode(preparePaymentDataInput.getApplicationCode());
    aeSourceBatch.setTenantId(preparePaymentDataInput.getTenantId());
    aeSourceBatch.setOrganizationId(preparePaymentDataInput.getOrganizationId());
    aeSourceBatch.setAeBatchCode(aeBatchCode);
    aeSourceBatchService.save(aeSourceBatch);
    dataOutput.setAeBatchId(aeBatchId);
    dataOutput.setMessage("成功");
    dataOutput.setStatus("OK");
    return dataOutput;
  }

  private void insertHeadList(List<SourcePreparePaymentHeadInput> headList, String aeBatchId) {
    headList.forEach(sourcePreparePaymentHeadInput -> {
      sourcePreparePaymentHeadInput.setSourceBatchId(aeBatchId);
      if (Strings.isEmpty(sourcePreparePaymentHeadInput.getSourceHeadId())) {
        throw new BizException("来源头ID不能为空");
      }
      sourcePreparePaymentHeadService.save(sourcePreparePaymentHeadInput);
    });
  }

  private void insertLineList(List<SourcePreparePaymentLineInput> lineList, String aeBatchId) {
    lineList.forEach(sourcePreparePaymentLineInput -> {
      sourcePreparePaymentLineInput.setSourceBatchId(aeBatchId);
      if (Strings.isEmpty(sourcePreparePaymentLineInput.getSourceHeadId())) {
        throw new BizException("来源头ID不能为空");
      }
      if (Strings.isEmpty(sourcePreparePaymentLineInput.getSourceLineId())) {
        throw new BizException("来源行ID不能为空");
      }
      sourcePreparePaymentLineService.save(sourcePreparePaymentLineInput);
    });
  }

  @Override
  public DataOutput revertData(OneDataInput oneDataInput) {
    return null;
  }

  @Override
  public TargetDataOutput getTargetDate(OneDataInput oneDataInput) {
    TargetDataOutput targetDataOutput = new TargetDataOutput();
    AeSourceBatch aeSourceBatch = aeSourceBatchService.getById(oneDataInput.getAeBatchId());
    if (aeSourceBatch == null) {
      throw new BizException("查询批次信息失败！");
    }
    if (!"OK".equals(aeSourceBatch.getEbsStatus())) {
      throw new BizException("目标数据还在生成中...");
    }
    //查询该批次该头ID的目标数据量
    Integer targetCount = targetApInterfaceService.count(new LambdaQueryWrapper<TargetApInterface>()
        .eq(TargetApInterface::getAeBatchId, oneDataInput.getAeBatchId())
        .eq(TargetApInterface::getSourceHeadId, oneDataInput.getSourceHeadId()));
    if (targetCount == null || targetCount == 0) {
      throw new BizException("没查询到生成的目标数据");
    }
    targetDataOutput.setStatus("OK");
    return targetDataOutput;
  }
}
