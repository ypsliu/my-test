package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.deloitte.bdh.ae.model.AeApplication;
import com.deloitte.bdh.ae.model.AeSourceBatch;
import com.deloitte.bdh.ae.model.AeTarget;
import com.deloitte.bdh.ae.model.dto.SourceQueryDto;
import com.deloitte.bdh.ae.model.io.segment.SourceDetail;
import com.deloitte.bdh.ae.model.io.segment.SourceInput;
import com.deloitte.bdh.ae.model.io.segment.SourceOutput;
import com.deloitte.bdh.ae.model.io.target.TargetSegmentDetail;
import com.deloitte.bdh.ae.service.AeApplicationService;
import com.deloitte.bdh.ae.service.AeSegmentService;
import com.deloitte.bdh.ae.service.AeSourceBatchService;
import com.deloitte.bdh.ae.service.AeTargetService;
import com.deloitte.bdh.ae.service.TargetGlInterfaceService;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.common.exception.BizException;
import com.deloitte.bdh.engine.properties.AeProperties;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.annotation.Resource;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Ashen
 * @date 24/04/2020
 */
@Service
@DS(DSConstant.AE_DB)
@Transactional(rollbackFor = Exception.class)
public class AeSegmentServiceImpl implements AeSegmentService {

  @Resource
  private AeSourceBatchService aeSourceBatchService;

  @Resource
  private TargetGlInterfaceService targetGlInterfaceService;

  @Resource
  private AeApplicationService aeApplicationService;

  @Resource
  private AeTargetService aeTargetService;

  @Autowired
  private AeProperties aeProperties;

  @Override
  public SourceOutput getSegment(SourceInput sourceInput) {
    SourceOutput sourceOutput = new SourceOutput();
    List<SourceDetail> sourceDetailList = sourceInput.getList();
    if (sourceInput == null || sourceDetailList == null || sourceDetailList.size() == 0) {
      throw new BizException("来源信息不能为空");
    }
    Set<String> aeBatchIdSet = sourceDetailList.stream().map(SourceDetail::getAeBatchId)
        .collect(Collectors.toSet());
    if (aeBatchIdSet.size() == 0) {
      throw new BizException("来源批次信息不能为空");
    }
    List<AeSourceBatch> sourceBatchList = aeSourceBatchService
        .list(new LambdaQueryWrapper<AeSourceBatch>()
            .in(AeSourceBatch::getAeBatchId, aeBatchIdSet));
    Map<String, AeSourceBatch> batchMap = sourceBatchList.stream()
        .collect(Collectors.toMap(AeSourceBatch::getAeBatchId, Function.identity()));
    List<String> aeApplicationCodeList = sourceBatchList.stream()
        .map(AeSourceBatch::getApplicationCode).collect(Collectors.toList());
    if (aeApplicationCodeList.size() == 0) {
      throw new BizException("来源应用产品信息不能为空");
    }
    List<AeApplication> aeApplicationList = aeApplicationService
        .list(new LambdaQueryWrapper<AeApplication>()
            .in(AeApplication::getApplicationCode, aeApplicationCodeList));
    List<String> applicationIdList = aeApplicationList.stream()
        .map(AeApplication::getApplicationId).collect(Collectors.toList());
    if (aeApplicationCodeList.size() == 0) {
      throw new BizException("来源查询的应用产品信息不能为空");
    }
    List<AeTarget> aeTargetList = aeTargetService.list(new LambdaQueryWrapper<AeTarget>()
        .in(AeTarget::getApplicationId, applicationIdList)
        .eq(AeTarget::getDisplayCode, aeProperties.getDisplayCodeFinancialExpenseType()));

    aeTargetList.forEach(aeTarget -> {
      if (aeProperties.getDisplayCodeFinancialExpenseType()
          .equalsIgnoreCase(aeTarget.getDisplayCode())) {
        aeTarget.setDisplayName(aeProperties.getValueCodeFinancialExpenseType());
      }
    });

    List<SourceQueryDto> queryDtoList = new ArrayList<>();
    sourceDetailList.forEach(sourceDetail -> {
      AeSourceBatch aeSourceBatch = batchMap.get(sourceDetail.getAeBatchId());
      if (aeSourceBatch != null && "OK".equalsIgnoreCase(aeSourceBatch.getAeStatus())) {
        queryDtoList.add(
            new SourceQueryDto(sourceDetail.getAeBatchId(), sourceDetail.getSourceHeadId(),
                sourceDetail.getSourceLineId()));
      }
    });
    if (queryDtoList.size() > 0) {
      //map 组装查询参数
      Map<String, SourceDetail> sourceDetailMap = new HashMap<>();
      sourceDetailList.forEach(sourceDetail -> {
        sourceDetailMap.put(
            sourceDetail.getAeBatchId() + "#" + sourceDetail.getSourceHeadId() + "#" + sourceDetail
                .getSourceLineId(), sourceDetail);
      });
      // 查询目标数据
      List<TargetSegmentDetail> targetSegmentDetailList = targetGlInterfaceService
          .queryTargetSegmentList(queryDtoList, aeTargetList);
      targetSegmentDetailList.forEach(targetSegmentDetail -> {
        convertSegment(targetSegmentDetail);
        SourceDetail sourceDetail = sourceDetailMap.get(
            targetSegmentDetail.getAeBatchId() + "#" + targetSegmentDetail.getSourceHeadId() + "#"
                + targetSegmentDetail.getSourceLineId());
        // 将目标数据放到查询参数对象中
        if (sourceDetail != null) {
          List<TargetSegmentDetail> detailList = sourceDetail.getTargetSegmentDetailList();
          if (detailList == null) {
            detailList = new ArrayList<>();
          }
          detailList.add(targetSegmentDetail);
          sourceDetail.setTargetSegmentDetailList(detailList);
        }
      });
    }
    sourceOutput.setList(sourceDetailList);
    return sourceOutput;
  }

  private void convertSegment(TargetSegmentDetail targetSegmentDetail) {
    String[] segmentDescriptionCh = null;
    String[] segmentDescriptionEn = null;
    if (Strings.isNotEmpty(targetSegmentDetail.getSegmentDescriptionCh())) {
      segmentDescriptionCh = targetSegmentDetail.getSegmentDescriptionCh().split(",");
    }
    if (Strings.isNotEmpty(targetSegmentDetail.getSegmentDescriptionEn())) {
      segmentDescriptionEn = targetSegmentDetail.getSegmentDescriptionEn().split(",");
    }
    targetSegmentDetail.setSegment1DescriptionCh(getOneDescription(1, segmentDescriptionCh));
    targetSegmentDetail.setSegment2DescriptionCh(getOneDescription(2, segmentDescriptionCh));
    targetSegmentDetail.setSegment3DescriptionCh(getOneDescription(3, segmentDescriptionCh));
    targetSegmentDetail.setSegment4DescriptionCh(getOneDescription(4, segmentDescriptionCh));
    targetSegmentDetail.setSegment5DescriptionCh(getOneDescription(5, segmentDescriptionCh));
    targetSegmentDetail.setSegment6DescriptionCh(getOneDescription(6, segmentDescriptionCh));
    targetSegmentDetail.setSegment7DescriptionCh(getOneDescription(7, segmentDescriptionCh));
    targetSegmentDetail.setSegment8DescriptionCh(getOneDescription(8, segmentDescriptionCh));
    targetSegmentDetail.setSegment9DescriptionCh(getOneDescription(9, segmentDescriptionCh));
    targetSegmentDetail.setSegment10DescriptionCh(getOneDescription(10, segmentDescriptionCh));
    targetSegmentDetail.setSegment11DescriptionCh(getOneDescription(11, segmentDescriptionCh));
    targetSegmentDetail.setSegment12DescriptionCh(getOneDescription(12, segmentDescriptionCh));
    targetSegmentDetail.setSegment13DescriptionCh(getOneDescription(13, segmentDescriptionCh));
    targetSegmentDetail.setSegment14DescriptionCh(getOneDescription(14, segmentDescriptionCh));
    targetSegmentDetail.setSegment1DescriptionEn(getOneDescription(1, segmentDescriptionEn));
    targetSegmentDetail.setSegment2DescriptionEn(getOneDescription(2, segmentDescriptionEn));
    targetSegmentDetail.setSegment3DescriptionEn(getOneDescription(3, segmentDescriptionEn));
    targetSegmentDetail.setSegment4DescriptionEn(getOneDescription(4, segmentDescriptionEn));
    targetSegmentDetail.setSegment5DescriptionEn(getOneDescription(5, segmentDescriptionEn));
    targetSegmentDetail.setSegment6DescriptionEn(getOneDescription(6, segmentDescriptionEn));
    targetSegmentDetail.setSegment7DescriptionEn(getOneDescription(7, segmentDescriptionEn));
    targetSegmentDetail.setSegment8DescriptionEn(getOneDescription(8, segmentDescriptionEn));
    targetSegmentDetail.setSegment9DescriptionEn(getOneDescription(9, segmentDescriptionEn));
    targetSegmentDetail.setSegment10DescriptionEn(getOneDescription(10, segmentDescriptionEn));
    targetSegmentDetail.setSegment11DescriptionEn(getOneDescription(11, segmentDescriptionEn));
    targetSegmentDetail.setSegment12DescriptionEn(getOneDescription(12, segmentDescriptionEn));
    targetSegmentDetail.setSegment13DescriptionEn(getOneDescription(13, segmentDescriptionEn));
    targetSegmentDetail.setSegment14DescriptionEn(getOneDescription(14, segmentDescriptionEn));
  }

  private String getOneDescription(int order, String[] segmentDescription) {
    if (segmentDescription != null && segmentDescription.length >= order) {
      return segmentDescription[order - 1];
    }
    return null;
  }
}
