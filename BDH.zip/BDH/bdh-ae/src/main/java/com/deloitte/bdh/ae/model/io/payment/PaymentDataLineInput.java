package com.deloitte.bdh.ae.model.io.payment;

import com.deloitte.bdh.ae.model.SourcePaymentLine;

/**
 * @author Ashen
 * @date 25/03/2020
 */
public class PaymentDataLineInput extends SourcePaymentLine {

}
