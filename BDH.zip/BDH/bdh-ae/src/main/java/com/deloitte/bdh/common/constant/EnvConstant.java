package com.deloitte.bdh.common.constant;

/**
 * 环境常量类
 *
 * @author pengdh
 * @date 2018/07/03
 */
public class EnvConstant {

  public static final String ENV_DEV = "dev";
  public static final String ENV_UAT = "uat";
  public static final String ENV_DEMO = "demo";
  public static final String ENV_PROD = "prod";

  public static final String ENV_HKTEST = "hktest";
  public static final String ENV_HKPROD = "hkprod";
}
