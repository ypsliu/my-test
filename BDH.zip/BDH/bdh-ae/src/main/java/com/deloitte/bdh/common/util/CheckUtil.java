package com.deloitte.bdh.common.util;

import com.deloitte.bdh.common.constant.CommonConstant;

/**
 * @author Ashen
 * @date 04/12/2020
 */
public class CheckUtil {

  public static boolean checkFlagY(String flagStr) {
    if (CommonConstant.Y.equals(flagStr)) {
      return true;
    }
    return false;
  }
}
