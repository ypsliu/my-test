package com.deloitte.bdh.ae.model.io.ebsapwriteoff;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

/**
 * @author Ashen
 * @date 14/07/2020
 */
@Data
public class APPLY_PREPAY_Input {

  @JSONField(name = "InputParameters")
  private InputParameters InputParameters;
}
