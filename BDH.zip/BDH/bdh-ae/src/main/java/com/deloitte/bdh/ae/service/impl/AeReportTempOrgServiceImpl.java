package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.deloitte.bdh.ae.client.FeignClientService;
import com.deloitte.bdh.ae.dao.ae.AeReportTempOrgMapper;
import com.deloitte.bdh.ae.model.AeReportTempOrg;
import com.deloitte.bdh.ae.model.dto.ReportDto;
import com.deloitte.bdh.ae.model.vo.CompanyDataPermissionVo;
import com.deloitte.bdh.ae.service.AeReportTempOrgService;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.ServiceTransactionalImpl;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.common.util.StringUtil;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Service
@DS(DSConstant.AE_DB)
public class AeReportTempOrgServiceImpl extends
    ServiceTransactionalImpl<AeReportTempOrgMapper, AeReportTempOrg> implements
    AeReportTempOrgService {

  @Autowired
  private FeignClientService feignClientService;

  @Override
  public List<CompanyDataPermissionVo> querySelectOrganizationList(
      RetRequest<ReportDto> retRequest) {
    ReportDto dto = retRequest.getData();
    // 查询授权公司列表
    List<CompanyDataPermissionVo> companyDataPermissionVoList = feignClientService
        .getUserDataPermissions();
    if (dto != null && StringUtil.isNotEmpty(dto.getReportId())) {
      List<AeReportTempOrg> orgList = this.list(new LambdaQueryWrapper<AeReportTempOrg>()
          .eq(AeReportTempOrg::getReportId, dto.getReportId()));

      Map<String, CompanyDataPermissionVo> companyMap = companyDataPermissionVoList.stream()
          .collect(Collectors.toMap(CompanyDataPermissionVo::getOrganizationId,
              Function.identity()));
      orgList.forEach(aeReportTempOrg -> {
        CompanyDataPermissionVo companyDataPermissionVo = companyMap
            .get(aeReportTempOrg.getOrganizationId());
        if (companyDataPermissionVo != null) {
          companyDataPermissionVo.setSelectedFlag(true);
        }
      });
    } else {
      //如果没有传报表ID，则为新建时查询数据；默认全选
      companyDataPermissionVoList.forEach(companyDataPermissionVo -> {
        companyDataPermissionVo.setSelectedFlag(true);
      });
    }
    return companyDataPermissionVoList;
  }
}
