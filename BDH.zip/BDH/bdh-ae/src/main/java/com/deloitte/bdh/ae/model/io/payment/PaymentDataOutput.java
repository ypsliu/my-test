package com.deloitte.bdh.ae.model.io.payment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @author Ashen
 * @date 28/02/2020
 */
@ApiModel(description = "会计引擎接口返回参数")
public class PaymentDataOutput {

  @ApiModelProperty(value = "返回状态")
  private String status;

  @ApiModelProperty(value = "返回信息")
  private String message;

  @ApiModelProperty(value = "批次信息")
  private String aeBatchId;

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public String getAeBatchId() {
    return aeBatchId;
  }

  public void setAeBatchId(String aeBatchId) {
    this.aeBatchId = aeBatchId;
  }
}
