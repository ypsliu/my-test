package com.deloitte.bdh.ae.properties;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * @author Ashen
 * @date 21/04/2020
 */
@RefreshScope
@Component
@Data
public class ApplicationCodeProperties {

  @Value("${bdh.application.code.expense}")
  private String applicationCodeExpense;

  @Value("${bdh.application.code.payment}")
  private String applicationCodePayment;

  @Value("${bdh.application.code.ps-salary}")
  private String applicationCodePsSalary;

  @Value("${bdh.application.code.scm-ap}")
  private String applicationCodeScmAp;

  @Value("${bdh.application.code.scm-ap-writeoff}")
  private String applicationCodeScmApWriteOff;

  @Value("${bdh.application.code.scm-ar}")
  private String applicationCodeScmAr;

  @Value("${bdh.application.code.scm-public-payment}")
  private String applicationCodeScmPublicPayment;

  @Value("${bdh.application.code.scm-prepare-payment}")
  private String applicationCodeScmPreparePayment;

  @Value("${bdh.application.code.import-expense}")
  private String applicationCodeImportExpense;

  @Value("${bdh.application.code.import-expense-payment}")
  private String applicationCodeImportExpensePayment;

}
