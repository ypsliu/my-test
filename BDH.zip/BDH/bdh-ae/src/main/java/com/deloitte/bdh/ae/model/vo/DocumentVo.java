package com.deloitte.bdh.ae.model.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Ashen
 * @date 20/02/2020
 */
@Data
@ApiModel(description = "单据显示信息")
public class DocumentVo {


  @ApiModelProperty(value = "单据编号")
  private String documentHeadNumber;

  @ApiModelProperty(value = "单据类型")
  private String documentHeadType;

  @ApiModelProperty(value = "备注")
  private String documentHeadDescription;

  @ApiModelProperty(value = "批次ID")
  private String aeBatchId;

  @ApiModelProperty(value = "单据ID")
  private String sourceHeadId;
}
