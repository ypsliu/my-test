package com.deloitte.bdh.ae.model.bo;

import com.deloitte.bdh.excel.annotation.ExcelColumn;
import com.deloitte.bdh.excel.annotation.ExcelModel;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.Data;

/**
 * @author Ashen
 * @date 25/11/2020
 */
@Data
@ExcelModel("AE_IMPORT_EXPENSE")
public class ExcelModelExpense {

  @ExcelColumn(title = "单据编号", order = 1, required = true)
  private String documentNumber;
  @ExcelColumn(title = "公司编码", order = 2, required = true)
  private String organizationNumber;
  @ExcelColumn(title = "公司", order = 3, required = true)
  private String organizationName;

  @ExcelColumn(title = "报销类型", order = 4, required = false)
  private String expenseReqTypeName;
  @ExcelColumn(title = "申请人", order = 5, required = false)
  private String requestUserName;
  @ExcelColumn(title = "申请日期", order = 6, required = false,formats = {"yyyy/MM/dd","yyyy-MM-dd"})
  private LocalDate requestDate;
  @ExcelColumn(title = "报销总金额（本位币）", order = 7, required = true)
  private BigDecimal totalAmount;
  @ExcelColumn(title = "说明", order = 8, required = false)
  private String expenseComments;

  @ExcelColumn(title = "费用大类编码", order = 21, required = true)
  private String expenseItemCode;
  @ExcelColumn(title = "费用大类", order = 22, required = true)
  private String expenseItemName;
  @ExcelColumn(title = "费用小类编码", order = 23, required = true)
  private String expenseClassCode;
  @ExcelColumn(title = "费用小类", order = 24, required = true)
  private String expenseClassName;
  @ExcelColumn(title = "部门编码", order = 25, required = true)
  private String organizationDeptCode;
  @ExcelColumn(title = "部门", order = 26, required = true)
  private String organizationDeptName;
  @ExcelColumn(title = "币种", order = 27, required = true)
  private String currencyCode;
  @ExcelColumn(title = "汇率", order = 28, required = true)
  private BigDecimal currencyRate;
  @ExcelColumn(title = "报销行金额", order = 29, required = true)
  private BigDecimal lineAmount;
  @ExcelColumn(title = "税率", order = 40, required = true)
  private BigDecimal taxRate;
  @ExcelColumn(title = "税金额", order = 41, required = true)
  private BigDecimal taxAmount;
  @ExcelColumn(title = "不含税金额", order = 42, required = true)
  private BigDecimal amountExcludeTax;

  @ExcelColumn(title = "项目编码", order = 43, required = false)
  private String projectNumber;
  @ExcelColumn(title = "项目编码说明", order = 44, required = false)
  private String projectName;
  @ExcelColumn(title = "开始时间", order = 44, required = false,formats = {"yyyy/MM/dd","yyyy-MM-dd"})
  private String startDate;
  @ExcelColumn(title = "结束时间", order = 45, required = false,formats = {"yyyy/MM/dd","yyyy-MM-dd"})
  private String endDate;
  @ExcelColumn(title = "每日单价", order = 46, required = false)
  private BigDecimal dayAmount;
  @ExcelColumn(title = "城市", order = 47, required = false)
  private String city;
  @ExcelColumn(title = "航班号/车次", order = 48, required = false)
  private String vehicleNumber;
  @ExcelColumn(title = "舱位等级/座位类型/酒店星级", order = 49, required = false)
  private String vehicleClass;
  @ExcelColumn(title = "出发机场/火车站", order = 60, required = false)
  private String fromLoc;
  @ExcelColumn(title = "目的机场/火车站", order = 61, required = false)
  private String toLoc;
  @ExcelColumn(title = "酒店名称", order = 62, required = false)
  private String hotelName;
  @ExcelColumn(title = "入住晚数", order = 63, required = false)
  private BigDecimal days;
  @ExcelColumn(title = "备注", order = 64, required = false)
  private String comments;
}
