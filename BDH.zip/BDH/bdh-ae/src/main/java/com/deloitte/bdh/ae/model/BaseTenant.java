package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.Data;

/**
 * <p>
 * 租户表
 * </p>
 *
 * @author Ashen
 * @since 2020-09-09
 */
@TableName("BASE_TENANT")
@Data
public class BaseTenant implements Serializable {

  private static final long serialVersionUID = 1L;

  @TableId("TENANT_ID")
  private String tenantId;

  @TableField("CH_NAME")
  private String chName;

  @TableField("EN_NAME")
  private String enName;

  @TableField("CONTACTS")
  private String contacts;

  @TableField("CONTACT_ADDRESS")
  private String contactAddress;

  @TableField("CONTACT_PHONE")
  private String contactPhone;

  @TableField("CONTACT_EMAIL")
  private String contactEmail;

  @TableField("ICON")
  private String icon;

  @TableField("INTERNAL_TENANT_FLAG")
  private Integer internalTenantFlag;

  @TableField("ACTIVE_FLAG")
  private Integer activeFlag;

  @TableField("START_DATE_ACTIVE")
  private LocalDateTime startDateActive;

  @TableField("END_DATE_ACTIVE")
  private LocalDateTime endDateActive;

  @TableField("CREATE_DATE")
  private LocalDateTime createDate;

  @TableField("CREATE_USER")
  private String createUser;

  @TableField("MODIFIED_DATE")
  private LocalDateTime modifiedDate;

  @TableField("MODIFIED_USER")
  private String modifiedUser;

  @TableField("IP")
  private String ip;

  @TableField("TENANT_CODE")
  private String tenantCode;

}
