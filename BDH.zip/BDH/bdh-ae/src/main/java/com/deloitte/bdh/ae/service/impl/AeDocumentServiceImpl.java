package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.deloitte.bdh.ae.client.FeignClientService;
import com.deloitte.bdh.ae.model.AeApplication;
import com.deloitte.bdh.ae.model.AeSource;
import com.deloitte.bdh.ae.model.AeSourceBatch;
import com.deloitte.bdh.ae.model.AeSourceLoadTable;
import com.deloitte.bdh.ae.model.dto.DocumentQueryDto;
import com.deloitte.bdh.ae.model.vo.CompanyDataPermissionVo;
import com.deloitte.bdh.ae.model.vo.DocumentVo;
import com.deloitte.bdh.ae.service.AeApplicationService;
import com.deloitte.bdh.ae.service.AeDocumentService;
import com.deloitte.bdh.ae.service.AeSourceBatchService;
import com.deloitte.bdh.ae.service.AeSourceLoadTableService;
import com.deloitte.bdh.ae.service.AeSourceService;
import com.deloitte.bdh.ae.service.LocaleMessageSourceService;
import com.deloitte.bdh.ae.service.TargetGlInterfaceService;
import com.deloitte.bdh.common.base.PageRequest;
import com.deloitte.bdh.common.base.PageResult;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.common.exception.BizException;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Resource;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Ashen
 * @date 20/02/2020
 */
@Service
@DS(DSConstant.AE_DB)
@Transactional(rollbackFor = Exception.class)
public class AeDocumentServiceImpl implements AeDocumentService {

  @Autowired
  private AeSourceBatchService aeSourceBatchService;

  @Autowired
  private AeApplicationService aeApplicationService;

  @Autowired
  private AeSourceService aeSourceService;

  @Autowired
  private AeSourceLoadTableService aeSourceLoadTableService;

  @Autowired
  private TargetGlInterfaceService targetGlInterfaceService;

  @Resource
  private LocaleMessageSourceService localeMessageSourceService;

  @Resource
  private FeignClientService feignClientService;

  @Override
  public PageResult selectByPageRequest(PageRequest<DocumentQueryDto> pageRequest) {
    AeSourceBatch aeSourceBatch = aeSourceBatchService
        .getById(pageRequest.getData().getAeBatchId());

    //权限验证
    List<CompanyDataPermissionVo> companyDataPermissionVoList = feignClientService
        .getUserDataPermissions();
    List<String> orgIdList = companyDataPermissionVoList.stream()
        .map(CompanyDataPermissionVo::getOrganizationId).collect(Collectors.toList());
    if (orgIdList.isEmpty() || !orgIdList.contains(aeSourceBatch.getOrganizationId())) {
      throw new BizException(localeMessageSourceService
          .getMessage("NO_DATA_PERMISSION", pageRequest.getLang()));
    }

    List<AeApplication> aeApplicationList = aeApplicationService
        .list(new LambdaQueryWrapper<AeApplication>()
            .eq(AeApplication::getApplicationCode, aeSourceBatch.getApplicationCode()));
    String applicationId = null;
    if (aeApplicationList.size() != 1) {
      throw new BizException("查询应用产品信息失败！");
    } else {
      applicationId = aeApplicationList.get(0).getApplicationId();
    }
    List<AeSource> sourceList = aeSourceService.list(new LambdaQueryWrapper<AeSource>()
        .eq(AeSource::getApplicationId, applicationId)
        .in(AeSource::getDisplayCode, "DOCUMENT_HEAD_NUMBER", "DOCUMENT_HEAD_TYPE",
            "DOCUMENT_HEAD_DESCRIPTION"));
    String tableId = "-1";
    Map<String, String> columnMap = new HashMap<>();
    for (int i = 0; i < sourceList.size(); i++) {
      AeSource aeSource = sourceList.get(i);
      if (!tableId.equals("-1") && !tableId.equals(aeSource.getTableId())) {
        throw new BizException("查找单据字段信息错误！");
      }
      tableId = aeSource.getTableId();
      columnMap.put(aeSource.getDisplayCode(), aeSource.getSourceName());
    }
    AeSourceLoadTable aeSourceLoadTable = aeSourceLoadTableService.getById(tableId);
    if (aeSourceLoadTable == null) {
      throw new BizException("未找到配置的单据字段信息!");
    }
    String sql = buildDocumentSql(aeSourceLoadTable.getTableName(), columnMap,
        pageRequest.getData(), aeSourceBatch.getSourceBatchId());
    PageHelper.startPage(pageRequest.getPage(), pageRequest.getSize());
    List<DocumentVo> list = targetGlInterfaceService.queryDocumentBySql(sql);
    list.forEach(documentVo -> {
      documentVo.setAeBatchId(aeSourceBatch.getAeBatchId());
    });
    PageInfo<DocumentVo> pageInfo = new PageInfo<DocumentVo>(list);
    PageResult pageResult = new PageResult(pageInfo);
    return pageResult;
  }

  private String buildDocumentSql(String tableName, Map<String, String> columnMap,
      DocumentQueryDto data, String sourceBatchId) {
    StringBuffer sql = new StringBuffer();
    sql.append(" SELECT ");
    sql.append("SOURCE_HEAD_ID as sourceHeadId,");

    String documentHeadNumber = columnMap.get("DOCUMENT_HEAD_NUMBER");
    sql.append(Strings.isEmpty(documentHeadNumber) ? "''" : documentHeadNumber);
    sql.append(" as documentHeadNumber,");

    String documentHeadType = columnMap.get("DOCUMENT_HEAD_TYPE");
    sql.append(Strings.isEmpty(documentHeadType) ? "''" : documentHeadType);
    sql.append(" as documentHeadType,");

    String documentHeadDescription = columnMap.get("DOCUMENT_HEAD_DESCRIPTION");
    sql.append(Strings.isEmpty(documentHeadDescription) ? "''" : documentHeadDescription);
    sql.append(" as documentHeadDescription ");

    sql.append(" FROM ").append(tableName);
    sql.append(" WHERE SOURCE_BATCH_ID ='").append(sourceBatchId).append("' ");
    if (Strings.isNotEmpty(data.getDocumentHeadNumber())) {
      String column = columnMap.get("DOCUMENT_HEAD_NUMBER");
      if (Strings.isNotEmpty(column)) {
        sql.append(" AND ").append(column).append(" like CONCAT('%' , '")
            .append(data.getDocumentHeadNumber())
            .append("', '%' ) ");
      }
    }
    if (Strings.isNotEmpty(data.getDocumentHeadType())) {
      String column = columnMap.get("DOCUMENT_HEAD_TYPE");
      if (Strings.isNotEmpty(column)) {
        sql.append(" AND ").append(column).append(" = '").append(data.getDocumentHeadType())
            .append("' ");
      }
    }
    return sql.toString();
  }
}
