package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "SourceExpenseHead对象", description = "")
public class SourceExpenseHead extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableField("EXPENSE_REQ_HEADER_ID")
  private String expenseReqHeaderId;

  @TableField("TRAVEL_REQ_HEADER_ID")
  private String travelReqHeaderId;

  @TableField("ORGANIZATION_ID")
  private String organizationId;

  @TableField("ORGANIZATION_DEPT_ID")
  private String organizationDeptId;

  @TableField("DOCUMENT_NUMBER")
  private String documentNumber;

  @TableField("REQUEST_USER_ID")
  private String requestUserId;

  @TableField("REQUEST_DATE")
  private LocalDate requestDate;

  @TableField("EXPENSE_PURPOSES")
  private String expensePurposes;

  @TableField("ATTACHMENT_NUMBER")
  private BigDecimal attachmentNumber;

  @TableField("STATUS_CODE")
  private String statusCode;

  @TableField("GL_DATE")
  private LocalDateTime glDate;

  @TableField("PROCESS_DATE")
  private LocalDateTime processDate;

  @TableField("PROCESS_MESSAGE")
  private String processMessage;

  @TableField("COMMENTS")
  private String comments;

  @TableField("WF_COMMENTS")
  private String wfComments;

  @TableField("WF_ITEM_TYPE")
  private String wfItemType;

  @TableField("WF_ITEM_KEY")
  private String wfItemKey;

  @TableField("WF_TASK_ID")
  private String wfTaskId;

  @TableField("TENANT_ID")
  private String tenantId;

  @TableField("CURRENCY_CODE")
  private String currencyCode;

  @TableField("EXPENSE_REQ_TYPE")
  private String expenseReqType;

  @TableField("ACTIVE_FLAG")
  private BigDecimal activeFlag;

  @TableField("TOTAL_AMOUNT")
  private BigDecimal totalAmount;

  @TableField("PAY_WAY")
  private BigDecimal payWay;

  @TableField("TOTAL_ACTUAL_AMOUNT")
  private BigDecimal totalActualAmount;

  @TableField("LEDGER_STATUS")
  private BigDecimal ledgerStatus;

  @TableField("FINANCIAL_AUDIT")
  private LocalDate financialAudit;

  @TableField("PAY_FINISH")
  private LocalDateTime payFinish;

  @TableField("BANK_ACCOUNT_ID")
  private String bankAccountId;

  @TableField("ACTION_TYPE")
  private String actionType;

  @TableField("PAYMENT_TOTAL_AMOUNT")
  private BigDecimal paymentTotalAmount;

  @TableField("RECEIVABLE_TOTAL_AMOUNT")
  private BigDecimal receivableTotalAmount;

  @TableField("STATUS_VERSION")
  private BigDecimal statusVersion;

  @TableField("ALERT_INFO")
  private String alertInfo;

  @TableField("REIM_USER")
  private BigDecimal reimUser;

  @TableField("FINANCE_STATUS")
  private BigDecimal financeStatus;

  @TableField("PAYMENT_STATUS")
  private BigDecimal paymentStatus;

  @TableField("PROC_ID")
  private String procId;

  @TableField("AE_ROW_ID")
  private String aeRowId;

  @TableField("AE_STATUS")
  private String aeStatus;

  @TableField("SOURCE_BATCH_ID")
  private String sourceBatchId;

  @TableField("SOURCE_HEAD_ID")
  private String sourceHeadId;

  @TableField("PREPARED_USER")
  private BigDecimal preparedUser;

  @TableField("TENANT_NAME")
  private String tenantName;

  @TableField("ORGANIZATION_NAME")
  private String organizationName;

  @TableField("ORGANIZATION_DEPT_NAME")
  private String organizationDeptName;

  @TableField("WF_ITEM_TYPE_NAME_CH")
  private String wfItemTypeNameCh;

  @TableField("WF_ITEM_TYPE_NAME_EN")
  private String wfItemTypeNameEn;

  @TableField("REQUEST_USER_NAME")
  private String requestUserName;

  @TableField("REQUEST_EMPLOYEE_ID")
  private String requestEmployeeId;

  @TableField("REQUEST_EMPLOYEE_NAME_CH")
  private String requestEmployeeNameCh;

  @TableField("REQUEST_EMPLOYEE_NAME_EN")
  private String requestEmployeeNameEn;


}
