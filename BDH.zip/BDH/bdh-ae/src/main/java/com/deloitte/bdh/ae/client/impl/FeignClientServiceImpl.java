package com.deloitte.bdh.ae.client.impl;

import com.deloitte.bdh.ae.client.BiDataCompanySystemClient;
import com.deloitte.bdh.ae.client.CompanyPermissionClient;
import com.deloitte.bdh.ae.client.EnumValueClient;
import com.deloitte.bdh.ae.client.FeignClientService;
import com.deloitte.bdh.ae.client.LanguageClient;
import com.deloitte.bdh.ae.client.OrganizationClient;
import com.deloitte.bdh.ae.client.UserClient;
import com.deloitte.bdh.ae.client.dto.BaseEnumValueDto;
import com.deloitte.bdh.ae.client.dto.CompanyDepartmentDto;
import com.deloitte.bdh.ae.client.dto.FndPortalOrganizationDto;
import com.deloitte.bdh.ae.client.model.FndPortalLanguage;
import com.deloitte.bdh.ae.client.vo.BiDataCompanySystemVo;
import com.deloitte.bdh.ae.client.vo.OrganizationClientVo;
import com.deloitte.bdh.ae.model.vo.CompanyDataPermissionVo;
import com.deloitte.bdh.ae.model.vo.EnumValueVo;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.RetResult;
import com.deloitte.bdh.common.properties.RedisKeyProperties;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

/**
 * @author Ashen
 * @date 30/11/2020
 */
@Service
public class FeignClientServiceImpl implements FeignClientService {

  @Autowired
  private OrganizationClient organizationClient;

  @Autowired
  private EnumValueClient enumValueClient;

  @Autowired
  private CompanyPermissionClient companyPermissionClient;

  @Autowired
  private UserClient userClient;

  @Autowired
  private LanguageClient languageClient;

  @Autowired
  private BiDataCompanySystemClient biDataCompanySystemClient;


  @Override
  @Cacheable(value = RedisKeyProperties.FEIGN_DLA_PREFIX
      + "getCompanyList", keyGenerator = "feignKeyGenerator")
  public List<OrganizationClientVo> getTenantCompanyList() {
    RetRequest<Void> retRequest = createRetRequest(null);
    RetResult<List<OrganizationClientVo>> retResult = organizationClient
        .getTenantCompanyList(retRequest);
    return retResult.getData();
  }

  @Override
  @Cacheable(value = RedisKeyProperties.FEIGN_DLA_PREFIX
      + "getPortalEnumValueList", keyGenerator = "feignKeyGenerator")
  public List<EnumValueVo> getPortalEnumValueList(String code) {
    BaseEnumValueDto baseEnumValueDto = new BaseEnumValueDto();
    baseEnumValueDto.setCode(code);
    RetRequest<BaseEnumValueDto> retRequest = createRetRequest(baseEnumValueDto);
    RetResult<List<EnumValueVo>> retResult = enumValueClient
        .getPortalEnumValueList(retRequest);
    return retResult.getData();
  }


  @Override
  @Cacheable(value = RedisKeyProperties.FEIGN_DLA_PREFIX
      + "getSystemEnumValueList", keyGenerator = "feignKeyGenerator")
  public List<EnumValueVo> getSystemEnumValueList(String code) {
    BaseEnumValueDto baseEnumValueDto = new BaseEnumValueDto();
    baseEnumValueDto.setCode(code);
    RetRequest<BaseEnumValueDto> retRequest = createRetRequest(baseEnumValueDto);
    RetResult<List<EnumValueVo>> retResult = enumValueClient
        .getSystemEnumValueList(retRequest);
    return retResult.getData();
  }

  @Override
  public List<CompanyDataPermissionVo> getUserDataPermissions() {
    RetRequest<Void> retRequest = createRetRequest(null);
    RetResult<List<CompanyDataPermissionVo>> retResult = companyPermissionClient
        .getUserDataPermissions(retRequest);
    return retResult.getData();
  }

  @Override
  public Map<String, String> getUserNameMapByIdSet(Set<String> userIdSet) {
    RetRequest<Set<String>> retRequest = createRetRequest(userIdSet);
    RetResult<Map<String, String>> retResult = userClient.queryUserNameMapByIdSet(retRequest);
    return retResult.getData();
  }

  @Override
  @Cacheable(value = RedisKeyProperties.FEIGN_DLA_PREFIX
      + "getLanguageList", keyGenerator = "feignKeyGenerator")
  public List<FndPortalLanguage> getLanguageList() {
    RetRequest<Void> retRequest = createRetRequest(null);
    RetResult<List<FndPortalLanguage>> retResult = languageClient
        .getLanguageList(retRequest);
    return retResult.getData();
  }

  @Override
  public List<BiDataCompanySystemVo> getSystemByCompanyId(String organizationId) {
    CompanyDepartmentDto companyDepartmentDto = new CompanyDepartmentDto();
    companyDepartmentDto.setOrganizationId(organizationId);
    RetRequest<CompanyDepartmentDto> retRequest = createRetRequest(companyDepartmentDto);
    RetResult<List<BiDataCompanySystemVo>> retResult = biDataCompanySystemClient
        .getSystemByCompanyId(retRequest);
    return retResult.getData();
  }

  @Override
  public OrganizationClientVo selectOrganizationByCode(String organizationCode) {
    FndPortalOrganizationDto dto = new FndPortalOrganizationDto();
    dto.setOrganizationCode(organizationCode);
    RetRequest<FndPortalOrganizationDto> retRequest = createRetRequest(dto);
    RetResult<OrganizationClientVo> retResult = organizationClient.selectOneByCode(retRequest);
    return retResult.getData();
  }

  public <T> RetRequest<T> createRetRequest(T data) {
    RetRequest<T> retRequest = new RetRequest<>();
    retRequest.setData(data);
    return retRequest;
  }
}
