package com.deloitte.bdh.ae.model.io.expense;

import com.deloitte.bdh.ae.model.SourceExpenseHead;

/**
 * @author Ashen
 * @date 28/02/2020
 */
public class ExpExpenseRequestHeadersInput extends SourceExpenseHead {

}
