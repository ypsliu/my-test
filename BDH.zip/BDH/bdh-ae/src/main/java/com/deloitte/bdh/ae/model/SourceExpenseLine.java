package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "SourceExpenseLine对象", description = "")
public class SourceExpenseLine extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableField("EXPENSE_COMMON_LINE_ID")
  private String expenseCommonLineId;

  @TableField("EXPENSE_REQ_HEADER_ID")
  private String expenseReqHeaderId;

  @TableField("LINE_NUM")
  private BigDecimal lineNum;

  @TableField("TEMPLATE_TYPE")
  private BigDecimal templateType;

  @TableField("EXPENSE_TYPE")
  private String expenseType;

  @TableField("START_DATE")
  private LocalDate startDate;

  @TableField("END_DATE")
  private LocalDate endDate;

  @TableField("HOTEL_NAME")
  private String hotelName;

  @TableField("VEHICLE_NUMBER")
  private String vehicleNumber;

  @TableField("VEHICLE_CLASS")
  private String vehicleClass;

  @TableField("HOTEL_ROOM_TYPE")
  private String hotelRoomType;

  @TableField("FROM_LOC")
  private String fromLoc;

  @TableField("TO_LOC")
  private String toLoc;

  @TableField("AMOUNT")
  private BigDecimal amount;

  @TableField("SERVICE_FEE")
  private BigDecimal serviceFee;

  @TableField("FLIGHT_FEE")
  private BigDecimal flightFee;

  @TableField("CURRENCY_CODE")
  private String currencyCode;

  @TableField("EXCHANGE_RATE")
  private BigDecimal exchangeRate;

  @TableField("BASE_AMOUNT")
  private BigDecimal baseAmount;

  @TableField("TAX_CODE")
  private String taxCode;

  @TableField("TAX_RATE")
  private BigDecimal taxRate;

  @TableField("TAX_AMOUNT")
  private BigDecimal taxAmount;

  @TableField("PROJECT_NUMBER")
  private String projectNumber;

  @TableField("COMMENTS")
  private String comments;

  @TableField("TENANT_ID")
  private String tenantId;

  @TableField("ACTIVE_FLAG")
  private BigDecimal activeFlag;

  @TableField("PAY_WAY")
  private BigDecimal payWay;

  @TableField("ACTUAL_AMOUNT")
  private BigDecimal actualAmount;

  @TableField("TAX_EXCLUSIVE_AMOUNT")
  private BigDecimal taxExclusiveAmount;

  @TableField("SPECIAL_INVOICE")
  private String specialInvoice;

  @TableField("OCR_DETECT")
  private Integer ocrDetect;

  @TableField("RECOGNITION_ID")
  private String recognitionId;

  @TableField("INVOICE_GOOD_IDS")
  private String invoiceGoodIds;

  @TableField("UNIT_PRICE")
  private BigDecimal unitPrice;

  @TableField("DAYS")
  private BigDecimal days;

  @TableField("START_TIME")
  private String startTime;

  @TableField("TAG_CODES")
  private String tagCodes;

  @TableField("SLIPT_FLAG")
  private Integer sliptFlag;

  @TableField("PARENT_EXPENSE_LINE_ID")
  private String parentExpenseLineId;

  @TableField("ORGANIZATION_DEPT_ID")
  private String organizationDeptId;

  @TableField("LINE_MARK")
  private String lineMark;

  @TableField("AE_ROW_ID")
  private String aeRowId;

  @TableField("AE_STATUS")
  private String aeStatus;

  @TableField("SOURCE_BATCH_ID")
  private String sourceBatchId;

  @TableField("SOURCE_HEAD_ID")
  private String sourceHeadId;

  @TableField("SOURCE_LINE_ID")
  private String sourceLineId;

  @TableField("AREA_ID")
  private String areaId;

  @TableField("CITY")
  private String city;

  @TableField("EXPENSE_TYPE_NAME_CH")
  private String expenseTypeNameCh;

  @TableField("EXPENSE_TYPE_NAME_EN")
  private String expenseTypeNameEn;

  @TableField("EXPENSE_ITEM_NAME_CH")
  private String expenseItemNameCh;

  @TableField("EXPENSE_ITEM_NAME_EN")
  private String expenseItemNameEn;

  @TableField("PROJECT_NAME_CH")
  private String projectNameCh;

  @TableField("PROJECT_NAME_EN")
  private String projectNameEn;


}
