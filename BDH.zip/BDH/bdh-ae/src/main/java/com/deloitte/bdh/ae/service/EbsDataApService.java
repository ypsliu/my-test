package com.deloitte.bdh.ae.service;

/**
 * @author Ashen
 * @date 21/04/2020
 */
public interface EbsDataApService {

  /**
   * 推送数据到EBS Ap发票
   *
   * @param aeBatchId
   */
  void putDataToEbsAp(String aeBatchId);
}
