package com.deloitte.bdh.ae.client;

import com.deloitte.bdh.ae.client.dto.CompanyDepartmentDto;
import com.deloitte.bdh.ae.client.dto.FndPortalOrganizationDto;
import com.deloitte.bdh.ae.client.model.FndPortalLanguage;
import com.deloitte.bdh.ae.client.vo.BiDataCompanySystemVo;
import com.deloitte.bdh.ae.client.vo.OrganizationClientVo;
import com.deloitte.bdh.ae.model.vo.CompanyDataPermissionVo;
import com.deloitte.bdh.ae.model.vo.EnumValueVo;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.RetResult;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * @author Ashen
 * @date 17/12/2020
 */
public interface FeignClientService {

  /**
   * 获取租户的所有公司列表
   *
   * @return
   */
  List<OrganizationClientVo> getTenantCompanyList();


  /**
   * 查询新值列表
   *
   * @param code
   * @return
   */
  List<EnumValueVo> getPortalEnumValueList(String code);


  /**
   * 查询新值列表
   *
   * @param code
   * @return
   */
  List<EnumValueVo> getSystemEnumValueList(String code);

  /**
   * 查询新值列表，支持多租户配置
   *
   * @param
   * @return
   */
  List<CompanyDataPermissionVo> getUserDataPermissions();

  /**
   * 查询用户名集合
   *
   * @param userIdSet
   * @return
   */
  Map<String, String> getUserNameMapByIdSet(Set<String> userIdSet);


  /**
   * 查询语言列表
   *
   * @return
   */
  List<FndPortalLanguage> getLanguageList();

  /**
   * 查询公司映射
   *
   * @param organizationId
   * @return
   */
  List<BiDataCompanySystemVo> getSystemByCompanyId(String organizationId);


  /**
   * 根据公司Code查询公司信息
   *
   * @param organizationCode
   * @return
   */
  OrganizationClientVo selectOrganizationByCode(String organizationCode);

}
