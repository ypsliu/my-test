package com.deloitte.bdh.common.annotation;

/**
 * @author Ashen
 * @date 05/03/2021
 */
public @interface NoTenantCode {

}
