package com.deloitte.bdh.common.context;

import com.deloitte.bdh.ae.model.BaseTenant;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.constant.LanguageConstant;
import com.deloitte.bdh.common.util.AssertUtils;
import com.deloitte.bdh.common.util.StringUtil;
import java.util.Objects;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 用于保存上下文
 */
public class ThreadContextHolder {

  private static final Logger logger = LoggerFactory.getLogger(ThreadContextHolder.class);


  private static final ThreadLocal<RetRequest<?>> REQUEST_THREAD_LOCAL = new ThreadLocal<>();

  private static final ThreadLocal<String> IP = new ThreadLocal<>();

  private static final ThreadLocal<BaseTenant> TENANT_THREAD_LOCAL = new ThreadLocal<>();

  private static final ThreadLocal<String> LANG = new ThreadLocal<>();

  /**
   * 获取IP
   *
   * @return 返回IP地址
   */
  public static String getIp() {
    return IP.get();
  }

  /**
   * 设置IP
   *
   * @param ip ip
   */
  public static void setIp(String ip) {
    IP.set(ip);
  }

  /**
   * 移除ip
   */
  public static void removeIp() {
    IP.remove();
  }

  /**
   * 移除操作人
   */
  public static void remove() {
    REQUEST_THREAD_LOCAL.remove();
    IP.remove();
    TENANT_THREAD_LOCAL.remove();
    LANG.remove();
  }

  /**
   * 获取操作人
   */
  public static RetRequest<?> getRetRequest() {
    return REQUEST_THREAD_LOCAL.get();
  }

  /**
   * 设置当前操作人
   *
   * @param retRequest 请中的额外参数
   */
  public static void setRetRequest(RetRequest<?> retRequest) {
    REQUEST_THREAD_LOCAL.set(retRequest);
  }

  /**
   * 设置当前接口的租户信息
   *
   * @param baseTenant
   */
  public static void setTenantThreadLocal(BaseTenant baseTenant) {
    TENANT_THREAD_LOCAL.set(baseTenant);
  }

  /**
   * 获取当前接口租户信息
   *
   * @return
   */
  public static BaseTenant getTenant() {
    BaseTenant baseTenant = TENANT_THREAD_LOCAL.get();
    AssertUtils.assertNotNull(baseTenant, "获取当前租户上下文失败!");
    return baseTenant;
  }

  /**
   * 获取当前接口租户ID
   *
   * @return
   */
  public static String getTenantId() {
    return getTenant().getTenantId();
  }

  /**
   * 获取当前接口操作人
   *
   * @return
   */
  public static String getOperator() {
    RetRequest<?> retRequest = ThreadContextHolder.getRetRequest();
    String operator = "";
    if (Objects.nonNull(retRequest)) {
      operator = retRequest.getOperator();
    } else {
      logger.error("无法获取请求中的retRequest信息，不能记录当前操作人");
    }
    return operator;
  }

  public static void setLang(String lang) {
    if (StringUtil.isNotEmpty(lang)) {
      LANG.set(lang);
    }
  }

  public static String getLang() {
    RetRequest<?> retRequest = REQUEST_THREAD_LOCAL.get();
    if (Objects.nonNull(retRequest)) {
      return retRequest.getLang();
    }
    if (StringUtil.isNotEmpty(LANG.get())) {
      return LANG.get();
    }
    return LanguageConstant.CN.getLanguage();
  }
}
