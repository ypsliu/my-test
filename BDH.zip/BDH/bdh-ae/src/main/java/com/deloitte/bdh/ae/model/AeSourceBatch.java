package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.LocalDate;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "AeSourceBatch对象", description = "")
public class AeSourceBatch extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableId("AE_BATCH_ID")
  private String aeBatchId;

  @TableField("BATCH_NAME")
  private String batchName;

  @TableField("SOURCE_BATCH_ID")
  private String sourceBatchId;

  @TableField("FAIL_REASON")
  private String failReason;

  @TableField("ACTIVE_FLAG")
  private Integer activeFlag;

  @TableField("TYPE")
  private String type;

  @TableField("TENANT_ID")
  private String tenantId;

  @TableField("APPLICATION_CODE")
  private String applicationCode;

  @TableField("ORGANIZATION_ID")
  private String organizationId;

  @TableField("AE_STATUS")
  private String aeStatus;

  @TableField("DESCRIPTION")
  private String description;

  @TableField("ENTRY_USER_ID")
  private String entryUserId;

  @TableField("ENTRY_DATE")
  private LocalDate entryDate;

  @TableField("EBS_STATUS")
  private String ebsStatus;

  @TableField("ENTRY_TYPE")
  private String entryType;

  @TableField("AE_BATCH_CODE")
  private String aeBatchCode;

  @TableField("ACCOUNTING_DATE")
  private LocalDate accountingDate;

  @TableField(exist = false)
  @ApiModelProperty(value = "EBS同步状态-显示值")
  private String ebsStatusShow;

  @TableField(exist = false)
  @ApiModelProperty(value = "会计科目类型-显示值")
  private String entryTypeShow;

  @TableField(exist = false)
  @ApiModelProperty(value = "来源系统")
  private String sourceShow;

  @TableField(exist = false)
  @ApiModelProperty(value = "入账人-显示值")
  private String entryUserName;

  @TableField(exist = false)
  @ApiModelProperty(value = "入账状态-显示值")
  private String aeStatusShow;

  @TableField(exist = false)
  @ApiModelProperty(value = "公司")
  private String organizationName;
}
