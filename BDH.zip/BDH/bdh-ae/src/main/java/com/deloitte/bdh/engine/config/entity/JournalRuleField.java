package com.deloitte.bdh.engine.config.entity;

import lombok.Data;

@Data
public class JournalRuleField {

  private String ruleId;

  private String segment1;

  private String segment2;

  private String segment3;

  private String segment4;

  private String segment5;

  private String segment6;

  private String segment7;

  private String segment8;

  private String segment9;

  private String segment10;

  private String segment11;

  private String segment12;

  private String segment13;

  private String segment14;

  private String segment15;

}