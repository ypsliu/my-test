package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.deloitte.bdh.ae.dao.ae.SourceExpenseHeadMapper;
import com.deloitte.bdh.ae.model.AeApplication;
import com.deloitte.bdh.ae.model.AeSourceBatch;
import com.deloitte.bdh.ae.model.AeSourceLoadTable;
import com.deloitte.bdh.ae.model.SourceExpenseHead;
import com.deloitte.bdh.ae.model.io.DataOutput;
import com.deloitte.bdh.ae.model.io.OneDataInput;
import com.deloitte.bdh.ae.model.io.expense.ExpExpenseCommonLinesInput;
import com.deloitte.bdh.ae.model.io.expense.ExpExpenseRequestHeadersInput;
import com.deloitte.bdh.ae.model.io.expense.ExpReceivableApplLinesInput;
import com.deloitte.bdh.ae.model.io.expense.ExpenseDataInput;
import com.deloitte.bdh.ae.model.io.expense.ExpenseDataOutput;
import com.deloitte.bdh.ae.model.io.target.TargetDataHeadOutput;
import com.deloitte.bdh.ae.model.io.target.TargetDataLineOutput;
import com.deloitte.bdh.ae.model.io.target.TargetDataOutput;
import com.deloitte.bdh.ae.properties.ApplicationCodeProperties;
import com.deloitte.bdh.ae.service.AeApplicationService;
import com.deloitte.bdh.ae.service.AeDataService;
import com.deloitte.bdh.ae.service.AeSourceBatchService;
import com.deloitte.bdh.ae.service.AeSourceLoadTableService;
import com.deloitte.bdh.ae.service.AeTenantMethodService;
import com.deloitte.bdh.ae.service.SourceExpenseHeadService;
import com.deloitte.bdh.ae.service.SourceExpenseLineService;
import com.deloitte.bdh.ae.service.SourceExpenseReceivableLineService;
import com.deloitte.bdh.ae.service.TargetGlInterfaceService;
import com.deloitte.bdh.common.base.ServiceTransactionalImpl;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.common.exception.BizException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Service
@DS(DSConstant.AE_DB)
public class SourceExpenseHeadServiceImpl extends
    ServiceTransactionalImpl<SourceExpenseHeadMapper, SourceExpenseHead> implements
    SourceExpenseHeadService {

  @Autowired
  private SourceExpenseHeadService sourceExpenseHeadService;

  @Autowired
  private AeApplicationService aeApplicationService;

  @Autowired
  private AeSourceLoadTableService aeSourceLoadTableService;

  @Autowired
  private AeSourceBatchService aeSourceBatchService;

  @Autowired
  private SourceExpenseLineService sourceExpenseLineService;

  @Autowired
  private SourceExpenseReceivableLineService sourceExpenseReceivableLineService;

  @Autowired
  private TargetGlInterfaceService targetGlInterfaceService;

  @Autowired
  private AeTenantMethodService aeTenantMethodService;

  @Autowired
  private AeDataService aeDataService;

  @Autowired
  private ApplicationCodeProperties applicationCodeProperties;

  @Override
  @Transactional(rollbackFor = Exception.class)
  public ExpenseDataOutput putData(ExpenseDataInput expenseDataInput) {
    aeTenantMethodService.verifyTenantApplication(expenseDataInput.getTenantId(),
        expenseDataInput.getApplicationCode(),
        applicationCodeProperties.getApplicationCodeExpense());
    ExpenseDataOutput expenseDataOutput = new ExpenseDataOutput();
    if (expenseDataInput == null || expenseDataInput.getHeaderList() == null
        || expenseDataInput.getHeaderList().size() == 0) {
      throw new BizException("头信息不能为空");
    }
    if (expenseDataInput.getExpenseLineList() == null
        || expenseDataInput.getExpenseLineList().size() == 0) {
      throw new BizException("行信息不能为空");
    }
    String aeBatchCode = aeSourceBatchService.selectAeBatchCode();
    String aeBatchId = this.getSequence();
    insertHeadList(expenseDataInput.getHeaderList(), aeBatchId);
    insertExpenseLineList(expenseDataInput.getExpenseLineList(), aeBatchId);
    insertReceivableLineList(expenseDataInput.getReceivableLineList(), aeBatchId);

    AeSourceBatch aeSourceBatch = new AeSourceBatch();
    aeSourceBatch.setAeBatchId(aeBatchId);
    aeSourceBatch.setSourceBatchId(aeBatchId);
    aeSourceBatch.setActiveFlag(1);
    aeSourceBatch.setApplicationCode(expenseDataInput.getApplicationCode());
    aeSourceBatch.setTenantId(expenseDataInput.getTenantId());
    aeSourceBatch.setOrganizationId(expenseDataInput.getOrganizationId());
    aeSourceBatch.setAeBatchCode(aeBatchCode);
    aeSourceBatchService.save(aeSourceBatch);
    expenseDataOutput.setAeBatchId(aeBatchId);
    expenseDataOutput.setMessage("成功");
    expenseDataOutput.setStatus("OK");
    return expenseDataOutput;
  }

  @Override
  public TargetDataOutput getTargetDate(OneDataInput oneDataInput) {
    TargetDataOutput targetDataOutput = new TargetDataOutput();
    try {
      AeSourceBatch aeSourceBatch = aeSourceBatchService.getById(oneDataInput.getAeBatchId());
      if (aeSourceBatch == null) {
        throw new BizException("查询批次信息失败！");
      }
      if (!"OK".equals(aeSourceBatch.getEbsStatus())) {
        throw new BizException("目标数据还在生成中...");
      }
      List<TargetDataHeadOutput> targetDataHeadOutputList = targetGlInterfaceService
          .queryTargetHeadList(oneDataInput.getAeBatchId(),
              oneDataInput.getSourceHeadId());
      targetDataOutput.setHeadList(targetDataHeadOutputList);
      if (targetDataHeadOutputList.size() == 0) {
        throw new BizException("单据头列表不能为空");
      }
      List<TargetDataLineOutput> targetDataLineOutputList = targetGlInterfaceService
          .queryTargetLineList(oneDataInput.getAeBatchId(),
              oneDataInput.getSourceHeadId());
      if (targetDataLineOutputList.size() == 0) {
        throw new BizException("单据行信息不能为空");
      }
      Map<String, List<TargetDataLineOutput>> lineMap = targetDataLineOutputList.stream().collect(
          Collectors.groupingBy(TargetDataLineOutput::getAeEbsHeadId));
      targetDataHeadOutputList.forEach(targetDataHeadOutput -> {
        targetDataHeadOutput.setOrganizationId(aeSourceBatch.getOrganizationId());
        targetDataHeadOutput.setTenantId(aeSourceBatch.getTenantId());
        List<TargetDataLineOutput> lineList = lineMap.get(targetDataHeadOutput.getAeEbsHeadId());
        if (lineList == null || lineList.size() == 0) {
          throw new BizException("单据编号：" + targetDataHeadOutput.getAeEbsNumber() + "的行信息不能为空！");
        }
        targetDataHeadOutput.setLineList(lineList);
      });
      targetDataOutput.setStatus("OK");
    } catch (Exception e) {
      targetDataOutput.setStatus("FAIL");
      targetDataOutput.setMessage("获取目标数据失败:" + e.getMessage());
    }
    return targetDataOutput;
  }

  private void insertReceivableLineList(List<ExpReceivableApplLinesInput> receivableLineList,
      String aeBatchId) {
    if (receivableLineList != null) {
      receivableLineList.forEach(expReceivableApplLinesInput -> {
        expReceivableApplLinesInput.setSourceBatchId(aeBatchId);
        sourceExpenseReceivableLineService.save(expReceivableApplLinesInput);
      });
    }
  }

  private void insertHeadList(List<ExpExpenseRequestHeadersInput> headersInputList,
      String aeBatchId) {
    headersInputList.forEach(expExpenseRequestHeadersInput -> {
      expExpenseRequestHeadersInput.setSourceBatchId(aeBatchId);
      sourceExpenseHeadService.save(expExpenseRequestHeadersInput);
    });
  }

  private void insertExpenseLineList(List<ExpExpenseCommonLinesInput> expenseInputList,
      String aeBatchId) {
    expenseInputList.forEach(expExpenseCommonLinesInput -> {
      expExpenseCommonLinesInput.setSourceBatchId(aeBatchId);
      sourceExpenseLineService.save(expExpenseCommonLinesInput);
    });
  }

  @Override
  @Transactional(rollbackFor = Exception.class)
  public DataOutput revertData(OneDataInput oneDataInput) {
    DataOutput dataOutput = new DataOutput();
    try {
      AeSourceBatch aeSourceBatch = aeSourceBatchService.getById(oneDataInput.getAeBatchId());
      if (aeSourceBatch == null) {
        throw new BizException("获取批次信息失败！");
      }
      if (!(Strings.isEmpty(aeSourceBatch.getEbsStatus()) || "FAIL"
          .equals(aeSourceBatch.getEbsStatus()))) {
        throw new BizException("已经开始进行EBS同步，无法进行撤销操作！");
      }
      List<AeApplication> aeApplicationList = aeApplicationService
          .list(new LambdaQueryWrapper<AeApplication>()
              .eq(AeApplication::getApplicationCode, aeSourceBatch.getApplicationCode()));
      if (aeApplicationList.size() != 1) {
        throw new BizException("查询应用产品信息失败");
      }
      // 删除来源数据上该头信息的数据
      List<AeSourceLoadTable> tableList = aeSourceLoadTableService
          .list(new LambdaQueryWrapper<AeSourceLoadTable>()
              .eq(AeSourceLoadTable::getApplicationId,
                  aeApplicationList.get(0).getApplicationId()));
      List<AeSourceLoadTable> headTableList = new ArrayList<>();
      // 删除目标数据上该头信息的数据
      tableList.forEach(aeSourceLoadTable -> {
        if ("SOURCE".equalsIgnoreCase(aeSourceLoadTable.getDirection())) {
          if ("HEAD".equals(aeSourceLoadTable.getType())) {
            headTableList.add(aeSourceLoadTable);
          }
          deleteSourceData(aeSourceLoadTable.getTableName(), aeSourceBatch.getSourceBatchId(),
              oneDataInput.getSourceHeadId());
        } else if ("TARGET".equalsIgnoreCase(aeSourceLoadTable.getDirection())) {
          deleteTargetData(aeSourceLoadTable.getTableName(), aeSourceBatch.getAeBatchId(),
              oneDataInput.getSourceHeadId());
        } else {
          throw new BizException("表方向异常");
        }
      });
      if (headTableList.size() == 0 || headTableList.size() > 1) {
        throw new BizException("配置的头表数据错误");
      }
      //校验来源头表数据量，如果数量为0则删除批次信息
      BigDecimal headCount = countTableBatchData(headTableList.get(0).getTableName(),
          aeSourceBatch.getSourceBatchId());
      if (headCount == null || headCount.compareTo(new BigDecimal("0")) == 0) {
        aeSourceBatchService.removeById(aeSourceBatch.getAeBatchId());
      }
      dataOutput.setStatus("OK");
    } catch (BizException e) {
      dataOutput.setStatus("FAIL");
      dataOutput.setMessage(e.getMessage());
    }
    return dataOutput;
  }

  /**
   * 计算头表数据量
   *
   * @param tableName
   * @param sourceBatchId
   * @return
   */
  private BigDecimal countTableBatchData(String tableName, String sourceBatchId) {
    if (Strings.isEmpty(tableName)) {
      throw new BizException("表信息不能为空!");
    }
    if (Strings.isEmpty(sourceBatchId)) {
      throw new BizException("批次不能为空!");
    }
    StringBuffer sql = new StringBuffer();
    sql.append("SELECT COUNT(1) FROM ").append(tableName);
    sql.append(" WHERE SOURCE_BATCH_ID = ").append(sourceBatchId);
    return aeDataService.countData(sql.toString());
  }

  /**
   * 删除目标数据
   *
   * @param tableName
   * @param aeBatchId
   * @param sourceHeadId
   */
  private void deleteTargetData(String tableName, String aeBatchId, String sourceHeadId) {
    if (Strings.isEmpty(tableName)) {
      throw new BizException("表信息不能为空!");
    }
    if (aeBatchId == null) {
      throw new BizException("批次不能为空!");
    }
    if (Strings.isEmpty(sourceHeadId)) {
      throw new BizException("单据头ID不能为空!");
    }
    StringBuffer sql = new StringBuffer();
    sql.append("DELETE FROM ").append(tableName);
    sql.append(" WHERE AE_BATCH_ID = ").append(aeBatchId);
    sql.append(" AND SOURCE_HEAD_ID= '").append(sourceHeadId).append("'");
    aeDataService.deleteData(sql.toString());
  }

  /**
   * 删除来源数据
   *
   * @param tableName
   * @param sourceBatchId
   * @param sourceHeadId
   */
  private void deleteSourceData(String tableName, String sourceBatchId, String sourceHeadId) {
    if (Strings.isEmpty(tableName)) {
      throw new BizException("表信息不能为空!");
    }
    if (Strings.isEmpty(sourceBatchId)) {
      throw new BizException("批次不能为空!");
    }
    if (Strings.isEmpty(sourceHeadId)) {
      throw new BizException("单据头ID不能为空!");
    }
    StringBuffer sql = new StringBuffer();
    sql.append("DELETE FROM ").append(tableName);
    sql.append(" WHERE SOURCE_BATCH_ID = ").append(sourceBatchId);
    sql.append(" AND SOURCE_HEAD_ID= '").append(sourceHeadId).append("'");
    aeDataService.deleteData(sql.toString());
  }
}
