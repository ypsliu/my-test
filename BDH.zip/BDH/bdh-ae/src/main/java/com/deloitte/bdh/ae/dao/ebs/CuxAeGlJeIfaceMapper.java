package com.deloitte.bdh.ae.dao.ebs;


import com.deloitte.bdh.ae.model.CuxAeGlJeIface;
import java.util.List;

public interface CuxAeGlJeIfaceMapper {

  /**
   * 计算已经同步的数据条数
   *
   * @param aeBatchId
   * @return
   */
  Integer countExistsData(String aeBatchId);


  /**
   * 查询EBS入账结果
   *
   * @return
   */
  List<CuxAeGlJeIface> selectResultByBatch(String aeBatchId);

  /**
   * 查询EBS报错信息
   *
   * @param aeBatchId
   * @return
   */
  List<CuxAeGlJeIface> selectErrorByBatch(String aeBatchId);

  /**
   * 查询成功的数据条数
   *
   * @param aeBatchId
   * @return
   */
  Integer countSuccessData(String aeBatchId);

  /**
   * 查询失败的数据条数
   *
   * @param aeBatchId
   * @return
   */
  Integer countErrorData(String aeBatchId);
}