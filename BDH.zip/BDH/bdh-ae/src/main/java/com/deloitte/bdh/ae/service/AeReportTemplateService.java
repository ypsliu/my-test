package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.AeReportTemplate;
import com.deloitte.bdh.ae.model.dto.ReportDto;
import com.deloitte.bdh.ae.model.dto.ReportRunDto;
import com.deloitte.bdh.common.base.PageHeadResult;
import com.deloitte.bdh.common.base.PageRequest;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.Service;
import com.deloitte.bdh.engine.runtime.entity.DataLine;
import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface AeReportTemplateService extends Service<AeReportTemplate> {

  List<AeReportTemplate> selectByPage(PageRequest<AeReportTemplate> pageRequest);

  void insertData(RetRequest<AeReportTemplate> retRequest);

  void updateData(RetRequest<AeReportTemplate> retRequest);

  void deleteData(String reportId);

  /**
   * 查询报表结果
   *
   * @param pageRequest
   * @return
   */
  PageHeadResult<DataLine> reportResult(PageRequest<ReportRunDto> pageRequest);

  /**
   * 导出报表结果
   *
   * @param reportRunDto
   * @return
   */
  PageHeadResult<DataLine> reportResultExport(ReportRunDto reportRunDto);

  List<AeReportTemplate> queryConditionReportList(RetRequest<AeReportTemplate> retRequest);

  void checkPermission(RetRequest<ReportDto> retRequest);


}
