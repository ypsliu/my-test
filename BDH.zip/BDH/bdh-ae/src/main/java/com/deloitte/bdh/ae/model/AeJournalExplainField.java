package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "AeJournalExplainField对象", description = "")
public class AeJournalExplainField extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableId("EXPLAIN_FIELD_ID")
  private String explainFieldId;

  @TableField("EXPLAIN_LINE_ID")
  private String explainLineId;

  @TableField("TYPE")
  private String type;

  @TableField("CONSTANT")
  private String constant;

  @TableField("SOURCE_ID")
  private String sourceId;

  @TableField("ACTIVE_FLAG")
  private Integer activeFlag;

  @TableField("DESCRIPTION")
  private String description;

  @TableField("PRIORITY_LEVEL")
  private BigDecimal priorityLevel;


}
