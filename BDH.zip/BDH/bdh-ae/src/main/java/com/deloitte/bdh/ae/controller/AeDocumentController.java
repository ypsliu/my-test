package com.deloitte.bdh.ae.controller;

import com.deloitte.bdh.ae.model.dto.DocumentQueryDto;
import com.deloitte.bdh.ae.service.AeDocumentService;
import com.deloitte.bdh.common.base.PageRequest;
import com.deloitte.bdh.common.base.PageResult;
import com.deloitte.bdh.common.base.RetResponse;
import com.deloitte.bdh.common.base.RetResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author dahpeng
 * @Description: AeSourceBatchController类
 * @date 2019/11/26 14:15
 */
@RestController
@RequestMapping("/aeDocument")
@Api(tags = "单据相关接口")
public class AeDocumentController {

  @Autowired
  private AeDocumentService aeDocumentService;

  /**
   * @Description: 分页查询
   * @Reutrn RetResult<PageInfo < AeSourceBatch>>
   */
  @PostMapping("queryPage")
  @ApiOperation(value = "分页查看批次下单据信息")
  public RetResult<Object> queryPage(
      @RequestBody @Validated PageRequest<DocumentQueryDto> pageRequest) {
    PageResult pageResult = aeDocumentService.selectByPageRequest(pageRequest);
    return RetResponse.makeOKRsp(pageResult);
  }

}