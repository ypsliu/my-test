package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.dto.DocumentQueryDto;
import com.deloitte.bdh.common.base.PageRequest;
import com.deloitte.bdh.common.base.PageResult;

/**
 * @author Ashen
 * @date 20/02/2020
 */
public interface AeDocumentService {

  /**
   * 根据批次信息查询单据信息
   */
  PageResult selectByPageRequest(PageRequest<DocumentQueryDto> pageRequest);
}
