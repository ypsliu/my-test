package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.SourcePsSalaryHead;
import com.deloitte.bdh.ae.model.SourcePsSalaryLine;
import java.util.List;

/**
 * @author Ashen
 * @date 27/04/2020
 */
public interface PsSalaryService {

  /**
   * 查询头信息
   *
   * @param psCompanyId
   * @param period
   * @param version
   * @return
   */
  List<SourcePsSalaryHead> selectHeadDataFromPs(String psCompanyId, String period, String version);


  /**
   * 查询行信息
   *
   * @param psCompanyId
   * @param period
   * @param version
   * @return
   */
  List<SourcePsSalaryLine> selectLineDataFromPs(String psCompanyId, String period, String version);


  /**
   * 查询PS系统中的一条最大明细数据
   *
   * @param psCompanyId
   * @param period
   * @return
   */
  SourcePsSalaryLine selectOneDataMaxVersionFromPs(String psCompanyId, String period);
}
