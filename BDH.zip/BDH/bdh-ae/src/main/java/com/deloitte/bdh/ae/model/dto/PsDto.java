package com.deloitte.bdh.ae.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.Data;

/**
 * @author Ashen
 * @date 20/02/2020
 */
@Data
@ApiModel(description = "PS参数信息")
public class PsDto {

  @ApiModelProperty(value = "期间，格式: yyyy/MM")
  @NotEmpty(message = "期间不能为空")
  private String period;

  @ApiModelProperty(value = "公司")
  @NotNull(message = "公司不能为空")
  private String organizationId;

  @ApiModelProperty(value = "是否覆盖数据：Y为覆盖，N为不覆盖已经同步的数据")
  private String overlayFlag;
}
