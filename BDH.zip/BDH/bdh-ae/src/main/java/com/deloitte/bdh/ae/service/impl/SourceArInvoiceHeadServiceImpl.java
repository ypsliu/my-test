package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.deloitte.bdh.ae.dao.ae.SourceArInvoiceHeadMapper;
import com.deloitte.bdh.ae.model.AeSourceBatch;
import com.deloitte.bdh.ae.model.SourceArInvoiceHead;
import com.deloitte.bdh.ae.model.TargetArInterface;
import com.deloitte.bdh.ae.model.io.DataOutput;
import com.deloitte.bdh.ae.model.io.OneDataInput;
import com.deloitte.bdh.ae.model.io.ar.ArDataInput;
import com.deloitte.bdh.ae.model.io.ar.SourceArInvoiceHeadInput;
import com.deloitte.bdh.ae.model.io.ar.SourceArInvoiceLineInput;
import com.deloitte.bdh.ae.model.io.target.TargetDataOutput;
import com.deloitte.bdh.ae.properties.ApplicationCodeProperties;
import com.deloitte.bdh.ae.service.AeSourceBatchService;
import com.deloitte.bdh.ae.service.AeTenantMethodService;
import com.deloitte.bdh.ae.service.SourceArInvoiceHeadService;
import com.deloitte.bdh.ae.service.SourceArInvoiceLineService;
import com.deloitte.bdh.ae.service.TargetArInterfaceService;
import com.deloitte.bdh.common.base.ServiceTransactionalImpl;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.common.exception.BizException;
import java.util.List;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Service
@DS(DSConstant.AE_DB)
public class SourceArInvoiceHeadServiceImpl extends
    ServiceTransactionalImpl<SourceArInvoiceHeadMapper, SourceArInvoiceHead> implements
    SourceArInvoiceHeadService {


  @Autowired
  private AeTenantMethodService aeTenantMethodService;

  @Autowired
  private AeSourceBatchService aeSourceBatchService;

  @Autowired
  private SourceArInvoiceHeadService sourceArInvoiceHeadService;

  @Autowired
  private SourceArInvoiceLineService sourceArInvoiceLineService;

  @Autowired
  private TargetArInterfaceService targetArInterfaceService;

  @Autowired
  private ApplicationCodeProperties applicationCodeProperties;

  @Override
  public DataOutput putData(ArDataInput arDataInput) {
    aeTenantMethodService
        .verifyTenantApplication(arDataInput.getTenantId(), arDataInput.getApplicationCode(),
            applicationCodeProperties.getApplicationCodeScmAr());
    DataOutput dataOutput = new DataOutput();
    if (arDataInput == null || arDataInput.getHeadList() == null
        || arDataInput.getHeadList().size() == 0) {
      throw new BizException("头信息不能为空");
    }
    if (arDataInput.getLineList() == null
        || arDataInput.getLineList().size() == 0) {
      throw new BizException("行信息不能为空");
    }
    String aeBatchCode = aeSourceBatchService.selectAeBatchCode();
    String aeBatchId = this.getSequence();
    insertHeadList(arDataInput.getHeadList(), aeBatchId);
    insertLineList(arDataInput.getLineList(), aeBatchId);

    AeSourceBatch aeSourceBatch = new AeSourceBatch();
    aeSourceBatch.setAeBatchId(aeBatchId);
    aeSourceBatch.setSourceBatchId(aeBatchId);
    aeSourceBatch.setActiveFlag(1);
    aeSourceBatch.setApplicationCode(arDataInput.getApplicationCode());
    aeSourceBatch.setTenantId(arDataInput.getTenantId());
    aeSourceBatch.setOrganizationId(arDataInput.getOrganizationId());
    aeSourceBatch.setAeBatchCode(aeBatchCode);
    aeSourceBatchService.save(aeSourceBatch);
    dataOutput.setAeBatchId(aeBatchId);
    dataOutput.setMessage("成功");
    dataOutput.setStatus("OK");
    return dataOutput;
  }

  private void insertHeadList(List<SourceArInvoiceHeadInput> headList, String aeBatchId) {
    headList.forEach(sourceArInvoiceHeadInput -> {
      sourceArInvoiceHeadInput.setSourceBatchId(aeBatchId);
      if (Strings.isEmpty(sourceArInvoiceHeadInput.getSourceHeadId())) {
        throw new BizException("来源头ID不能为空");
      }
      sourceArInvoiceHeadService.save(sourceArInvoiceHeadInput);
    });

  }

  private void insertLineList(List<SourceArInvoiceLineInput> lineList, String aeBatchId) {
    lineList.forEach(sourceArInvoiceLineInput -> {
      sourceArInvoiceLineInput.setSourceBatchId(aeBatchId);
      if (Strings.isEmpty(sourceArInvoiceLineInput.getSourceHeadId())) {
        throw new BizException("来源头ID不能为空");
      }
      if (Strings.isEmpty(sourceArInvoiceLineInput.getSourceLineId())) {
        throw new BizException("来源行ID不能为空");
      }
      sourceArInvoiceLineService.save(sourceArInvoiceLineInput);
    });
  }

  @Override
  public TargetDataOutput getTargetDate(OneDataInput oneDataInput) {
    TargetDataOutput targetDataOutput = new TargetDataOutput();
    AeSourceBatch aeSourceBatch = aeSourceBatchService.getById(oneDataInput.getAeBatchId());
    if (aeSourceBatch == null) {
      throw new BizException("查询批次信息失败！");
    }
    if (!"OK".equals(aeSourceBatch.getEbsStatus())) {
      throw new BizException("目标数据还在生成中...");
    }
    //查询该批次该头ID的目标数据量
    Integer targetCount = targetArInterfaceService.count(new LambdaQueryWrapper<TargetArInterface>()
        .eq(TargetArInterface::getAeBatchId, oneDataInput.getAeBatchId())
        .eq(TargetArInterface::getSourceHeadId, oneDataInput.getSourceHeadId()));
    if (targetCount == null || targetCount == 0) {
      throw new BizException("没查询到生成的目标数据");
    }
    targetDataOutput.setStatus("OK");
    return targetDataOutput;
  }
}
