package com.deloitte.bdh.ae.dao.ae;

import com.deloitte.bdh.ae.model.SourceImportPaymentHead;
import com.deloitte.bdh.common.base.Mapper;

/**
 * <p>
 * 借款付款行信息 Mapper 接口
 * </p>
 *
 * @author Ashen
 * @since 2021-03-24
 */
public interface SourceImportPaymentHeadMapper extends Mapper<SourceImportPaymentHead> {

}
