package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.SourcePreparePaymentHead;
import com.deloitte.bdh.common.base.Service;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface SourcePreparePaymentHeadService extends Service<SourcePreparePaymentHead> {

}
