package com.deloitte.bdh.common.interceptor;

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import com.deloitte.bdh.common.context.ThreadContextHolder;
import com.deloitte.bdh.common.util.StringUtil;
import java.time.LocalDateTime;
import org.apache.ibatis.reflection.MetaObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * @author jinqwang
 */
@Component
public class MybatisPlusMetaObjectHandler implements MetaObjectHandler {

  private static final Logger logger = LoggerFactory.getLogger(MybatisPlusMetaObjectHandler.class);

  @Override
  public void insertFill(MetaObject metaObject) {
    String operator = ThreadContextHolder.getOperator();
    setFieldValByName("createDate", LocalDateTime.now(), metaObject);
    setFieldValByName("createUser", operator, metaObject);
    setFieldValByName("modifiedDate", LocalDateTime.now(), metaObject);
    setFieldValByName("modifiedUser", operator, metaObject);
    setFieldValByName("ip", getIp(), metaObject);
  }

  @Override
  public void updateFill(MetaObject metaObject) {
    String operator = ThreadContextHolder.getOperator();
    setFieldValByName("modifiedDate", LocalDateTime.now(), metaObject);
    setFieldValByName("modifiedUser", operator, metaObject);
    setFieldValByName("ip", getIp(), metaObject);

  }

  private String getIp() {
    String ip = ThreadContextHolder.getIp();
    return StringUtil.isEmpty(ip) ? "" : ip;
  }

}
