package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "SourcePaymentHead对象", description = "")
public class SourcePaymentHead extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableField("PAYMENT_ID")
  private String paymentId;

  @TableField("SOURCE_ID")
  private String sourceId;

  @TableField("SOURCE_TYPE")
  private String sourceType;

  @TableField("PAYMENT_METHOD")
  private String paymentMethod;

  @TableField("CASH_FLOW_SEGMENT")
  private String cashFlowSegment;

  @TableField("BANK_ACCOUNT_ID")
  private String bankAccountId;

  @TableField("CURRENCY_CODE")
  private String currencyCode;

  @TableField("PAYMENT_AMOUNT")
  private BigDecimal paymentAmount;

  @TableField("PAYMENT_DATE")
  private LocalDate paymentDate;

  @TableField("TENANT_ID")
  private String tenantId;

  @TableField("ACTIVE_FLAG")
  private BigDecimal activeFlag;

  @TableField("BATCH_ID")
  private String batchId;

  @TableField("BATCH_NAME")
  private String batchName;

  @TableField("LEDGER_STATUS")
  private BigDecimal ledgerStatus;

  @TableField("ACTION_TYPE")
  private String actionType;

  @TableField("GL_DATE")
  private LocalDate glDate;

  @TableField("PAYMENT_TOTAL_AMOUNT")
  private BigDecimal paymentTotalAmount;

  @TableField("PAYMENT_STATUS")
  private String paymentStatus;

  @TableField("PAY_SERIAL_NUM")
  private String paySerialNum;

  @TableField("INSTRUCTION_ID")
  private String instructionId;

  @TableField("PAY_MESSAGE")
  private String payMessage;

  @TableField("ACCEPTANCE_BILL_NO")
  private String acceptanceBillNo;

  @TableField("BANK_INSTRUCTION_NUM")
  private String bankInstructionNum;

  @TableField("SOURCE_BATCH_ID")
  private String sourceBatchId;

  @TableField("SOURCE_HEAD_ID")
  private String sourceHeadId;

  @TableField("AE_ROW_ID")
  private String aeRowId;

  @TableField("AE_STATUS")
  private String aeStatus;

  @TableField("ORGANIZATION_ID")
  private String organizationId;

  @TableField("ORGANIZATION_DEPT_ID")
  private String organizationDeptId;

  @TableField("TENANT_NAME")
  private String tenantName;

  @TableField("ORGANIZATION_NAME")
  private String organizationName;

  @TableField("ORGANIZATION_DEPT_NAME")
  private String organizationDeptName;

  @TableField("REQUEST_USER_NAME")
  private String requestUserName;

  @TableField("SOURCE_TYPE_CH")
  private String sourceTypeCh;

  @TableField("SOURCE_TYPE_EN")
  private String sourceTypeEn;

  @TableField("DOCUMENT_NUMBER")
  private String documentNumber;


}
