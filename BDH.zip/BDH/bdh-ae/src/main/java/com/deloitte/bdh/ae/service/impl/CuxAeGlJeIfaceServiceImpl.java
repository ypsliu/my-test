package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.deloitte.bdh.ae.dao.ebs.CuxAeGlJeIfaceMapper;
import com.deloitte.bdh.ae.model.CuxAeGlJeIface;
import com.deloitte.bdh.ae.service.CuxAeGlJeIfaceService;
import com.deloitte.bdh.common.constant.DSConstant;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Ashen
 * @date 09/02/2021
 */
@Service
@DS(DSConstant.EBS_DB)
@Transactional(propagation = Propagation.NOT_SUPPORTED)
public class CuxAeGlJeIfaceServiceImpl implements CuxAeGlJeIfaceService {

  @Resource
  private CuxAeGlJeIfaceMapper cuxAeGlJeIfaceMapper;

  @Override
  public Integer countExistsData(String aeBatchId) {
    return cuxAeGlJeIfaceMapper.countExistsData(aeBatchId);
  }

  @Override
  public List<CuxAeGlJeIface> selectResultByBatch(String aeBatchId) {
    return cuxAeGlJeIfaceMapper.selectResultByBatch(aeBatchId);
  }

  @Override
  public List<CuxAeGlJeIface> selectErrorByBatch(String aeBatchId) {
    return cuxAeGlJeIfaceMapper.selectErrorByBatch(aeBatchId);
  }

  @Override
  public Integer countSuccessData(String aeBatchId) {
    return cuxAeGlJeIfaceMapper.countSuccessData(aeBatchId);
  }

  @Override
  public Integer countErrorData(String aeBatchId) {
    return cuxAeGlJeIfaceMapper.countErrorData(aeBatchId);
  }
}
