package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.deloitte.bdh.ae.dao.ae.TargetGlInterfaceMapper;
import com.deloitte.bdh.ae.model.AeTarget;
import com.deloitte.bdh.ae.model.TargetGlInterface;
import com.deloitte.bdh.ae.model.dto.SourceQueryDto;
import com.deloitte.bdh.ae.model.io.ebsgl.P_PROCESS_DATA_DEL_ITEM;
import com.deloitte.bdh.ae.model.io.target.TargetDataHeadOutput;
import com.deloitte.bdh.ae.model.io.target.TargetDataLineOutput;
import com.deloitte.bdh.ae.model.io.target.TargetSegmentDetail;
import com.deloitte.bdh.ae.model.vo.DocumentVo;
import com.deloitte.bdh.ae.model.vo.TargetAccountVo;
import com.deloitte.bdh.ae.service.TargetGlInterfaceService;
import com.deloitte.bdh.common.base.ServiceTransactionalImpl;
import com.deloitte.bdh.common.constant.DSConstant;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Service
@DS(DSConstant.AE_DB)
public class TargetGlInterfaceServiceImpl extends
    ServiceTransactionalImpl<TargetGlInterfaceMapper, TargetGlInterface> implements
    TargetGlInterfaceService {

  @Override
  public List<TargetAccountVo> queryAccountingByParam(String sourceBatchId, String sourceHeadId,
      String applicationCode, String lang) {
    return baseMapper.queryAccountingByParam(sourceBatchId, sourceHeadId, applicationCode, lang);
  }

  @Override
  public List<DocumentVo> queryDocumentBySql(String sql) {
    return baseMapper.queryDocumentBySql(sql);
  }

  @Override
  public List<TargetAccountVo> exportAccountingByParam(List<String> batchList, String type,
      String applicationCode, String lang) {
    return baseMapper.exportAccountingByParam(batchList, type, applicationCode, lang);
  }

  @Override
  public void updateTarget(String aeBatchId, String sourceHeadId, String sourceLineId,
      String aeRowId, String aeEbsHeadId, String aeEbsLineOrder, String aeEbsNumber) {
    baseMapper.updateTarget(aeBatchId, sourceHeadId, sourceLineId, aeRowId,
        aeEbsHeadId, aeEbsLineOrder, aeEbsNumber);
  }

  @Override
  public List<TargetDataHeadOutput> queryTargetHeadList(String aeBatchId, String sourceHeadId) {
    return baseMapper.queryTargetHeadList(aeBatchId, sourceHeadId);
  }

  @Override
  public List<TargetDataLineOutput> queryTargetLineList(String aeBatchId, String sourceHeadId) {
    return baseMapper.queryTargetLineList(aeBatchId, sourceHeadId);
  }

  @Override
  public void deleteTargetByBatchId(String aeBatchId) {
    baseMapper.deleteTargetByBatchId(aeBatchId);
  }

  @Override
  public List<TargetSegmentDetail> queryTargetSegmentList(List<SourceQueryDto> queryDtoList,
      List<AeTarget> aeTargetList) {
    return baseMapper.queryTargetSegmentList(queryDtoList, aeTargetList);
  }

  @Override
  public List<P_PROCESS_DATA_DEL_ITEM> queryGlItem(String aeBatchId) {
    return baseMapper.queryGlItem(aeBatchId);
  }
}
