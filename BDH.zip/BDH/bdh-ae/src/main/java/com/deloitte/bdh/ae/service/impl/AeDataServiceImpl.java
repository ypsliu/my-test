package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.deloitte.bdh.ae.dao.ae.AeDataMapper;
import com.deloitte.bdh.ae.service.AeDataService;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.engine.runtime.entity.DataLine;
import java.math.BigDecimal;
import java.util.List;
import javax.annotation.Resource;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Ashen
 * @date 01/02/2021
 */
@Service
@DS(DSConstant.AE_DB)
@Transactional(rollbackFor = Exception.class)
public class AeDataServiceImpl implements AeDataService {

  @Resource
  private AeDataMapper aeDataMapper;

  @Override
  public List<DataLine> loadData(@Param("sql") String sql) {
    return aeDataMapper.loadData(sql);
  }


  @Override
  public void insertData(@Param("sql") String sql) {
    aeDataMapper.insertData(sql);
  }


  @Override
  public void deleteData(@Param("sql") String sql) {
    aeDataMapper.deleteData(sql);
  }


  @Override
  public void updateData(@Param("sql") String sql) {
    aeDataMapper.updateData(sql);
  }


  @Override
  public BigDecimal countData(@Param("sql") String sql) {
    return aeDataMapper.countData(sql);
  }
}
