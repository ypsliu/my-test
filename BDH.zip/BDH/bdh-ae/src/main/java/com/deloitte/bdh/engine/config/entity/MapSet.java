package com.deloitte.bdh.engine.config.entity;

import java.util.List;
import java.util.Map;
import lombok.Data;

/**
 * 映射集
 *
 * @author Ashen
 * @date 04/12/2019
 */
@Data
public class MapSet {

  private String setId;

  private String setCode;

  private String setName;

  private List<MapSetField> mapSetFieldList;

  private Map<String, String> valueMap;
}
