package com.deloitte.bdh.engine.config.entity;

import lombok.Data;

@Data
public class JournalTypeAttribute {

  private String targetId;

  private String sourceId;

  private String sourceType;

  private String setId;

  private String valueData;
}