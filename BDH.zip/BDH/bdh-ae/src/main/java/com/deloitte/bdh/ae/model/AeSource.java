package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "AeSource对象", description = "")
public class AeSource extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableId("SOURCE_ID")
  private String sourceId;

  @TableField("TABLE_ID")
  private String tableId;

  @TableField("APPLICATION_ID")
  private String applicationId;

  @TableField("DISPLAY_CODE")
  private String displayCode;

  @TableField("DISPLAY_NAME")
  private String displayName;

  @TableField("DB_FUNCTION_NAME")
  private String dbFunctionName;

  @TableField("ACTIVE_FLAG")
  private Integer activeFlag;

  @TableField("SOURCE_TYPE")
  private String sourceType;

  @TableField("SOURCE_NAME")
  private String sourceName;

  @TableField("SOURCE_DESCRIPTION")
  private String sourceDescription;

  @TableField("SOURCE_DATA_TYPE")
  private String sourceDataType;


}
