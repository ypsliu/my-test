package com.deloitte.bdh.ae.model;

import lombok.Data;

/**
 * @author Ashen
 * @date 22/04/2020
 */
@Data
public class TargetSourceBasicInfo {

  private String aeRowId;
  private String sourceHeadId;
  private String sourceLineId;
  private String sourceBatchId;
  private String aeBatchId;

}
