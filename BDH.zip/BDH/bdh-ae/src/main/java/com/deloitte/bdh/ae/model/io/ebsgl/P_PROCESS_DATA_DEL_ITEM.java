package com.deloitte.bdh.ae.model.io.ebsgl;


import com.alibaba.fastjson.annotation.JSONField;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.Data;


/**
 * @author Ashen
 * @date 09/02/2021
 */
@Data
public class P_PROCESS_DATA_DEL_ITEM {

  @JSONField(name = "STATUS", ordinal = 1)
  private String STATUS;

  @JSONField(name = "LEDGER_ID", ordinal = 2)
  private String LEDGER_ID;

  @JSONField(name = "ACCOUNTING_DATE", ordinal = 3)
  private LocalDateTime ACCOUNTING_DATE;

  @JSONField(name = "CURRENCY_CODE", ordinal = 4)
  private String CURRENCY_CODE;

  @JSONField(name = "DATE_CREATED", ordinal = 5)
  private LocalDateTime DATE_CREATED;

  @JSONField(name = "CREATED_BY", ordinal = 6)
  private String CREATED_BY;

  @JSONField(name = "ACTUAL_FLAG", ordinal = 7)
  private String ACTUAL_FLAG;

  @JSONField(name = "USER_JE_CATEGORY_NAME", ordinal = 8)
  private String USER_JE_CATEGORY_NAME;

  @JSONField(name = "USER_JE_SOURCE_NAME", ordinal = 9)
  private String USER_JE_SOURCE_NAME;

  @JSONField(name = "CURRENCY_CONVERSION_DATE", ordinal = 20)
  private LocalDate CURRENCY_CONVERSION_DATE;

  @JSONField(name = "ENCUMBRANCE_TYPE_ID", ordinal = 21)
  private String ENCUMBRANCE_TYPE_ID;

  @JSONField(name = "BUDGET_VERSION_ID", ordinal = 22)
  private String BUDGET_VERSION_ID;

  @JSONField(name = "USER_CURRENCY_CONVERSION_TYPE", ordinal = 23)
  private String USER_CURRENCY_CONVERSION_TYPE;

  @JSONField(name = "CURRENCY_CONVERSION_RATE", ordinal = 24)
  private String CURRENCY_CONVERSION_RATE;

  @JSONField(name = "AVERAGE_JOURNAL_FLAG", ordinal = 25)
  private String AVERAGE_JOURNAL_FLAG;

  @JSONField(name = "ORIGINATING_BAL_SEG_VALUE", ordinal = 26)
  private String ORIGINATING_BAL_SEG_VALUE;

  @JSONField(name = "SEGMENT1", ordinal = 27)
  private String SEGMENT1;

  @JSONField(name = "SEGMENT2", ordinal = 28)
  private String SEGMENT2;

  @JSONField(name = "SEGMENT3", ordinal = 29)
  private String SEGMENT3;

  @JSONField(name = "SEGMENT4", ordinal = 40)
  private String SEGMENT4;

  @JSONField(name = "SEGMENT5", ordinal = 41)
  private String SEGMENT5;

  @JSONField(name = "SEGMENT6", ordinal = 42)
  private String SEGMENT6;

  @JSONField(name = "SEGMENT7", ordinal = 43)
  private String SEGMENT7;

  @JSONField(name = "SEGMENT8", ordinal = 44)
  private String SEGMENT8;

  @JSONField(name = "SEGMENT9", ordinal = 45)
  private String SEGMENT9;

  @JSONField(name = "SEGMENT10", ordinal = 46)
  private String SEGMENT10;

  @JSONField(name = "SEGMENT11", ordinal = 47)
  private String SEGMENT11;

  @JSONField(name = "SEGMENT12", ordinal = 48)
  private String SEGMENT12;

  @JSONField(name = "SEGMENT13", ordinal = 49)
  private String SEGMENT13;

  @JSONField(name = "SEGMENT14", ordinal = 60)
  private String SEGMENT14;

  @JSONField(name = "SEGMENT15", ordinal = 61)
  private String SEGMENT15;

  @JSONField(name = "SEGMENT16", ordinal = 62)
  private String SEGMENT16;

  @JSONField(name = "SEGMENT17", ordinal = 63)
  private String SEGMENT17;

  @JSONField(name = "SEGMENT18", ordinal = 64)
  private String SEGMENT18;

  @JSONField(name = "SEGMENT19", ordinal = 65)
  private String SEGMENT19;

  @JSONField(name = "SEGMENT20", ordinal = 66)
  private String SEGMENT20;

  @JSONField(name = "SEGMENT21", ordinal = 67)
  private String SEGMENT21;

  @JSONField(name = "SEGMENT22", ordinal = 68)
  private String SEGMENT22;

  @JSONField(name = "SEGMENT23", ordinal = 69)
  private String SEGMENT23;

  @JSONField(name = "SEGMENT24", ordinal = 80)
  private String SEGMENT24;

  @JSONField(name = "SEGMENT25", ordinal = 81)
  private String SEGMENT25;

  @JSONField(name = "SEGMENT26", ordinal = 82)
  private String SEGMENT26;

  @JSONField(name = "SEGMENT27", ordinal = 83)
  private String SEGMENT27;

  @JSONField(name = "SEGMENT28", ordinal = 84)
  private String SEGMENT28;

  @JSONField(name = "SEGMENT29", ordinal = 85)
  private String SEGMENT29;

  @JSONField(name = "SEGMENT30", ordinal = 86)
  private String SEGMENT30;

  @JSONField(name = "ENTERED_DR", ordinal = 87)
  private BigDecimal ENTERED_DR;

  @JSONField(name = "ENTERED_CR", ordinal = 88)
  private BigDecimal ENTERED_CR;

  @JSONField(name = "ACCOUNTED_DR", ordinal = 89)
  private BigDecimal ACCOUNTED_DR;

  @JSONField(name = "ACCOUNTED_CR", ordinal = 100)
  private BigDecimal ACCOUNTED_CR;

  @JSONField(name = "TRANSACTION_DATE", ordinal = 101)
  private LocalDate TRANSACTION_DATE;

  @JSONField(name = "REFERENCE1", ordinal = 102)
  private String REFERENCE1;

  @JSONField(name = "REFERENCE2", ordinal = 103)
  private String REFERENCE2;

  @JSONField(name = "REFERENCE3", ordinal = 104)
  private String REFERENCE3;

  @JSONField(name = "REFERENCE4", ordinal = 105)
  private String REFERENCE4;

  @JSONField(name = "REFERENCE5", ordinal = 106)
  private String REFERENCE5;

  @JSONField(name = "REFERENCE6", ordinal = 107)
  private String REFERENCE6;

  @JSONField(name = "REFERENCE7", ordinal = 108)
  private String REFERENCE7;

  @JSONField(name = "REFERENCE8", ordinal = 109)
  private String REFERENCE8;

  @JSONField(name = "REFERENCE9", ordinal = 120)
  private String REFERENCE9;

  @JSONField(name = "REFERENCE10", ordinal = 121)
  private String REFERENCE10;

  @JSONField(name = "REFERENCE11", ordinal = 122)
  private String REFERENCE11;

  @JSONField(name = "REFERENCE12", ordinal = 123)
  private String REFERENCE12;

  @JSONField(name = "REFERENCE13", ordinal = 124)
  private String REFERENCE13;

  @JSONField(name = "REFERENCE14", ordinal = 125)
  private String REFERENCE14;

  @JSONField(name = "REFERENCE15", ordinal = 126)
  private String REFERENCE15;

  @JSONField(name = "REFERENCE16", ordinal = 127)
  private String REFERENCE16;

  @JSONField(name = "REFERENCE17", ordinal = 128)
  private String REFERENCE17;

  @JSONField(name = "REFERENCE18", ordinal = 129)
  private String REFERENCE18;

  @JSONField(name = "REFERENCE19", ordinal = 140)
  private String REFERENCE19;

  @JSONField(name = "REFERENCE20", ordinal = 141)
  private String REFERENCE20;

  @JSONField(name = "REFERENCE21", ordinal = 142)
  private String REFERENCE21;

  @JSONField(name = "REFERENCE22", ordinal = 143)
  private String REFERENCE22;

  @JSONField(name = "REFERENCE23", ordinal = 144)
  private String REFERENCE23;

  @JSONField(name = "REFERENCE24", ordinal = 145)
  private String REFERENCE24;

  @JSONField(name = "REFERENCE25", ordinal = 146)
  private String REFERENCE25;

  @JSONField(name = "REFERENCE26", ordinal = 147)
  private String REFERENCE26;

  @JSONField(name = "REFERENCE27", ordinal = 148)
  private String REFERENCE27;

  @JSONField(name = "REFERENCE28", ordinal = 149)
  private String REFERENCE28;

  @JSONField(name = "REFERENCE29", ordinal = 160)
  private String REFERENCE29;

  @JSONField(name = "REFERENCE30", ordinal = 161)
  private String REFERENCE30;

  @JSONField(name = "JE_BATCH_ID", ordinal = 162)
  private String JE_BATCH_ID;

  @JSONField(name = "PERIOD_NAME", ordinal = 163)
  private String PERIOD_NAME;

  @JSONField(name = "JE_HEADER_ID", ordinal = 164)
  private String JE_HEADER_ID;

  @JSONField(name = "JE_LINE_NUM", ordinal = 165)
  private String JE_LINE_NUM;

  @JSONField(name = "CHART_OF_ACCOUNTS_ID", ordinal = 166)
  private String CHART_OF_ACCOUNTS_ID;

  @JSONField(name = "FUNCTIONAL_CURRENCY_CODE", ordinal = 168)
  private String FUNCTIONAL_CURRENCY_CODE;

  @JSONField(name = "CODE_COMBINATION_ID", ordinal = 169)
  private String CODE_COMBINATION_ID;

  @JSONField(name = "DATE_CREATED_IN_GL", ordinal = 180)
  private LocalDate DATE_CREATED_IN_GL;

  @JSONField(name = "WARNING_CODE", ordinal = 181)
  private String WARNING_CODE;

  @JSONField(name = "STATUS_DESCRIPTION", ordinal = 182)
  private String STATUS_DESCRIPTION;

  @JSONField(name = "STAT_AMOUNT", ordinal = 183)
  private BigDecimal STAT_AMOUNT;

  @JSONField(name = "GROUP_ID", ordinal = 184)
  private String GROUP_ID;

  @JSONField(name = "REQUEST_ID", ordinal = 186)
  private String REQUEST_ID;

  @JSONField(name = "SUBLEDGER_DOC_SEQUENCE_ID", ordinal = 187)
  private String SUBLEDGER_DOC_SEQUENCE_ID;

  @JSONField(name = "SUBLEDGER_DOC_SEQUENCE_VALUE", ordinal = 188)
  private String SUBLEDGER_DOC_SEQUENCE_VALUE;

  @JSONField(name = "ATTRIBUTE1", ordinal = 189)
  private String ATTRIBUTE1;

  @JSONField(name = "ATTRIBUTE2", ordinal = 200)
  private String ATTRIBUTE2;

  @JSONField(name = "GL_SL_LINK_ID", ordinal = 201)
  private String GL_SL_LINK_ID;

  @JSONField(name = "GL_SL_LINK_TABLE", ordinal = 202)
  private String GL_SL_LINK_TABLE;

  @JSONField(name = "ATTRIBUTE3", ordinal = 203)
  private String ATTRIBUTE3;

  @JSONField(name = "ATTRIBUTE4", ordinal = 204)
  private String ATTRIBUTE4;

  @JSONField(name = "ATTRIBUTE5", ordinal = 205)
  private String ATTRIBUTE5;

  @JSONField(name = "ATTRIBUTE6", ordinal = 206)
  private String ATTRIBUTE6;

  @JSONField(name = "ATTRIBUTE7", ordinal = 207)
  private String ATTRIBUTE7;

  @JSONField(name = "ATTRIBUTE8", ordinal = 208)
  private String ATTRIBUTE8;

  @JSONField(name = "ATTRIBUTE9", ordinal = 209)
  private String ATTRIBUTE9;

  @JSONField(name = "ATTRIBUTE10", ordinal = 220)
  private String ATTRIBUTE10;

  @JSONField(name = "ATTRIBUTE11", ordinal = 221)
  private String ATTRIBUTE11;

  @JSONField(name = "ATTRIBUTE12", ordinal = 222)
  private String ATTRIBUTE12;

  @JSONField(name = "ATTRIBUTE13", ordinal = 223)
  private String ATTRIBUTE13;

  @JSONField(name = "ATTRIBUTE14", ordinal = 224)
  private String ATTRIBUTE14;

  @JSONField(name = "ATTRIBUTE15", ordinal = 225)
  private String ATTRIBUTE15;

  @JSONField(name = "ATTRIBUTE16", ordinal = 226)
  private String ATTRIBUTE16;

  @JSONField(name = "ATTRIBUTE17", ordinal = 227)
  private String ATTRIBUTE17;

  @JSONField(name = "ATTRIBUTE18", ordinal = 228)
  private String ATTRIBUTE18;

  @JSONField(name = "ATTRIBUTE19", ordinal = 229)
  private String ATTRIBUTE19;

  @JSONField(name = "ATTRIBUTE20", ordinal = 240)
  private String ATTRIBUTE20;

  @JSONField(name = "CONTEXT", ordinal = 241)
  private String CONTEXT;

  @JSONField(name = "CONTEXT2", ordinal = 242)
  private String CONTEXT2;

  @JSONField(name = "INVOICE_DATE", ordinal = 243)
  private LocalDate INVOICE_DATE;

  @JSONField(name = "TAX_CODE", ordinal = 244)
  private String TAX_CODE;

  @JSONField(name = "INVOICE_IDENTIFIER", ordinal = 245)
  private String INVOICE_IDENTIFIER;

  @JSONField(name = "INVOICE_AMOUNT", ordinal = 246)
  private BigDecimal INVOICE_AMOUNT;

  @JSONField(name = "CONTEXT3", ordinal = 247)
  private String CONTEXT3;

  @JSONField(name = "USSGL_TRANSACTION_CODE", ordinal = 248)
  private String USSGL_TRANSACTION_CODE;

  @JSONField(name = "DESCR_FLEX_ERROR_MESSAGE", ordinal = 249)
  private String DESCR_FLEX_ERROR_MESSAGE;

  @JSONField(name = "JGZZ_RECON_REF", ordinal = 260)
  private String JGZZ_RECON_REF;

  @JSONField(name = "REFERENCE_DATE", ordinal = 261)
  private LocalDate REFERENCE_DATE;

  @JSONField(name = "SET_OF_BOOKS_ID", ordinal = 262)
  private String SET_OF_BOOKS_ID;

  @JSONField(name = "BALANCING_SEGMENT_VALUE", ordinal = 263)
  private String BALANCING_SEGMENT_VALUE;

  @JSONField(name = "MANAGEMENT_SEGMENT_VALUE", ordinal = 264)
  private String MANAGEMENT_SEGMENT_VALUE;

  @JSONField(name = "FUNDS_RESERVED_FLAG", ordinal = 265)
  private String FUNDS_RESERVED_FLAG;

  @JSONField(name = "CODE_COMBINATION_ID_INTERIM", ordinal = 266)
  private String CODE_COMBINATION_ID_INTERIM;

  @JSONField(name = "AE_HEAD_DESCRIPTION", ordinal = 267)
  private String AE_HEAD_DESCRIPTION;

  @JSONField(name = "AE_LINE_DESCRIPTION", ordinal = 268)
  private String AE_LINE_DESCRIPTION;

  @JSONField(name = "AE_SOURCE_SYSTEM", ordinal = 269)
  private String AE_SOURCE_SYSTEM;

  @JSONField(name = "AE_STATUS", ordinal = 280)
  private String AE_STATUS;

  @JSONField(name = "AE_MERGE_FLAG", ordinal = 281)
  private String AE_MERGE_FLAG;

  @JSONField(name = "AE_SIDE_CODE", ordinal = 282)
  private String AE_SIDE_CODE;

  @JSONField(name = "SOURCE_BATCH_ID", ordinal = 283)
  private String SOURCE_BATCH_ID;

  @JSONField(name = "SOURCE_HEAD_ID", ordinal = 284)
  private String SOURCE_HEAD_ID;

  @JSONField(name = "SOURCE_LINE_ID", ordinal = 285)
  private String SOURCE_LINE_ID;

  @JSONField(name = "AE_ROW_ID", ordinal = 286)
  private String AE_ROW_ID;

  @JSONField(name = "AE_MERGE_ROW_ID", ordinal = 287)
  private String AE_MERGE_ROW_ID;

  @JSONField(name = "AE_LINE_NUM", ordinal = 288)
  private BigDecimal AE_LINE_NUM;

  @JSONField(name = "AE_CREATE_TIME", ordinal = 289)
  private LocalDateTime AE_CREATE_TIME;

  @JSONField(name = "AE_BATCH_ID", ordinal = 300)
  private String AE_BATCH_ID;

  @JSONField(name = "AE_REVERSE_STATUS", ordinal = 301)
  private String AE_REVERSE_STATUS;

  @JSONField(name = "INTERFACE_ID", ordinal = 302)
  private String INTERFACE_ID;

  @JSONField(name = "CREATION_DATE", ordinal = 303)
  private LocalDateTime CREATION_DATE;

}
