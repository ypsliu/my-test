package com.deloitte.bdh.ae.client;

import com.deloitte.bdh.common.context.ThreadContextHolder;
import java.lang.reflect.Method;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.cache.interceptor.SimpleKey;
import org.springframework.stereotype.Component;

/**
 * @author Ashen
 * @date 17/12/2020
 */
@Component("feignKeyGenerator")
public class FeignKeyGenerator implements KeyGenerator {

  @Override
  public Object generate(Object target, Method method, Object... params) {
    if (params.length == 0) {
      return ThreadContextHolder.getTenant().getTenantCode() + ":" + ThreadContextHolder.getLang();
    }
    return new SimpleKey(params);
  }
}
