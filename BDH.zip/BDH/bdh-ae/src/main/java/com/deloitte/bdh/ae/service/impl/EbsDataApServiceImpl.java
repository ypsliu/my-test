package com.deloitte.bdh.ae.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.baomidou.dynamic.datasource.annotation.DS;
import com.deloitte.bdh.ae.model.TargetSourceBasicInfo;
import com.deloitte.bdh.ae.model.io.ebsap.ApInvoicesInput;
import com.deloitte.bdh.ae.model.io.ebsap.CREATE_INVOICES_Input;
import com.deloitte.bdh.ae.model.io.ebsap.EbsApResponse;
import com.deloitte.bdh.ae.model.io.ebsap.EbsApResponseErrorDetail;
import com.deloitte.bdh.ae.model.io.ebsap.InputParameters;
import com.deloitte.bdh.ae.model.io.ebsap.P_INVOICES_TBL;
import com.deloitte.bdh.ae.model.io.ebsap.P_INVOICES_TBL_ITEM;
import com.deloitte.bdh.ae.service.AeSourceBatchService;
import com.deloitte.bdh.ae.service.EbsDataApService;
import com.deloitte.bdh.ae.service.TargetApInterfaceService;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.common.exception.BizException;
import com.deloitte.bdh.common.http.HttpClientUtil;
import com.deloitte.bdh.engine.runtime.ErrorMessageService;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.annotation.Resource;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Ashen
 * @date 21/04/2020
 */
@Service
@RefreshScope
@DS(DSConstant.AE_DB)
@Transactional(rollbackFor = Exception.class)
public class EbsDataApServiceImpl implements EbsDataApService {

  @Resource
  private AeSourceBatchService aeSourceBatchService;

  @Resource
  private TargetApInterfaceService targetApInterfaceService;

  @Autowired
  private ErrorMessageService errorMessageService;

  @Value("${ebs.ap.host.url}")
  private String ebsApHostUrl;

  @Value("${ebs.auth}")
  private String ebsAuth;

  @Override
  public void putDataToEbsAp(String aeBatchId) {
    try {
      List<P_INVOICES_TBL_ITEM> itemList = targetApInterfaceService.queryInvoicesItem(aeBatchId);
      if (itemList.isEmpty()) {
        throw new BizException("发票信息不能为空！");
      }
      ApInvoicesInput apInvoicesInput = new ApInvoicesInput();
      CREATE_INVOICES_Input create_invoices_input = new CREATE_INVOICES_Input();
      apInvoicesInput.setCREATE_INVOICES_Input(create_invoices_input);
      InputParameters inputParameters = new InputParameters();
      create_invoices_input.setInputParameters(inputParameters);
      P_INVOICES_TBL p_invoices_tbl = new P_INVOICES_TBL();
      inputParameters.setP_INVOICES_TBL(p_invoices_tbl);
      p_invoices_tbl.setP_INVOICES_TBL_ITEM(itemList);

      Map<String, Object> header = new HashMap<>();
      byte[] authBytes = new byte[0];
      authBytes = ebsAuth.getBytes("UTF-8");
      String baseAuth = Base64.encodeBase64String(authBytes);
      header.put("Authorization", "Basic " + baseAuth);
      String payload = JSON.toJSONString(apInvoicesInput, SerializerFeature.WriteMapNullValue);
      CloseableHttpResponse response = HttpClientUtil
          .httpPostRequestByJsonAndReturnResponse(ebsApHostUrl, header, payload);
      if (null != response) {
        if (response.getStatusLine().getStatusCode() != 200) {
          throw new BizException("返回错误的接口状态");
        }
        HttpEntity entity = response.getEntity();
        if (entity != null) {
          String result = EntityUtils.toString(entity);
          response.close();
          EbsApResponse ebsApResponse = JSON.parseObject(result, EbsApResponse.class);
          if ("S".equals(ebsApResponse.getOutputParameters().getX_RETURN_STATUS())) {
            aeSourceBatchService
                .updateBatchEbsStatus(aeBatchId, "FINAL_ACCOUNT", "DOING",
                    "OK");
            return;
          } else {
            String data = ebsApResponse.getOutputParameters().getX_MSG_DATA();
            try {
              //如果能解析为数组
              List<EbsApResponseErrorDetail> list = JSON
                  .parseArray(data, EbsApResponseErrorDetail.class);
              Set<String> lineNumberSet = new HashSet<>();
              list.forEach(ebsApResponseErrorDetail -> {
                lineNumberSet.add(ebsApResponseErrorDetail.getLine_number());
              });
              List<TargetSourceBasicInfo> sourceBasicInfoList = targetApInterfaceService
                  .selectByLineNumberSet(lineNumberSet);
              Map<String, TargetSourceBasicInfo> sourceBasicInfoMap = sourceBasicInfoList.stream()
                  .collect(
                      Collectors.toMap(TargetSourceBasicInfo::getAeRowId, Function.identity()));

              list.forEach(ebsApResponseErrorDetail -> {
                TargetSourceBasicInfo targetSourceBasicInfo = sourceBasicInfoMap
                    .get(ebsApResponseErrorDetail.getLine_number());
                if (targetSourceBasicInfo == null) {
                  errorMessageService
                      .insertErrorMessage(aeBatchId, ebsApResponseErrorDetail.getErr_msg());
                } else {
                  errorMessageService
                      .insertErrorMessage(aeBatchId, targetSourceBasicInfo.getSourceBatchId(),
                          targetSourceBasicInfo.getSourceHeadId(),
                          targetSourceBasicInfo.getSourceLineId(),
                          ebsApResponseErrorDetail.getErr_msg());
                }
              });
            } catch (Exception e) {
              //不能解析为数据，则为错误信息
              throw new BizException(ebsApResponse.getOutputParameters().getX_MSG_DATA());
            }
          }
        }
      }
    } catch (Exception e) {
      throw new BizException("调用EBS接口异常：" + e.getMessage());
    }
    throw new BizException("调用EBS接口异常");
  }

}
