package com.deloitte.bdh.ae.model.io.expense;

import com.deloitte.bdh.ae.model.SourceExpenseReceivableLine;

public class ExpReceivableApplLinesInput extends SourceExpenseReceivableLine {


}