package com.deloitte.bdh.ae.service;

/**
 * @author Ashen
 * @date 21/04/2020
 */
public interface EbsDataApPaymentService {

  /**
   * 推送数据到EBS Ap支付
   *
   * @param aeBatchId
   */
  void putDataToEbsApPayment(String aeBatchId);
}
