package com.deloitte.bdh.ae.client.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;

/**
 * @author Ashen
 * @date 17/12/2020
 */
@Data
@ApiModel(description = "组织列表响应视图")
public class OrganizationClientVo implements Serializable {

  private static final long serialVersionUID = 4678597348895976552L;

  @ApiModelProperty(value = "组织id")
  private String organizationId;

  @ApiModelProperty(value = "组织code")
  private String organizationCode;

  @ApiModelProperty(value = "组织名")
  private String organizationName;

  @ApiModelProperty(value = "父组织ID")
  private String parentOrganizationId;

  @ApiModelProperty(value = "组织类型")
  private String organizationTypeEnumVal;
}
