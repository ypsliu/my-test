package com.deloitte.bdh.common.properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author Ashen
 * @date 12/11/2020
 */
@Component
public class ApplicationProperties {

  @Value(value = "${server.port}")
  private String serverPort;

  @Value(value = "${spring.application.name}")
  private String applicationName;

  public String getServerPort() {
    return serverPort;
  }

  public void setServerPort(String serverPort) {
    this.serverPort = serverPort;
  }

  public String getApplicationName() {
    return applicationName;
  }

  public void setApplicationName(String applicationName) {
    this.applicationName = applicationName;
  }
}
