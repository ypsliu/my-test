package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.deloitte.bdh.ae.dao.base.BaseTenantMapper;
import com.deloitte.bdh.ae.model.BaseTenant;
import com.deloitte.bdh.ae.service.BaseTenantService;
import com.deloitte.bdh.common.base.ServiceNoTransactionalImpl;
import com.deloitte.bdh.common.constant.DSConstant;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 租户表 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2020-09-09
 */
@Service
@DS(DSConstant.BASE_DB)
public class BaseTenantServiceImpl extends
    ServiceNoTransactionalImpl<BaseTenantMapper, BaseTenant> implements
    BaseTenantService {

  @Override
  public BaseTenant getTenantByCode(String tenantCode) {
    if (StringUtils.isBlank(tenantCode)) {
      return null;
    }
    return getOne(new LambdaQueryWrapper<BaseTenant>()
        .eq(BaseTenant::getTenantCode, tenantCode), false);
  }
}
