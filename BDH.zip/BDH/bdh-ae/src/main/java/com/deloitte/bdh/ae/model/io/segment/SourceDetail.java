package com.deloitte.bdh.ae.model.io.segment;

import com.deloitte.bdh.ae.model.io.target.TargetSegmentDetail;
import java.util.List;
import lombok.Data;

/**
 * @author Ashen
 * @date 24/04/2020
 */
@Data
public class SourceDetail {

  private String aeBatchId;
  private String sourceHeadId;
  private String sourceLineId;

  private List<TargetSegmentDetail> targetSegmentDetailList;
}
