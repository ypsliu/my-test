package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.deloitte.bdh.ae.client.FeignClientService;
import com.deloitte.bdh.ae.client.model.FndPortalLanguage;
import com.deloitte.bdh.ae.dao.ae.AeReportTemplateMapper;
import com.deloitte.bdh.ae.model.AeApplication;
import com.deloitte.bdh.ae.model.AeReportTempField;
import com.deloitte.bdh.ae.model.AeReportTempOrg;
import com.deloitte.bdh.ae.model.AeReportTemplate;
import com.deloitte.bdh.ae.model.AeSourceLoadTable;
import com.deloitte.bdh.ae.model.AeTarget;
import com.deloitte.bdh.ae.model.dto.ReportDto;
import com.deloitte.bdh.ae.model.dto.ReportRunDto;
import com.deloitte.bdh.ae.model.vo.CompanyDataPermissionVo;
import com.deloitte.bdh.ae.model.vo.HeadProperty;
import com.deloitte.bdh.ae.service.AeApplicationService;
import com.deloitte.bdh.ae.service.AeDataService;
import com.deloitte.bdh.ae.service.AeReportTempFieldService;
import com.deloitte.bdh.ae.service.AeReportTempOrgService;
import com.deloitte.bdh.ae.service.AeReportTemplateService;
import com.deloitte.bdh.ae.service.AeSourceLoadTableService;
import com.deloitte.bdh.ae.service.AeTargetService;
import com.deloitte.bdh.ae.service.EnumService;
import com.deloitte.bdh.ae.service.LocaleMessageSourceService;
import com.deloitte.bdh.common.base.PageHeadResult;
import com.deloitte.bdh.common.base.PageRequest;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.ServiceTransactionalImpl;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.common.exception.BizException;
import com.deloitte.bdh.common.util.AssertUtils;
import com.deloitte.bdh.common.util.StringUtil;
import com.deloitte.bdh.engine.runtime.entity.DataLine;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.annotation.Resource;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Service
@DS(DSConstant.AE_DB)
public class AeReportTemplateServiceImpl extends
    ServiceTransactionalImpl<AeReportTemplateMapper, AeReportTemplate> implements
    AeReportTemplateService {

  @Resource
  private AeReportTemplateService aeReportTemplateService;
  @Resource
  private AeReportTempOrgService aeReportTempOrgService;
  @Resource
  private AeReportTempFieldService aeReportTempFieldService;
  @Resource
  private AeTargetService aeTargetService;
  @Resource
  private AeSourceLoadTableService aeSourceLoadTableService;
  @Resource
  private AeDataService aeDataService;
  @Resource
  private AeApplicationService aeApplicationService;
  @Resource
  private LocaleMessageSourceService localeMessageSourceService;
  @Autowired
  private FeignClientService feignClientService;
  @Autowired
  private EnumService enumService;

  @Override
  public List<AeReportTemplate> selectByPage(PageRequest<AeReportTemplate> pageRequest) {
    AeReportTemplate dto = pageRequest.getData();
    if (dto == null) {
      throw new BizException("报表查询参数不能为空!");
    }
    if (dto.getApplicationId() == null) {
      throw new BizException("应用产品不能为空！");
    }
    Set<String> reportIdSet = getReportIdSetSecurity(pageRequest);

    PageHelper.startPage(pageRequest.getPage(), pageRequest.getSize());
    List<AeReportTemplate> list = aeReportTemplateService
        .list(new LambdaQueryWrapper<AeReportTemplate>()
            .eq(AeReportTemplate::getApplicationId, dto.getApplicationId())
            .like(Strings.isNotEmpty(dto.getReportName()), AeReportTemplate::getReportName,
                dto.getReportName())
            .and(wrapper -> wrapper.eq(AeReportTemplate::getOwnerId, pageRequest.getOperator())
                .or()
                .in(AeReportTemplate::getReportId, reportIdSet)));
    if (list.size() == 0) {
      return list;
    }
    Map<String, String> ownerTypeLovMap = enumService.getSystemEnumValueMap("BDH_OWNER_TYPE");

    Set<String> applicationIdSet = new HashSet<>();
    list.forEach(template -> {
      applicationIdSet.add(template.getApplicationId());
    });
    List<AeApplication> aeApplicationList = aeApplicationService
        .list(new LambdaQueryWrapper<AeApplication>()
            .in(AeApplication::getApplicationId, applicationIdSet));

    Map<String, AeApplication> aeApplicationMap = aeApplicationList.stream()
        .collect(Collectors.toMap(AeApplication::getApplicationId, Function.identity()));
    List<FndPortalLanguage> langList = feignClientService.getLanguageList();
    Map<String, FndPortalLanguage> langMap = langList.stream()
        .collect(Collectors.toMap(FndPortalLanguage::getCode, Function.identity()));

    list.forEach(template -> {
      AeApplication aeApplication = aeApplicationMap.get(template.getApplicationId());
      FndPortalLanguage fndPortalLanguage = langMap.get(template.getLang());
      template.setApplicationName(aeApplication != null ? aeApplication.getApplicationName() : "");
      template.setLangShow(fndPortalLanguage != null ? fndPortalLanguage.getName() : "");
      template.setOwnerTypeShow(ownerTypeLovMap.get(template.getOwnerType()));
    });
    return list;
  }

  /**
   * 根据安全性检查可以查到的报表ID <p> 1、如果前端传了公司，走该公司安全性；<p> 2、如果没传公司，当前登录人有权限公司安全性<p>
   *
   * @param pageRequest
   * @return
   */
  private Set<String> getReportIdSetSecurity(PageRequest<AeReportTemplate> pageRequest) {
    AeReportTemplate aeReportTemplate = pageRequest.getData();
    Set<String> reportIdSet = new HashSet<>();
    Set<String> organizationIdSet = new HashSet<>();
    //数据安全性:1、拥有者为自己；
    if (StringUtil.isNotEmpty(aeReportTemplate.getOrganizationId())) {
      organizationIdSet.add(aeReportTemplate.getOrganizationId());
    } else {
      List<CompanyDataPermissionVo> companyDataPermissionVoList = feignClientService
          .getUserDataPermissions();
      companyDataPermissionVoList.forEach(companyDataPermissionVo -> {
        organizationIdSet.add(companyDataPermissionVo.getOrganizationId());
      });
      if (organizationIdSet.isEmpty()) {
        organizationIdSet.add("-1");
      }
    }
    List<AeReportTempOrg> reportTempOrgList = aeReportTempOrgService
        .list(new LambdaQueryWrapper<AeReportTempOrg>()
            .in(AeReportTempOrg::getOrganizationId, organizationIdSet));

    reportTempOrgList.forEach(aeReportTempOrg -> {
      reportIdSet.add(aeReportTempOrg.getReportId());
    });
    if (reportIdSet.isEmpty()) {
      reportIdSet.add("-1");
    }
    return reportIdSet;
  }

  @Override
  @Transactional(rollbackFor = Exception.class)
  public void insertData(RetRequest<AeReportTemplate> retRequest) {
    AeReportTemplate aeReportTemplate = retRequest.getData();
    aeReportTemplate.setReportId(this.getSequence());
    aeReportTemplate.setOwnerId(retRequest.getOperator());
    insertOrganization(aeReportTemplate.getOrganizationList(), aeReportTemplate.getReportId());
    insertField(aeReportTemplate.getFieldList(), aeReportTemplate.getReportId());
    this.save(aeReportTemplate);
  }

  /**
   * 新增字段
   *
   * @param fieldList
   * @param reportId
   */
  private void insertField(List<AeReportTempField> fieldList, String reportId) {
    if (fieldList != null) {
      fieldList.forEach(aeReportTempField -> {
        aeReportTempField.setFieldId(this.getSequence());
        aeReportTempField.setReportId(reportId);
        aeReportTempFieldService.save(aeReportTempField);
      });
    }
  }

  /**
   * 新增公司
   *
   * @param organizationList
   * @param reportId
   */
  private void insertOrganization(List<CompanyDataPermissionVo> organizationList,
      String reportId) {
    if (organizationList != null) {
      organizationList.forEach(companyDataPermissionVo -> {
        if (companyDataPermissionVo.getSelectedFlag()) {
          AeReportTempOrg aeReportTempOrg = new AeReportTempOrg();
          aeReportTempOrg.setReportOrganizationId(this.getSequence());
          aeReportTempOrg.setReportId(reportId);
          aeReportTempOrg.setOrganizationId(companyDataPermissionVo.getOrganizationId());
          aeReportTempOrgService.save(aeReportTempOrg);
        }
      });
    }
  }

  @Override
  @Transactional(rollbackFor = Exception.class)
  public void updateData(RetRequest<AeReportTemplate> retRequest) {
    AeReportTemplate dto = retRequest.getData();
    if (dto == null || dto.getReportId() == null) {
      throw new BizException("报表ID不能为空！");
    }
    aeReportTempOrgService.remove(new LambdaQueryWrapper<AeReportTempOrg>()
        .eq(AeReportTempOrg::getReportId, dto.getReportId()));
    aeReportTempFieldService.remove(new LambdaQueryWrapper<AeReportTempField>()
        .eq(AeReportTempField::getReportId, dto.getReportId()));
    insertOrganization(dto.getOrganizationList(), dto.getReportId());
    insertField(dto.getFieldList(), dto.getReportId());
    aeReportTemplateService.updateById(dto);
  }

  @Override
  public PageHeadResult<DataLine> reportResult(PageRequest<ReportRunDto> pageRequest) {
    PageHeadResult<DataLine> result = new PageHeadResult<>();
    ReportRunDto dto = pageRequest.getData();
    List<AeReportTempField> fieldList = aeReportTempFieldService
        .list(new LambdaQueryWrapper<AeReportTempField>()
            .eq(AeReportTempField::getReportId, dto.getReportId())
            .orderByAsc(AeReportTempField::getPriorityLevel));
    if (fieldList.size() == 0) {
      throw new BizException("报表配置的字段不能为空！");
    }
    Set<String> targetIdSet = fieldList.stream().map(AeReportTempField::getTargetId)
        .collect(Collectors.toSet());

    List<AeTarget> targetList = aeTargetService.list(new LambdaQueryWrapper<AeTarget>()
        .in(AeTarget::getTargetId, targetIdSet));
    Set<String> tableIdSet = new HashSet<>();
    targetList.forEach(aeTarget -> {
      tableIdSet.add(aeTarget.getTableId());
    });
    if (tableIdSet.size() != 1) {
      throw new BizException("字段信息不再一张目标表中");
    }
    List<HeadProperty> headPropertyList = createHeadList(fieldList, targetList);
    AeSourceLoadTable aeSourceLoadTable = aeSourceLoadTableService
        .getById(tableIdSet.iterator().next());
    String sql = createReportSql(aeSourceLoadTable.getTableName(), headPropertyList, dto);
    PageHelper.startPage(pageRequest.getPage(), pageRequest.getSize());
    List<DataLine> dataLineList = aeDataService.loadData(sql.toString());
    PageInfo<DataLine> pageInfo = new PageInfo<DataLine>(dataLineList);
    result.setHeadList(headPropertyList);
    result.setList(dataLineList);
    result.setTotal(pageInfo.getTotal());
    return result;
  }

  @Override
  public PageHeadResult<DataLine> reportResultExport(ReportRunDto dto) {
    PageHeadResult<DataLine> result = new PageHeadResult<>();
    List<AeReportTempField> fieldList = aeReportTempFieldService
        .list(new LambdaQueryWrapper<AeReportTempField>()
            .eq(AeReportTempField::getReportId, dto.getReportId())
            .orderByAsc(AeReportTempField::getPriorityLevel));
    if (fieldList.size() == 0) {
      throw new BizException("报表配置的字段不能为空！");
    }
    Set<String> targetIdSet = fieldList.stream().map(AeReportTempField::getTargetId).collect(
        Collectors.toSet());
    List<AeTarget> targetList = aeTargetService.list(new LambdaQueryWrapper<AeTarget>()
        .in(AeTarget::getTargetId, targetIdSet));
    Set<String> tableIdSet = new HashSet<>();
    targetList.forEach(aeTarget -> {
      tableIdSet.add(aeTarget.getTableId());
    });
    if (tableIdSet.size() != 1) {
      throw new BizException("字段信息不再一张目标表中");
    }
    List<HeadProperty> headPropertyList = createHeadList(fieldList, targetList);
    AeSourceLoadTable aeSourceLoadTable = aeSourceLoadTableService
        .getById(tableIdSet.iterator().next());
    String sql = createReportSql(aeSourceLoadTable.getTableName(), headPropertyList, dto);
    List<DataLine> dataLineList = aeDataService.loadData(sql.toString());
    PageInfo<DataLine> pageInfo = new PageInfo<DataLine>(dataLineList);
    result.setHeadList(headPropertyList);
    result.setList(dataLineList);
    result.setTotal(pageInfo.getTotal());
    return result;
  }

  @Override
  public List<AeReportTemplate> queryConditionReportList(
      RetRequest<AeReportTemplate> retRequest) {
    AeReportTemplate dto = retRequest.getData();
    if (dto.getApplicationId() == null) {
      throw new BizException("应用产品不能为空！");
    }
    if (dto.getOrganizationId() == null) {
      throw new BizException("选择公司不能为空！");
    }
    List<AeReportTemplate> aeReportTemplateList = baseMapper
        .selectByApplicationAndOrganization(dto.getApplicationId(),
            dto.getOrganizationId(), retRequest.getLang());
    return aeReportTemplateList;
  }

  @Override
  public void checkPermission(RetRequest<ReportDto> retRequest) {
    List<CompanyDataPermissionVo> companyDataPermissionVoList = feignClientService
        .getUserDataPermissions();
    ReportDto dto = retRequest.getData();
    if (retRequest.getData() != null && retRequest.getData().getReportId() != null) {
      List<AeReportTempOrg> orgList = aeReportTempOrgService
          .list(new LambdaQueryWrapper<AeReportTempOrg>()
              .eq(AeReportTempOrg::getReportId, dto.getReportId()));

      //权限验证
      List<String> companyIds = companyDataPermissionVoList.stream()
          .map(CompanyDataPermissionVo::getOrganizationId)
          .filter(Objects::nonNull)
          .collect(Collectors.toList());

      List<String> orgIds = orgList.stream()
          .map(AeReportTempOrg::getOrganizationId)
          .filter(Objects::nonNull)
          .collect(Collectors.toList());

      if (companyIds.isEmpty() || !companyIds.containsAll(orgIds)) {
        throw new BizException(localeMessageSourceService
            .getMessage("NO_DATA_PERMISSION", retRequest.getLang()));
      }

    }
  }

  @Override
  @Transactional(rollbackFor = Exception.class)
  public void deleteData(String reportId) {
    AssertUtils.assertNotEmpty(reportId, "reportId不能为空！");
    aeReportTempOrgService.remove(new LambdaQueryWrapper<AeReportTempOrg>()
        .eq(AeReportTempOrg::getReportId, reportId));
    aeReportTempFieldService.remove(new LambdaQueryWrapper<AeReportTempField>()
        .eq(AeReportTempField::getReportId, reportId));
    aeReportTemplateService.removeById(reportId);
  }

  private String createReportSql(String tableName, List<HeadProperty> headPropertyList,
      ReportRunDto reportRunDto) {
    StringBuffer sql = new StringBuffer();
    sql.append("SELECT ");
    headPropertyList.forEach(headProperty -> {
      if (StringUtil.isNotEmpty(headProperty.getDataType()) && (
          headProperty.getDataType().toUpperCase().contains("DATE") || headProperty.getDataType()
              .toUpperCase().contains("TIME"))) {
        sql.append(" DATE_FORMAT( T1.").append(headProperty.getProperty())
            .append(", \"%Y/%m/%d\") as ").append(headProperty.getProperty()).append(",");
      } else {
        sql.append("T1.").append(headProperty.getProperty()).append(" ,");
      }
    });
    sql.deleteCharAt(sql.length() - 1);
    sql.append(" FROM ").append(tableName).append(" T1 ");
    sql.append(" LEFT JOIN AE_SOURCE_BATCH T2 ");
    sql.append(" ON T1.AE_BATCH_ID = T2.AE_BATCH_ID");
    sql.append(" LEFT JOIN AE_APPLICATION T3 ");
    sql.append(" ON T2.APPLICATION_CODE = T3.APPLICATION_CODE");
    sql.append(" WHERE T1.AE_STATUS = 'FINAL'");
    sql.append(" AND T2.AE_STATUS = 'OK'");
    if (reportRunDto.getOrganizationId() == null) {
      throw new BizException("公司不能为空！");
    } else {
      sql.append(" AND T2.ORGANIZATION_ID = '").append(reportRunDto.getOrganizationId())
          .append("'");
    }
    if (reportRunDto.getApplicationId() == null) {
      throw new BizException("应用产品不能为空！");
    } else {
      sql.append(" AND T3.APPLICATION_ID = '").append(reportRunDto.getApplicationId()).append("'");
    }
    if (Strings.isNotEmpty(reportRunDto.getAeBatchCode())) {
      sql.append(" AND T2.AE_BATCH_CODE = '").append(reportRunDto.getAeBatchCode()).append("'");
    }
    if (Strings.isNotEmpty(reportRunDto.getEntryType())) {
      sql.append(" AND T2.ENTRY_TYPE = '").append(reportRunDto.getEntryType()).append("'");
    }
    if (reportRunDto.getGlDateFrom() != null) {
      sql.append(" AND T1.ACCOUNTING_DATE >= STR_TO_DATE('")
          .append(reportRunDto.getGlDateFrom())
          .append("','%Y-%m-%d')");
    }
    if (reportRunDto.getGlDateTo() != null) {
      sql.append(" AND T1.ACCOUNTING_DATE <= STR_TO_DATE('")
          .append(reportRunDto.getGlDateTo())
          .append("','%Y-%m-%d')");
    }
    return sql.toString();
  }

  private List<HeadProperty> createHeadList(List<AeReportTempField> fieldList,
      List<AeTarget> targetList) {
    List<HeadProperty> headPropertyList = new ArrayList<>();
    Map<String, AeTarget> targetMap = targetList.stream()
        .collect(Collectors.toMap(AeTarget::getTargetId,
            Function.identity()));
    fieldList.forEach(aeReportTempField -> {
      AeTarget aeTarget = targetMap.get(aeReportTempField.getTargetId());
      if (aeTarget == null) {
        throw new BizException("字段关联的目标信息失败！");
      }
      headPropertyList
          .add(new HeadProperty(aeTarget.getTargetName(), aeReportTempField.getFieldName(),
              aeReportTempField.getWidth(), aeTarget.getTargetDataType()));
    });
    return headPropertyList;
  }
}
