package com.deloitte.bdh.ae.model.io.ebsgl;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

/**
 * @author Ashen
 * @date 09/02/2021
 */
@Data
public class GlInput {

  @JSONField(name = "IMPORT_ACCOUNTING")
  private IMPORT_ACCOUNTING importAccounting;
}
