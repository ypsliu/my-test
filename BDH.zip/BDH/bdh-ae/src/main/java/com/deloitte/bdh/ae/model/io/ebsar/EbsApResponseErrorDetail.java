package com.deloitte.bdh.ae.model.io.ebsar;

import lombok.Data;

/**
 * @author Ashen
 * @date 21/04/2020
 */
@Data
public class EbsApResponseErrorDetail {

  private String status;
  private String line_number;
  private String err_msg;
}
