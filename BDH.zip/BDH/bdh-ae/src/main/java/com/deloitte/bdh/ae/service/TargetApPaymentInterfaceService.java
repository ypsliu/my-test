package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.TargetApPaymentInterface;
import com.deloitte.bdh.ae.model.TargetSourceBasicInfo;
import com.deloitte.bdh.ae.model.io.ebsappayment.P_PAYMENTS_TBL_ITEM;
import com.deloitte.bdh.common.base.Service;
import java.util.List;
import java.util.Set;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface TargetApPaymentInterfaceService extends Service<TargetApPaymentInterface> {

  /**
   * 查询AP支付信息
   *
   * @param aeBatchId
   * @return
   */
  List<P_PAYMENTS_TBL_ITEM> queryPaymentsItem(String aeBatchId);

  /**
   * 根据apGrpNum 查询目标数据的来源基本信息
   *
   * @param apGrpNumSet
   * @param aeBatchId
   * @return
   */
  List<TargetSourceBasicInfo> selectByLineNumberSet(Set<String> apGrpNumSet, String aeBatchId);
}
