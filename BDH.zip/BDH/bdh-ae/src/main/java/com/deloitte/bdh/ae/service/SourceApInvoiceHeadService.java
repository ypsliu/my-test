package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.SourceApInvoiceHead;
import com.deloitte.bdh.ae.model.io.DataOutput;
import com.deloitte.bdh.ae.model.io.OneDataInput;
import com.deloitte.bdh.ae.model.io.ap.ApDataInput;
import com.deloitte.bdh.ae.model.io.target.TargetDataOutput;
import com.deloitte.bdh.common.base.Service;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface SourceApInvoiceHeadService extends Service<SourceApInvoiceHead> {

  DataOutput putData(ApDataInput apDataInput);

  TargetDataOutput getTargetDate(OneDataInput oneDataInput);
}
