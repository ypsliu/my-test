package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "AeJournalTypeAttribute对象", description = "")
public class AeJournalTypeAttribute extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableId("TYPE_ATTRIBUTE_ID")
  private String typeAttributeId;

  @TableField("JOURNAL_TYPE_ID")
  private String journalTypeId;

  @TableField("TARGET_ID")
  private String targetId;

  @TableField("SOURCE_ID")
  private String sourceId;

  @TableField("ACTIVE_FLAG")
  private Integer activeFlag;

  @TableField("DESCRIPTION")
  private String description;

  @TableField("PRIORITY_LEVEL")
  private BigDecimal priorityLevel;

  @TableField("SET_ID")
  private String setId;

  @TableField("SOURCE_TYPE")
  private String sourceType;

  @TableField("VALUE_DATA")
  private String valueData;


}
