package com.deloitte.bdh.engine.config.entity;

import lombok.Data;

/**
 * 映射集
 *
 * @author Ashen
 * @date 04/12/2019
 */
@Data
public class MapSetField {

  private String setId;

  private String sourceId;

  private String fieldOrder;
}
