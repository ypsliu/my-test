package com.deloitte.bdh.ae.model.vo;

import java.time.LocalDate;
import lombok.Data;

/**
 * @author Ashen
 * @date 20/02/2020
 */
@Data
public class TargetAccountVo {

  private String aeEbsNumber;
  private String userJeCategoryName;
  private String aeHeadDescription;
  private LocalDate accountingDate;
  private String currencyCode;
  private String currencyConversionRate;
  private String aeLineNum;
  private String segment;
  private String segmentDescription;
  private String enteredDr;
  private String enteredCr;
  private String accountedDr;
  private String accountedCr;
  private String aeLineDescription;
}
