package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.AeBatchSyncLog;
import com.deloitte.bdh.common.base.PageRequest;
import com.deloitte.bdh.common.base.Service;
import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface AeBatchSyncLogService extends Service<AeBatchSyncLog> {

  void insertSyncLog(String aeBatchId, String userId, String period, LocalDateTime startTime,
      LocalDateTime endTime, String status, String failReason);

  List<AeBatchSyncLog> selectList(PageRequest<Void> pageRequest);
}
