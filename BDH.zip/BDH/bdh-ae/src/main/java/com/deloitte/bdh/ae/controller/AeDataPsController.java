package com.deloitte.bdh.ae.controller;

import com.deloitte.bdh.ae.model.dto.PsDto;
import com.deloitte.bdh.ae.service.AeDataPsService;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.RetResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Ashen
 * @date 28/02/2020
 */
@RestController
@Api(tags = "数据同步:PS薪资数据")
@RequestMapping("/aeDataPs")
public class AeDataPsController {

  @Autowired
  private AeDataPsService aeDataPsService;

  @PostMapping("/putData")
  @ApiOperation(value = "同步PS数据创建批次信息")
  public RetResult<PsDto> putData(
      @RequestBody @Validated RetRequest<PsDto> psDtoRetRequest) {
    RetResult<PsDto> result = aeDataPsService.putData(psDtoRetRequest);
    return result;
  }
}
