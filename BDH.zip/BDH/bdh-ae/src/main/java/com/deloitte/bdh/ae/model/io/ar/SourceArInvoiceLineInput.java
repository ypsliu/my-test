package com.deloitte.bdh.ae.model.io.ar;

import com.deloitte.bdh.ae.model.SourceArInvoiceLine;

/**
 * @author Ashen
 * @date 20/04/2020
 */
public class SourceArInvoiceLineInput extends SourceArInvoiceLine {

}
