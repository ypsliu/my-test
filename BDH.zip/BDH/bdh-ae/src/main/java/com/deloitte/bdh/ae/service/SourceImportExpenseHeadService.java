package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.SourceImportExpenseHead;
import com.deloitte.bdh.common.base.Service;

/**
 * <p>
 * 员工费用报销申请头 服务类
 * </p>
 *
 * @author Ashen
 * @since 2021-03-24
 */
public interface SourceImportExpenseHeadService extends Service<SourceImportExpenseHead> {

}
