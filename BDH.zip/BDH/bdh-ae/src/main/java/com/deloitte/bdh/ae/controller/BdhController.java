package com.deloitte.bdh.ae.controller;

import com.deloitte.bdh.common.annotation.NoLog;
import com.deloitte.bdh.common.annotation.NoTenantCode;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author dahpeng
 * @date 2019/09/25
 */
@RestController
public class BdhController {

  @GetMapping("/hellobdh")
  @NoLog
  @NoTenantCode
  public String hellobdh() {
    return "hello bdh";
  }

}
