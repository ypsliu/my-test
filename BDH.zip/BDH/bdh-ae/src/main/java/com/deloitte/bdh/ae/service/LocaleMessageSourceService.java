package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.common.constant.EnvConstant;
import com.deloitte.bdh.common.constant.LanguageConstant;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import javax.annotation.Resource;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

/**
 * 语言国际化
 *
 * @author pengdh
 * @date 2018/10/11
 */
@Service
public class LocaleMessageSourceService {

  @Resource
  private Environment environment;

  /**
   * @param key  对应messages配置的key.
   * @param lang 语言标识
   * @return String
   */
  public String getMessage(String key, String lang) {
    try {
      String env = environment.getActiveProfiles()[0];
      if (StringUtils.equals(LanguageConstant.CN.getLanguage(), lang)) {
        if (StringUtils.equals(EnvConstant.ENV_HKTEST, env) || StringUtils
            .equals(EnvConstant.ENV_HKPROD, env)) {
          ResourceBundle bundle = ResourceBundle.getBundle("messages_zh_HK");
          return bundle.getString(key);
        } else {
          ResourceBundle bundle = ResourceBundle.getBundle("messages_zh_CN");
          return bundle.getString(key);
        }
      } else {
        ResourceBundle bundle = ResourceBundle.getBundle("messages_en_US");
        return bundle.getString(key);
      }
    } catch (MissingResourceException e) {
      return null;
    }
  }
}
