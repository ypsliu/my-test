package com.deloitte.bdh.ae.controller;

import com.deloitte.bdh.ae.task.BatchEbsTaskService;
import com.deloitte.bdh.ae.task.BatchTaskService;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.RetResponse;
import com.deloitte.bdh.common.base.RetResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Ashen
 * @date 20/02/2020
 */
@RestController
@RequestMapping("/aeBatchJob")
@Api(tags = "跑批数据接口")
public class AeBatchJobController {

  @Autowired
  private BatchEbsTaskService batchEbsTaskService;

  @Autowired
  private BatchTaskService batchTaskService;


  @PostMapping("/runAeBatchTask")
  @ApiOperation(value = "运行创建会计引擎批次数据任务")
  public RetResult<Void> runAeBatch(@RequestBody @Validated RetRequest<Void> request) {
    batchTaskService.runBatchTask();
    return RetResponse.makeOKRsp();
  }

  @PostMapping("/aeDataToEbsTask")
  @ApiOperation(value = "运行AE->EBS数据同步任务")
  public RetResult<Void> aeDataToEbsTask(@RequestBody @Validated RetRequest<Void> request) {
    batchEbsTaskService.runAeDataToEbsTask();
    return RetResponse.makeOKRsp();
  }


  @PostMapping("/ebsDataToAeTask")
  @ApiOperation(value = "运行EBS->AE数据同步任务")
  public RetResult<Void> ebsDataToAeTask(@RequestBody @Validated RetRequest<Void> request) {
    batchEbsTaskService.runEbsDataToAeTask();
    return RetResponse.makeOKRsp();
  }
}
