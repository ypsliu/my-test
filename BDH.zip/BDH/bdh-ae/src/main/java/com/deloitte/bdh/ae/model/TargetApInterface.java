package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "TargetApInterface对象", description = "")
public class TargetApInterface extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableField("ORG_NAME")
  private String orgName;

  @TableField("VENDOR_NUMBER")
  private String vendorNumber;

  @TableField("VENDOR_NAME")
  private String vendorName;

  @TableField("VENDOR_SITE_CODE")
  private String vendorSiteCode;

  @TableField("INVOICE_DATE")
  private LocalDate invoiceDate;

  @TableField("BATCH_NAME")
  private String batchName;

  @TableField("PAY_GROUP")
  private String payGroup;

  @TableField("INVOICE_NUM")
  private String invoiceNum;

  @TableField("INVOICE_TYPE")
  private String invoiceType;

  @TableField("INVOICE_DESCRIPTION")
  private String invoiceDescription;

  @TableField("INVOICE_CURRENCY")
  private String invoiceCurrency;

  @TableField("EXCHANGE_RATE_TYPE")
  private String exchangeRateType;

  @TableField("EXCHANGE_RATE")
  private BigDecimal exchangeRate;

  @TableField("EXCHANGE_DATE")
  private LocalDate exchangeDate;

  @TableField("INVOICE_AMOUNT")
  private BigDecimal invoiceAmount;

  @TableField("ACCOUNTING_DATE")
  private LocalDate accountingDate;

  @TableField("SEGMENT1")
  private String segment1;

  @TableField("SEGMENT2")
  private String segment2;

  @TableField("SEGMENT3")
  private String segment3;

  @TableField("SEGMENT4")
  private String segment4;

  @TableField("SEGMENT5")
  private String segment5;

  @TableField("SEGMENT6")
  private String segment6;

  @TableField("SEGMENT7")
  private String segment7;

  @TableField("SEGMENT8")
  private String segment8;

  @TableField("SEGMENT9")
  private String segment9;

  @TableField("SEGMENT10")
  private String segment10;

  @TableField("SEGMENT11")
  private String segment11;

  @TableField("SEGMENT12")
  private String segment12;

  @TableField("SEGMENT13")
  private String segment13;

  @TableField("SEGMENT14")
  private String segment14;

  @TableField("SEGMENT15")
  private String segment15;

  @TableField("SEGMENT16")
  private String segment16;

  @TableField("SEGMENT17")
  private String segment17;

  @TableField("SEGMENT18")
  private String segment18;

  @TableField("SEGMENT19")
  private String segment19;

  @TableField("SEGMENT20")
  private String segment20;

  @TableField("SEGMENT21")
  private String segment21;

  @TableField("SEGMENT22")
  private String segment22;

  @TableField("SEGMENT23")
  private String segment23;

  @TableField("SEGMENT24")
  private String segment24;

  @TableField("SEGMENT25")
  private String segment25;

  @TableField("SEGMENT26")
  private String segment26;

  @TableField("SEGMENT27")
  private String segment27;

  @TableField("SEGMENT28")
  private String segment28;

  @TableField("SEGMENT29")
  private String segment29;

  @TableField("SEGMENT30")
  private String segment30;

  @TableField("PAYMENT_TERM_NAME")
  private String paymentTermName;

  @TableField("PAYMENT_METHOD_NAME")
  private String paymentMethodName;

  @TableField("TERMS_DATE")
  private LocalDate termsDate;

  @TableField("PAYABLE_ACCOUNT")
  private String payableAccount;

  @TableField("ATTACH_NO")
  private BigDecimal attachNo;

  @TableField("EN_COMMENTS")
  private String enComments;

  @TableField("LINE_DESC")
  private String lineDesc;

  @TableField("LINE_AMOUNT")
  private BigDecimal lineAmount;

  @TableField("LINE_TAX_CODE")
  private String lineTaxCode;

  @TableField("LINE_GL_DATE")
  private LocalDate lineGlDate;

  @TableField("LINE_ACCOUNT")
  private String lineAccount;

  @TableField("PROJECT_NUMBER")
  private String projectNumber;

  @TableField("PROJECT_NAME")
  private String projectName;

  @TableField("TASK_NUMBER")
  private String taskNumber;

  @TableField("PO_NUMBER")
  private String poNumber;

  @TableField("RCV_NUMBER")
  private String rcvNumber;

  @TableField("PO_SHIPMENT_NUM")
  private String poShipmentNum;

  @TableField("ITEM_NUMBER")
  private BigDecimal itemNumber;

  @TableField("ITEM_DESC")
  private String itemDesc;

  @TableField("QUANTITY")
  private BigDecimal quantity;

  @TableField("PRICE")
  private BigDecimal price;

  @TableField("SET_OF_BOOKS_ID")
  private String setOfBooksId;

  @TableField("AE_HEAD_DESCRIPTION")
  private String aeHeadDescription;

  @TableField("AE_LINE_DESCRIPTION")
  private String aeLineDescription;

  @TableField("AE_SOURCE_SYSTEM")
  private String aeSourceSystem;

  @TableField("AE_STATUS")
  private String aeStatus;

  @TableField("AE_MERGE_FLAG")
  private String aeMergeFlag;

  @TableField("AE_SIDE_CODE")
  private String aeSideCode;

  @TableField("SOURCE_BATCH_ID")
  private String sourceBatchId;

  @TableField("SOURCE_HEAD_ID")
  private String sourceHeadId;

  @TableField("SOURCE_LINE_ID")
  private String sourceLineId;

  @TableField("AE_ROW_ID")
  private String aeRowId;

  @TableField("AE_MERGE_ROW_ID")
  private String aeMergeRowId;

  @TableField("AE_LINE_NUM")
  private BigDecimal aeLineNum;

  @TableField("AE_CREATE_TIME")
  private LocalDate aeCreateTime;

  @TableField("AE_BATCH_ID")
  private String aeBatchId;

  @TableField("AE_EBS_HEAD_ID")
  private String aeEbsHeadId;

  @TableField("AE_EBS_LINE_ORDER")
  private String aeEbsLineOrder;

  @TableField("AE_EBS_NUMBER")
  private String aeEbsNumber;

  @TableField("AE_REVERSE_STATUS")
  private String aeReverseStatus;

  @TableField("AE_JOURNAL_TYPE_ID")
  private String aeJournalTypeId;

  @TableField("AE_SEGMENT_DESCRIPTION_CH")
  private String aeSegmentDescriptionCh;

  @TableField("AE_SEGMENT_DESCRIPTION_EN")
  private String aeSegmentDescriptionEn;

  @TableField("BANK_ACCOUNT_NAME")
  private String bankAccountName;

  @TableField("LINE_TYPE")
  private String lineType;


}
