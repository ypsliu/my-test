package com.deloitte.bdh.ae.service;

/**
 * @author Ashen
 * @date 03/04/2020
 */
public interface AeTenantMethodService {

  /**
   * 验证租户是否有权限使用该应用产品
   *
   * @param tenantId
   * @param applicationCode         传入的应用产品代码
   * @param applicationCodeStandard 标准的对比代码
   */
  void verifyTenantApplication(String tenantId, String applicationCode,
      String applicationCodeStandard);

}
