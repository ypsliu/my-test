package com.deloitte.bdh.ae.client.model;

import com.deloitte.bdh.common.base.BaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.math.BigDecimal;
import lombok.Data;

@Data
public class FndPortalLanguage extends BaseModel {

  private String languageId;

  private String code;

  private String name;

  @JsonIgnore
  private String shortName;

  @JsonIgnore
  private String description;

  @JsonIgnore
  private Integer activeFlag;

  @JsonIgnore
  private BigDecimal priorityLevel;
}