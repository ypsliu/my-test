package com.deloitte.bdh.engine.config.entity;

import java.util.Map;
import lombok.Data;

/**
 * 一个批次数据运行时的配置信息
 *
 * @author Ashen
 * @date 28/11/2019
 */
@Data
public class Config {

  /**
   * 应用产品ID
   */
  private String applicationId;

  /**
   * 批次相关全局 信息
   */
  private Map<String, Object> batchDataMap;

  /**
   * 来源集合
   */
  private Map<String, Source> sourceMap;

  /**
   * 目标集合
   */
  private Map<String, Target> targetMap;

  /**
   * 会计事件列表
   */
  private Map<String, Event> eventMap;

  /**
   * 日记账行信息
   */
  private Map<String, Journal> journalMap;

  /**
   * 说明
   */
  private Map<String, JournalExplain> journalExplainMap;

  /**
   * 推导规则
   */
  private Map<String, JournalRule> journalRuleMap;

  /**
   * 行类型
   */
  private Map<String, JournalType> journalTypeMap;

  /**
   * 映射集
   */
  private Map<String, MapSet> mapSetMap;

}
