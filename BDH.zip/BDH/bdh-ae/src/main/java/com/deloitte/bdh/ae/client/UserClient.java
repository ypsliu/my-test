package com.deloitte.bdh.ae.client;

import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.RetResult;
import java.util.Map;
import java.util.Set;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @author Ashen
 * @date 17/12/2020
 */
@FeignClient(value = "bdh-platform", contextId = "user-client")
@Component
public interface UserClient {

  /**
   * 查询用户名映射集
   *
   * @param retRequest
   * @return
   */
  @PostMapping("/platform/fndPortalUser/queryUserNameMapByIdSet")
  RetResult<Map<String, String>> queryUserNameMapByIdSet(
      @RequestBody @Validated RetRequest<Set<String>> retRequest);
}
