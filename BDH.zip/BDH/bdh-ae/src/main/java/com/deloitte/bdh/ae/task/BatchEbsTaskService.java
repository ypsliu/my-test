package com.deloitte.bdh.ae.task;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.deloitte.bdh.ae.model.AeSourceBatch;
import com.deloitte.bdh.ae.service.AeDataToEbsService;
import com.deloitte.bdh.ae.service.AeSourceBatchService;
import com.deloitte.bdh.common.context.ThreadContextHolder;
import com.deloitte.bdh.common.distributedlock.DistributedLockHandler;
import com.deloitte.bdh.engine.runtime.ErrorMessageService;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Ashen
 * @date 10/03/2020
 */
@Service
public class BatchEbsTaskService {

  private static final Logger logger = LoggerFactory.getLogger(BatchEbsTaskService.class);

  private static final String AE_DATA_TO_EBS_KEY = "syncAeDataToEbsTask";
  private static final String AE_DATA_TO_EBS_VALUE = "syncAeDataToEbsTask";

  private static final String AE_DATA_FROM_EBS_KEY = "syncAeDataFromEbsTask";
  private static final String AE_DATA_FROM_EBS_VALUE = "syncAeDataFromEbsTask";


  @Autowired
  private DistributedLockHandler distributedLockHandler;

  @Autowired
  private AeSourceBatchService aeSourceBatchService;

  @Autowired
  private AeDataToEbsService aeDataToEbsService;

  @Autowired
  private ErrorMessageService errorMessageService;

  /**
   * 同步Ebs数据到Ae
   */
  public void runEbsDataToAeTask() {
    boolean lock = distributedLockHandler
        .tryLock(AE_DATA_FROM_EBS_KEY + ThreadContextHolder.getTenant().getTenantCode(),
            AE_DATA_FROM_EBS_VALUE + ThreadContextHolder.getTenant().getTenantCode());
    if (lock) {
      try {
        runEbsDataToAe();
      } catch (Exception e) {
        e.printStackTrace();
      } finally {
        // 使用完释放锁
        distributedLockHandler
            .releaseLock(AE_DATA_FROM_EBS_KEY + ThreadContextHolder.getTenant().getTenantCode());
      }
    }
  }

  /**
   * 同步Ae数据到Ebs
   */
  public void runAeDataToEbsTask() {
    boolean lock = distributedLockHandler
        .tryLock(AE_DATA_TO_EBS_KEY + ThreadContextHolder.getTenant().getTenantCode(),
            AE_DATA_TO_EBS_VALUE + ThreadContextHolder.getTenant().getTenantCode());
    if (lock) {
      try {
        runAeDataToEbs();
      } catch (Exception e) {
        e.printStackTrace();
      } finally {
        // 使用完释放锁
        distributedLockHandler
            .releaseLock(AE_DATA_TO_EBS_KEY + ThreadContextHolder.getTenant().getTenantCode());
      }
    }
  }

  private void runEbsDataToAe() {
    Integer successCount = 0;
    List<AeSourceBatch> aeSourceBatchList = aeSourceBatchService
        .list(new LambdaQueryWrapper<AeSourceBatch>()
            .eq(AeSourceBatch::getEbsStatus, "DOING_OK")
            .orderByAsc(AeSourceBatch::getEntryDate));
    for (int i = 0; i < aeSourceBatchList.size(); i++) {
      String aeBatchId = null;
      try {
        AeSourceBatch aeSourceBatch = aeSourceBatchList.get(i);
        aeBatchId = aeSourceBatch.getAeBatchId();
        if (aeSourceBatchService
            .updateBatchEbsStatus(aeBatchId, "FINAL_ACCOUNT", "DOING_OK", "DOING_DATA")) {
          aeDataToEbsService.getDataFromEbs(aeBatchId, aeSourceBatch.getApplicationCode());
          successCount++;
        }
        aeSourceBatchService
            .updateBatchEbsStatus(aeBatchId, "FINAL_ACCOUNT", "DOING_DATA", "OK");
      } catch (Exception e) {
        if (aeBatchId != null) {
          aeSourceBatchService
              .updateBatchEbsStatus(aeBatchId, "FINAL_ACCOUNT", "DOING_DATA", "FAIL");
        }
        e.printStackTrace();
      }
    }
    logger.info("自动跑批同步EBS科目数据,共有" + aeSourceBatchList.size() + "条数据，同步了" + successCount + "条数据！");
  }


  private void runAeDataToEbs() {
    //如果批次的入账类型为最终入账、且创建成功状态
    Integer successCount = 0;
    List<AeSourceBatch> aeSourceBatchList = aeSourceBatchService
        .list(new LambdaQueryWrapper<AeSourceBatch>()
            .eq(AeSourceBatch::getEntryType, "FINAL_ACCOUNT")
            .eq(AeSourceBatch::getAeStatus, "OK")
            .and(wrapper -> wrapper.eq(AeSourceBatch::getEbsStatus, "")
                .or()
                .isNull(AeSourceBatch::getEbsStatus)));
    for (int i = 0; i < aeSourceBatchList.size(); i++) {
      AeSourceBatch aeSourceBatch = aeSourceBatchList.get(i);
      //如果创建数据成功，并且EBS状态为空
      Boolean updateResult = aeSourceBatchService
          .updateBatchEbsStatus(aeSourceBatch.getAeBatchId(), "FINAL_ACCOUNT",
              aeSourceBatch.getEbsStatus(), "DOING");
      if (updateResult) {
        try {
          errorMessageService.deleteErrorByBatch(aeSourceBatch.getAeBatchId());
          aeDataToEbsService
              .putDataToEbs(aeSourceBatch.getAeBatchId(), aeSourceBatch.getApplicationCode());
          aeSourceBatchService
              .updateBatchEbsStatus(aeSourceBatch.getAeBatchId(), "FINAL_ACCOUNT", "DOING",
                  "DOING_OK");
          successCount++;
        } catch (Exception e) {
          e.printStackTrace();
          aeSourceBatchService
              .updateBatchEbsStatus(aeSourceBatch.getAeBatchId(), "FINAL_ACCOUNT", "DOING",
                  "FAIL");
          errorMessageService.insertErrorMessage(aeSourceBatch.getAeBatchId(), e.getMessage());
        }
      }
    }
    logger.info("自动跑批推送数据到EBS,共有" + aeSourceBatchList.size() + "条数据，同步了" + successCount + "条数据！");
  }
}
