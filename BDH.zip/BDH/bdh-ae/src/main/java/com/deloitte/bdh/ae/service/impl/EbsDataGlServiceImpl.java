package com.deloitte.bdh.ae.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.baomidou.dynamic.datasource.annotation.DS;
import com.deloitte.bdh.ae.model.CuxAeGlJeIface;
import com.deloitte.bdh.ae.model.io.ebs.EbsResponse;
import com.deloitte.bdh.ae.model.io.ebsgl.GlInput;
import com.deloitte.bdh.ae.model.io.ebsgl.IMPORT_ACCOUNTING;
import com.deloitte.bdh.ae.model.io.ebsgl.InputParameters;
import com.deloitte.bdh.ae.model.io.ebsgl.P_PROCESS_DATA_DEL;
import com.deloitte.bdh.ae.model.io.ebsgl.P_PROCESS_DATA_DEL_ITEM;
import com.deloitte.bdh.ae.service.AeSourceBatchService;
import com.deloitte.bdh.ae.service.CuxAeGlJeIfaceService;
import com.deloitte.bdh.ae.service.EbsDataGlService;
import com.deloitte.bdh.ae.service.TargetGlInterfaceService;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.common.exception.BizException;
import com.deloitte.bdh.common.http.HttpClientUtil;
import com.deloitte.bdh.engine.DataException;
import com.deloitte.bdh.engine.runtime.ErrorMessageService;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Ashen
 * @date 21/04/2020
 */
@Service
@RefreshScope
@DS(DSConstant.AE_DB)
@Transactional(rollbackFor = Exception.class)
public class EbsDataGlServiceImpl implements EbsDataGlService {

  @Resource
  private AeSourceBatchService aeSourceBatchService;

  @Autowired
  private CuxAeGlJeIfaceService cuxAeGlJeIfaceService;

  @Autowired
  private TargetGlInterfaceService targetGlInterfaceService;

  @Autowired
  private ErrorMessageService errorMessageService;

  @Value("${ebs.gl.host.url}")
  private String ebsGlHostUrl;

  @Value("${ebs.auth}")
  private String ebsAuth;

  @Override
  public void getDataFromEbsGl(String aeBatchId) {
    Integer totalCount = cuxAeGlJeIfaceService.countExistsData(aeBatchId);
    Integer successCount = cuxAeGlJeIfaceService.countSuccessData(aeBatchId);
    Integer errorCount = cuxAeGlJeIfaceService.countErrorData(aeBatchId);
    if (totalCount > 0 && totalCount.equals(successCount)) {
      // EBS 处理成功
      List<CuxAeGlJeIface> list = cuxAeGlJeIfaceService.selectResultByBatch(aeBatchId);
      list.forEach(cuxAeGlJeIface -> {
        //更新目标表数据
        targetGlInterfaceService.updateTarget(aeBatchId, cuxAeGlJeIface.getSourceHeadId(),
            cuxAeGlJeIface.getSourceLineId(), cuxAeGlJeIface.getAeRowId(),
            cuxAeGlJeIface.getImportJeHeaderId(), cuxAeGlJeIface.getImportJeLineNum(),
            cuxAeGlJeIface.getImportDocSequenceValue());
      });
    } else if (errorCount > 0) {
      // EBS 处理失败
      List<CuxAeGlJeIface> errorList = cuxAeGlJeIfaceService.selectErrorByBatch(aeBatchId);
      errorList.forEach(cuxAeGlJeIface -> {
        errorMessageService.insertErrorMessage(aeBatchId, cuxAeGlJeIface.getSourceBatchId(),
            cuxAeGlJeIface.getSourceHeadId(), cuxAeGlJeIface.getSourceLineId(),
            cuxAeGlJeIface.getImportErrorMessage());
      });
      throw new DataException("EBS处理数据失败");
    } else {
      // 待EBS处理
      aeSourceBatchService
          .updateBatchEbsStatus(aeBatchId, "FINAL_ACCOUNT", "DOING_DATA", "DOING_OK");
    }
  }

  @Override
  public void putDataToEbsGl(String aeBatchId) {
    try {
      List<P_PROCESS_DATA_DEL_ITEM> itemList = targetGlInterfaceService.queryGlItem(aeBatchId);
      if (CollectionUtil.isEmpty(itemList)) {
        throw new BizException("目标数据不能为空");
      }
      Map<String, Object> header = new HashMap<>();
      byte[] authBytes = new byte[0];
      authBytes = ebsAuth.getBytes("UTF-8");
      String baseAuth = Base64.encodeBase64String(authBytes);
      header.put("Authorization", "Basic " + baseAuth);
      GlInput glInput = new GlInput();
      IMPORT_ACCOUNTING importAccounting = new IMPORT_ACCOUNTING();
      InputParameters inputParameters = new InputParameters();
      glInput.setImportAccounting(importAccounting);
      importAccounting.setInputParameters(inputParameters);
      P_PROCESS_DATA_DEL p_process_data_del = new P_PROCESS_DATA_DEL();
      inputParameters.setP_PROCESS_BATCH_ID(aeBatchId);
      inputParameters.setPProcessDataDel(p_process_data_del);
      List<P_PROCESS_DATA_DEL_ITEM> p_process_data_del_itemList = new ArrayList<>();
      p_process_data_del.setP_process_data_del_itemList(p_process_data_del_itemList);
      itemList.forEach(p_process_data_del_item -> {
        p_process_data_del_itemList.add(p_process_data_del_item);
      });
      String payload = JSON.toJSONString(glInput, SerializerFeature.WriteMapNullValue);
      CloseableHttpResponse response = HttpClientUtil
          .httpPostRequestByJsonAndReturnResponse(ebsGlHostUrl, header, payload);
      if (null != response) {
        if (response.getStatusLine().getStatusCode() != 200) {
          throw new BizException("调用接口返回码异常");
        }
        HttpEntity entity = response.getEntity();
        if (entity != null) {
          String result = EntityUtils.toString(entity);
          response.close();
          EbsResponse ebsResponse = JSON.parseObject(result, EbsResponse.class);
          if (!"S".equals(ebsResponse.getOutputParameters().getX_RETURN_STATUS())) {
            throw new BizException(ebsResponse.getOutputParameters().getX_RETURN_MESSAGE());
          } else {
            return;
          }
        }
      }
    } catch (Exception e) {
      throw new BizException("调用EBS接口异常：" + e.getMessage());
    }
    throw new BizException("调用EBS接口异常");
  }

}
