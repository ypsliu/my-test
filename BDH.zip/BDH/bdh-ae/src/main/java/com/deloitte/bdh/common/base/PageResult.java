package com.deloitte.bdh.common.base;

import com.github.pagehelper.PageInfo;
import java.util.List;

/**
 * @author dahpeng
 * @date 2020/02/18
 */
public class PageResult<T> {

  long total;
  private boolean hasNextPage;
  List<T> list;

  public PageResult() {
  }

  public PageResult(PageInfo<T> pageInfo) {
    this.total = pageInfo.getTotal();
    this.hasNextPage = pageInfo.isHasNextPage();
    this.list = pageInfo.getList();
  }

  public long getTotal() {
    return total;
  }

  public void setTotal(long total) {
    this.total = total;
  }

  public List<T> getList() {
    return list;
  }

  public void setList(List<T> list) {
    this.list = list;
  }

  public boolean isHasNextPage() {
    return hasNextPage;
  }

  public void setHasNextPage(boolean hasNextPage) {
    this.hasNextPage = hasNextPage;
  }
}
