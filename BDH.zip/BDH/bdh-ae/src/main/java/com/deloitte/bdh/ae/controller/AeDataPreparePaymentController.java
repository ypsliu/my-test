package com.deloitte.bdh.ae.controller;

import com.deloitte.bdh.ae.model.io.DataOutput;
import com.deloitte.bdh.ae.model.io.OneDataInput;
import com.deloitte.bdh.ae.model.io.preparepayment.PreparePaymentDataInput;
import com.deloitte.bdh.ae.model.io.target.TargetDataOutput;
import com.deloitte.bdh.ae.service.SourcePreparePaymentLineService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author dahpeng
 * @Description: SourceArInvoiceHeadController类
 * @date 2020/04/23 15:49
 */
@RestController
@Api(tags = "数据同步:对公预支付数据")
@RequestMapping("/aeDataPreparePaymentController")
public class AeDataPreparePaymentController {

  @Autowired
  private SourcePreparePaymentLineService sourcePreparePaymentLineService;

  /**
   * @Description: 接口数据
   * @Reutrn
   */
  @PostMapping("putData")
  @ApiOperation(value = "对公预支付数据同步接口")
  public DataOutput putData(
      @RequestBody @Validated PreparePaymentDataInput preparePaymentDataInput) {
    try {
      DataOutput dataOutput = sourcePreparePaymentLineService.putData(preparePaymentDataInput);
      return dataOutput;
    } catch (Exception e) {
      e.printStackTrace();
      DataOutput dataOutput = new DataOutput();
      dataOutput.setStatus("FAIL");
      dataOutput.setMessage("同步数据失败：" + e.getMessage());
      return dataOutput;
    }
  }

  /**
   * @Description: 接口数据
   * @Reutrn
   */
  @PostMapping("revertData")
  @ApiOperation(value = "数据撤销接口")
  public DataOutput revertData(
      @RequestBody OneDataInput oneDataInput) {
    try {
      DataOutput dataOutput = sourcePreparePaymentLineService.revertData(oneDataInput);
      return dataOutput;
    } catch (Exception e) {
      e.printStackTrace();
      DataOutput dataOutput = new DataOutput();
      dataOutput.setStatus("FAIL");
      dataOutput.setMessage("撤销数据失败：" + e.getMessage());
      return dataOutput;
    }
  }

  /**
   * @Description: 接口数据
   * @Reutrn
   */
  @PostMapping("getTargetDate")
  @ApiOperation(value = "获取最终的科目信息")
  public TargetDataOutput getTargetDate(
      @RequestBody OneDataInput oneDataInput) {
    try {
      TargetDataOutput targetDataOutput = sourcePreparePaymentLineService
          .getTargetDate(oneDataInput);
      return targetDataOutput;
    } catch (Exception e) {
      e.printStackTrace();
      TargetDataOutput targetDataOutput = new TargetDataOutput();
      targetDataOutput.setStatus("FAIL");
      targetDataOutput.setMessage("获取目标数据失败：" + e.getMessage());
      return targetDataOutput;
    }
  }
}