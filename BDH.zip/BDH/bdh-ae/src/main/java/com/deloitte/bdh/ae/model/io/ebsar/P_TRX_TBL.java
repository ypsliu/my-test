package com.deloitte.bdh.ae.model.io.ebsar;

import com.alibaba.fastjson.annotation.JSONField;
import java.util.List;
import lombok.Data;

/**
 * @author Ashen
 * @date 21/04/2020
 */
@Data
public class P_TRX_TBL {

  @JSONField(name = "P_TRX_TBL_ITEM")
  private List<P_TRX_TBL_ITEM> P_TRX_TBL_ITEM;

}
