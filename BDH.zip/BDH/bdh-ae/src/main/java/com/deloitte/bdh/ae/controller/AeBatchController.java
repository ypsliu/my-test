package com.deloitte.bdh.ae.controller;

import com.deloitte.bdh.ae.model.AeSourceBatch;
import com.deloitte.bdh.ae.model.dto.ApplicationDto;
import com.deloitte.bdh.ae.model.dto.BatchDto;
import com.deloitte.bdh.ae.model.dto.BatchListGenerateDto;
import com.deloitte.bdh.ae.model.dto.BatchQueryDto;
import com.deloitte.bdh.ae.model.vo.UserVo;
import com.deloitte.bdh.ae.service.AeSourceBatchService;
import com.deloitte.bdh.common.base.PageRequest;
import com.deloitte.bdh.common.base.PageResult;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.RetResponse;
import com.deloitte.bdh.common.base.RetResult;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author dahpeng
 * @Description: AeSourceBatchController类
 * @date 2019/11/26 14:15
 */
@RestController
@RequestMapping("/aeBatch")
@Api(tags = "批次相关接口")
public class AeBatchController {

  @Autowired
  private AeSourceBatchService aeSourceBatchService;

  /**
   * @Description: 分页查询
   * @Reutrn RetResult<PageInfo < AeSourceBatch>>
   */
  @PostMapping("queryPage")
  @ApiOperation(value = "查询批次信息：分页查询批次")
  public RetResult<PageResult<AeSourceBatch>> queryPage(
      @RequestBody @Validated PageRequest<BatchQueryDto> pageRequest) {
    List<AeSourceBatch> list = aeSourceBatchService.selectByPageRequest(pageRequest);
    PageInfo<AeSourceBatch> pageInfo = new PageInfo<AeSourceBatch>(list);
    PageResult pageResult = new PageResult(pageInfo);
    return RetResponse.makeOKRsp(pageResult);
  }

  /**
   * @Description: 入账人列表
   * @Reutrn RetResult<PageInfo < ApplicationDto>>
   */
  @PostMapping("entryUserList")
  @ApiOperation(value = "查询批次信息：入账人列表")
  public RetResult<List<UserVo>> entryUserList(
      @RequestBody @Validated RetRequest<ApplicationDto> retRequest) {
    List<UserVo> userNameList = aeSourceBatchService.selectEntryUserList(retRequest);
    return RetResponse.makeOKRsp(userNameList);
  }

  @PostMapping("/generateData")
  @ApiOperation(value = "创建会计科目信息")
  public RetResult<Object> generateData(
      @RequestBody @Validated RetRequest<BatchListGenerateDto> batchDtoRetRequest) {
    aeSourceBatchService.generateData(batchDtoRetRequest);
    return RetResponse.makeOKRsp();
  }


  @PostMapping("/deleteData")
  @ApiOperation(value = "删除批次数据")
  public RetResult<Object> deleteData(
      @RequestBody @Validated RetRequest<BatchDto> retRequest) {
    aeSourceBatchService.deleteData(retRequest.getData());
    return RetResponse.makeOKRsp();
  }

}