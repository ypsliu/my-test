package com.deloitte.bdh.ae.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import javax.validation.constraints.NotEmpty;
import lombok.Data;

/**
 * @author Ashen
 * @date 19/02/2020
 */
@Data
@ApiModel(description = "批次列表导出类")
public class BatchListExportDto {

  @ApiModelProperty(value = "批次列表")
  @NotEmpty(message = "批次列表不能为空")
  private List<String> batchIdList;

  @ApiModelProperty(value = "数据类型：DETAIL:明细、FINAL:汇总")
  @NotEmpty(message = "数据类型不能为空")
  private String type;
}
