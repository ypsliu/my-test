package com.deloitte.bdh.ae.model.io.ebsap;

import com.alibaba.fastjson.annotation.JSONField;
import java.util.List;
import lombok.Data;

/**
 * @author Ashen
 * @date 21/04/2020
 */
@Data
public class P_INVOICES_TBL {

  @JSONField(name = "P_INVOICES_TBL_ITEM")
  private List<P_INVOICES_TBL_ITEM> P_INVOICES_TBL_ITEM;

}
