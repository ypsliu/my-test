package com.deloitte.bdh.ae.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.baomidou.dynamic.datasource.annotation.DS;
import com.deloitte.bdh.ae.model.TargetSourceBasicInfo;
import com.deloitte.bdh.ae.model.io.ebsap.EbsApResponseErrorDetail;
import com.deloitte.bdh.ae.model.io.ebsapwriteoff.APPLY_PREPAY_Input;
import com.deloitte.bdh.ae.model.io.ebsapwriteoff.EbsApWriteOffInput;
import com.deloitte.bdh.ae.model.io.ebsapwriteoff.EbsApWriteOffOutput;
import com.deloitte.bdh.ae.model.io.ebsapwriteoff.InputParameters;
import com.deloitte.bdh.ae.model.io.ebsapwriteoff.P_APPLY_PREPAY_TBL;
import com.deloitte.bdh.ae.model.io.ebsapwriteoff.P_APPLY_PREPAY_TBL_ITEM;
import com.deloitte.bdh.ae.service.AeSourceBatchService;
import com.deloitte.bdh.ae.service.EbsDataApWriteOffService;
import com.deloitte.bdh.ae.service.TargetApWriteoffInterfaceService;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.common.exception.BizException;
import com.deloitte.bdh.common.http.HttpClientUtil;
import com.deloitte.bdh.engine.runtime.ErrorMessageService;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.annotation.Resource;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Ashen
 * @date 14/07/2020
 */
@Service
@DS(DSConstant.AE_DB)
@Transactional(rollbackFor = Exception.class)
public class EbsDataApWriteOffServiceImpl implements EbsDataApWriteOffService {

  @Resource
  private AeSourceBatchService aeSourceBatchService;

  @Autowired
  private TargetApWriteoffInterfaceService targetApWriteoffInterfaceService;

  @Autowired
  private ErrorMessageService errorMessageService;

  @Value("${ebs.ap.writeoff.host.url}")
  private String ebsApWriteOffHostUrl;

  @Value("${ebs.auth}")
  private String ebsAuth;

  @Override
  public void putDataToEbsApWriteOff(String aeBatchId) {
    try {
      List<P_APPLY_PREPAY_TBL_ITEM> itemList = targetApWriteoffInterfaceService
          .queryInvoicesItem(aeBatchId);
      if (itemList.isEmpty()) {
        throw new BizException("核销信息不能为空！");
      }
      EbsApWriteOffInput ebsApWriteOffInput = new EbsApWriteOffInput();
      APPLY_PREPAY_Input apply_prepay_input = new APPLY_PREPAY_Input();
      ebsApWriteOffInput.setAPPLY_PREPAY_Input(apply_prepay_input);
      InputParameters inputParameters = new InputParameters();
      apply_prepay_input.setInputParameters(inputParameters);
      P_APPLY_PREPAY_TBL p_APPLYPREPAY_tbl = new P_APPLY_PREPAY_TBL();
      inputParameters.setP_APPLY_PREPAY_TBL(p_APPLYPREPAY_tbl);
      p_APPLYPREPAY_tbl.setP_APPLY_PREPAY_TBL_ITEM(itemList);

      Map<String, Object> header = new HashMap<>();
      byte[] authBytes = new byte[0];
      authBytes = ebsAuth.getBytes("UTF-8");
      String baseAuth = Base64.encodeBase64String(authBytes);
      header.put("Authorization", "Basic " + baseAuth);
      String payload = JSON.toJSONString(ebsApWriteOffInput, SerializerFeature.WriteMapNullValue);
      CloseableHttpResponse response = HttpClientUtil
          .httpPostRequestByJsonAndReturnResponse(ebsApWriteOffHostUrl, header, payload);
      if (null != response) {
        if (response.getStatusLine().getStatusCode() != 200) {
          throw new BizException("返回错误的接口状态");
        }
        HttpEntity entity = response.getEntity();
        if (entity != null) {
          String result = EntityUtils.toString(entity);
          response.close();
          EbsApWriteOffOutput ebsApWriteOffOutput = JSON
              .parseObject(result, EbsApWriteOffOutput.class);
          if ("S".equals(ebsApWriteOffOutput.getOutputParameters().getX_RETURN_STATUS())) {
            aeSourceBatchService
                .updateBatchEbsStatus(aeBatchId, "FINAL_ACCOUNT", "DOING",
                    "OK");
            return;
          } else {
            String data = ebsApWriteOffOutput.getOutputParameters().getX_MSG_DATA();
            //不能解析为数据，则为错误信息
            try {
              //如果能解析为数组
              List<EbsApResponseErrorDetail> errorDetailListlist = JSON
                  .parseArray(data, EbsApResponseErrorDetail.class);
              Set<String> lineNumberSet = new HashSet<>();
              errorDetailListlist.forEach(ebsApResponseErrorDetail -> {
                lineNumberSet.add(ebsApResponseErrorDetail.getLine_number());
              });
              List<TargetSourceBasicInfo> sourceBasicInfoList = targetApWriteoffInterfaceService
                  .selectByLineNumberSet(lineNumberSet, aeBatchId);
              Map<String, TargetSourceBasicInfo> sourceBasicInfoMap = sourceBasicInfoList.stream()
                  .collect(
                      Collectors.toMap(TargetSourceBasicInfo::getAeRowId, Function.identity()));
              errorDetailListlist.forEach(ebsApResponseErrorDetail -> {
                TargetSourceBasicInfo targetSourceBasicInfo = sourceBasicInfoMap
                    .get(ebsApResponseErrorDetail.getLine_number());
                if (targetSourceBasicInfo == null) {
                  errorMessageService
                      .insertErrorMessage(aeBatchId, ebsApResponseErrorDetail.getErr_msg());
                } else {
                  errorMessageService
                      .insertErrorMessage(aeBatchId, targetSourceBasicInfo.getSourceBatchId(),
                          targetSourceBasicInfo.getSourceHeadId(),
                          targetSourceBasicInfo.getSourceLineId(),
                          ebsApResponseErrorDetail.getErr_msg());
                }
              });
            } catch (Exception e) {
              //不能解析为数据，则为错误信息
              throw new BizException(data);
            }
          }
        }
      }
    } catch (Exception e) {
      throw new BizException("调用EBS接口异常：" + e.getMessage());
    }
    throw new BizException("调用EBS接口异常");
  }
}
