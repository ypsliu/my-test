package com.deloitte.bdh.ae.model.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.math.BigDecimal;
import lombok.Data;

/**
 * @author Ashen
 * @date 20/02/2020
 */
@Data
@ApiModel(description = "列名字段显示信息")
public class HeadProperty {

  @ApiModelProperty(value = "字段")
  private String property;

  @ApiModelProperty(value = "名称")
  private String name;

  @ApiModelProperty(value = "宽度")
  private BigDecimal width;

  @ApiModelProperty(value = "数据类型")
  private String dataType;

  public HeadProperty(String property, String name) {
    this.property = property;
    this.name = name;
  }

  public HeadProperty(String property, String name, BigDecimal width) {
    this.property = property;
    this.name = name;
    this.width = width;
  }

  public HeadProperty(String property, String name, BigDecimal width, String dataType) {
    this.property = property;
    this.name = name;
    this.width = width;
    this.dataType = dataType;
  }

}
