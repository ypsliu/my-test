package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.SourceImportPaymentHead;
import com.deloitte.bdh.common.base.Service;

/**
 * <p>
 * 借款付款行信息 服务类
 * </p>
 *
 * @author Ashen
 * @since 2021-03-24
 */
public interface SourceImportPaymentHeadService extends Service<SourceImportPaymentHead> {

}
