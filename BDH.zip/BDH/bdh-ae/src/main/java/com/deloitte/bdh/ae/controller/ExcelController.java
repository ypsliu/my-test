package com.deloitte.bdh.ae.controller;

import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.RetResponse;
import com.deloitte.bdh.common.base.RetResult;
import com.deloitte.bdh.excel.model.ExcelTempData;
import com.deloitte.bdh.excel.model.dto.ExcelDto;
import com.deloitte.bdh.excel.service.ExcelService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author Ashen
 * @date 26/11/2020
 */
@Api(tags = "Excel导入功能开发")
@RestController
@RequestMapping("/excel")
public class ExcelController {

  @Autowired
  private ExcelService excelService;

  @ApiOperation(value = "文件导入:模板下载")
  @PostMapping(value = "/downloadUploadTemplate")
  public void downloadUploadTemplate(@RequestBody @Validated RetRequest<ExcelDto> retRequest,
      HttpServletResponse response) {
    excelService.downloadUploadTemplate(retRequest.getData().getModel(), response);
  }


  @ApiOperation(value = "文件导入:上传文件并检查")
  @PostMapping("/checkUploadFile")
  public RetResult<ExcelTempData> checkUploadFile(
      @ApiParam(value = "业务对象", required = true) @RequestParam(required = true) String model,
      @RequestParam(required = true) String lang, @RequestParam(required = true) String operator,
      String source, String sid, String version, @RequestParam MultipartFile multipartFile) {
    ExcelTempData excelTempData = excelService.checkUploadFile(model, multipartFile);
    excelService.addSystemTitle(excelTempData);
    excelTempData.setModel(model);
    return RetResponse.makeOKRsp(excelTempData);
  }

  @ApiOperation(value = "文件导入:对数据进行检查")
  @PostMapping("/checkUploadData")
  public RetResult<ExcelTempData> checkUploadData(
      @RequestBody @Validated RetRequest<ExcelTempData> retRequest) {
    ExcelTempData excelTempData = retRequest.getData();
    Boolean checkResult = excelService
        .checkUploadData(retRequest.getData().getModel(), retRequest.getData());
    excelService.addSystemTitle(excelTempData);
    if (!checkResult) {
      return RetResponse.makeFailRsp(excelTempData);
    }
    return RetResponse.makeOKRsp(excelTempData);
  }

  @ApiOperation(value = "文件导入:保存数据")
  @PostMapping("/saveUploadData")
  public RetResult<ExcelTempData> uploadData(
      @RequestBody @Validated RetRequest<ExcelTempData> retRequest) {
    Boolean saveFlag = excelService
        .saveUploadData(retRequest.getData().getModel(), retRequest.getData());
    ExcelTempData excelTempData = retRequest.getData();
    excelService.addSystemTitle(excelTempData);
    if (!saveFlag) {
      return RetResponse.makeFailRsp(excelTempData);
    }
    return RetResponse.makeOKRsp();
  }
}
