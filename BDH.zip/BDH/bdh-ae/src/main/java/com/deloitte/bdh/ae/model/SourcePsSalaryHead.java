package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@Accessors(chain = true)
@ApiModel(value = "SourcePsSalaryHead对象", description = "")
public class SourcePsSalaryHead {

  private static final long serialVersionUID = 1L;

  @TableField("AE_ROW_ID")
  private String aeRowId;

  @TableField("AE_STATUS")
  private String aeStatus;

  @TableField("SOURCE_BATCH_ID")
  private String sourceBatchId;

  @TableField("SOURCE_HEAD_ID")
  private String sourceHeadId;

  @TableField("CAL_PRD_ID")
  private String calPrdId;

  @TableField("COMPANY")
  private String company;

  @TableField("C_COST_CENTER")
  private String cCostCenter;

  @TableField("COMPANY_DESCR")
  private String companyDescr;

  @TableField("C_COST_CENTER_DESC")
  private String cCostCenterDesc;

  @TableField("ORGANIZATION_ID")
  private String organizationId;


}
