package com.deloitte.bdh.ae.model.io.ebsap;

import com.alibaba.fastjson.annotation.JSONField;
import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

/**
 * @author Ashen
 * @date 21/04/2020
 */
@Data
public class P_INVOICES_TBL_ITEM {

  @JSONField(name = "ORG_NAME", ordinal = 1)
  private String ORG_NAME;

  @JSONField(name = "VENDOR_NUMBER", ordinal = 2)
  private String VENDOR_NUMBER;

  @JSONField(name = "VENDOR_NAME", ordinal = 3)
  private String VENDOR_NAME;

  @JSONField(name = "VENDOR_SITE_CODE", ordinal = 4)
  private String VENDOR_SITE_CODE;

  @JSONField(name = "INVOICE_DATE", format = "yyyy-MM-dd", ordinal = 5)
  private Date INVOICE_DATE;

  @JSONField(name = "BATCH_NAME", ordinal = 6)
  private String BATCH_NAME;

  @JSONField(name = "PAY_GROUP", ordinal = 7)
  private String PAY_GROUP;

  @JSONField(name = "INVOICE_NUM", ordinal = 8)
  private String INVOICE_NUM;

  @JSONField(name = "INVOICE_TYPE", ordinal = 9)
  private String INVOICE_TYPE;

  @JSONField(name = "BANK_ACCOUNT_NAME", ordinal = 10)
  private String BANK_ACCOUNT_NAME;

  @JSONField(name = "INVOICE_DESCRIPTION", ordinal = 20)
  private String INVOICE_DESCRIPTION;

  @JSONField(name = "INVOICE_CURRENCY", ordinal = 21)
  private String INVOICE_CURRENCY;

  @JSONField(name = "EXCHANGE_RATE_TYPE", ordinal = 22)
  private String EXCHANGE_RATE_TYPE;

  @JSONField(name = "EXCHANGE_RATE", ordinal = 23)
  private BigDecimal EXCHANGE_RATE;

  @JSONField(name = "EXCHANGE_DATE", format = "yyyy-MM-dd", ordinal = 24)
  private Date EXCHANGE_DATE;

  @JSONField(name = "INVOICE_AMOUNT", ordinal = 25)
  private BigDecimal INVOICE_AMOUNT;

  @JSONField(name = "GL_DATE", format = "yyyy-MM-dd", ordinal = 26)
  private Date GL_DATE;

  @JSONField(name = "PAYMENT_TERM_NAME", ordinal = 27)
  private String PAYMENT_TERM_NAME;

  @JSONField(name = "PAYMENT_METHOD_NAME", ordinal = 28)
  private String PAYMENT_METHOD_NAME;

  @JSONField(name = "TERMS_DATE", format = "yyyy-MM-dd", ordinal = 29)
  private Date TERMS_DATE;

  @JSONField(name = "PAYABLE_ACCOUNT", ordinal = 30)
  private BigDecimal PAYABLE_ACCOUNT;

  @JSONField(name = "ATTACH_NO", ordinal = 31)
  private BigDecimal ATTACH_NO;

  @JSONField(name = "EN_COMMENTS", ordinal = 32)
  private String EN_COMMENTS;

  @JSONField(name = "LINE_NUMBER", ordinal = 33)
  private String LINE_NUMBER;

  @JSONField(name = "LINE_DESC", ordinal = 34)
  private String LINE_DESC;

  @JSONField(name = "LINE_AMOUNT", ordinal = 35)
  private BigDecimal LINE_AMOUNT;

  @JSONField(name = "LINE_TAX_CODE", ordinal = 36)
  private String LINE_TAX_CODE;

  @JSONField(name = "LINE_GL_DATE", format = "yyyy-MM-dd", ordinal = 37)
  private Date LINE_GL_DATE;

  @JSONField(name = "LINE_ACCOUNT", ordinal = 38)
  private String LINE_ACCOUNT;

  @JSONField(name = "PROJECT_NUMBER", ordinal = 39)
  private String PROJECT_NUMBER;

  @JSONField(name = "PROJECT_NAME", ordinal = 40)
  private String PROJECT_NAME;

  @JSONField(name = "TASK_NUMBER", ordinal = 41)
  private String TASK_NUMBER;

  @JSONField(name = "PO_NUMBER", ordinal = 42)
  private String PO_NUMBER;

  @JSONField(name = "RCV_NUMBER", ordinal = 43)
  private String RCV_NUMBER;

  @JSONField(name = "PO_SHIPMENT_NUM", ordinal = 44)
  private String PO_SHIPMENT_NUM;

  @JSONField(name = "ITEM_NUMBER", ordinal = 45)
  private String ITEM_NUMBER;

  @JSONField(name = "ITEM_DESC", ordinal = 46)
  private String ITEM_DESC;

  @JSONField(name = "QUANTITY", ordinal = 47)
  private BigDecimal QUANTITY;

  @JSONField(name = "PRICE", ordinal = 48)
  private BigDecimal PRICE;

  @JSONField(name = "LINE_TYPE", ordinal = 49)
  private String LINE_TYPE;
}
