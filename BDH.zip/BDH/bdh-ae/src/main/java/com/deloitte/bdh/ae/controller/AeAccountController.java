package com.deloitte.bdh.ae.controller;

import com.deloitte.bdh.ae.model.dto.BatchDocumentDto;
import com.deloitte.bdh.ae.model.dto.BatchDto;
import com.deloitte.bdh.ae.model.dto.BatchListExportDto;
import com.deloitte.bdh.ae.model.vo.HeadProperty;
import com.deloitte.bdh.ae.model.vo.TargetAccountVo;
import com.deloitte.bdh.ae.service.AeTargetService;
import com.deloitte.bdh.common.base.PageHeadResult;
import com.deloitte.bdh.common.base.PageRequest;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.RetResponse;
import com.deloitte.bdh.common.base.RetResult;
import com.deloitte.bdh.common.util.DateUtils;
import com.deloitte.bdh.common.util.ExcelData;
import com.deloitte.bdh.common.util.ExcelUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Ashen
 * @date 20/02/2020
 */
@RestController
@RequestMapping("/aeAccounting")
@Api(tags = "账务信息")
public class AeAccountController {

  @Autowired
  private AeTargetService aeTargetService;

  @PostMapping("queryByBatch")
  @ApiOperation(value = "批次查询账务信息")
  public RetResult<Object> queryByBatch(
      @RequestBody @Validated PageRequest<BatchDto> pageRequest) {
    PageHeadResult<TargetAccountVo> pageHeadResult = aeTargetService
        .queryAccountingByBatch(pageRequest);
    return RetResponse.makeOKRsp(pageHeadResult);
  }

  @PostMapping("queryByDocument")
  @ApiOperation(value = "单据查询账务信息")
  public RetResult<Object> queryByDocument(
      @RequestBody @Validated PageRequest<BatchDocumentDto> pageRequest) {
    PageHeadResult<TargetAccountVo> pageHeadResult = aeTargetService
        .queryAccountingByDocument(pageRequest);
    return RetResponse.makeOKRsp(pageHeadResult);
  }

  @PostMapping("/exportData")
  @ApiOperation(value = "导出账务信息")
  public void exportData(
      @RequestBody @Validated RetRequest<BatchListExportDto> retRequest,
      HttpServletResponse response) throws Exception {
    BatchListExportDto batchListExportDto = retRequest.getData();
    PageHeadResult<TargetAccountVo> pageHeadResult = aeTargetService.exportData(batchListExportDto);
    ExcelData excelData = new ExcelData();
    List<String> titles = pageHeadResult.getHeadList().stream().map(HeadProperty::getName).collect(
        Collectors.toList());
    excelData.setTitles(titles);
    List<List<Object>> rows = new ArrayList();
    pageHeadResult.getList().stream().forEach(targetAccountVo -> {
      List<Object> row = convertData(targetAccountVo, pageHeadResult.getHeadList());
      rows.add(row);
    });
    excelData.setRows(rows);
    ExcelUtil.exportExcel(response, "文件名", excelData);
  }

  private List<Object> convertData(TargetAccountVo targetAccountVo, List<HeadProperty> headList) {
    List<Object> dataList = new ArrayList<>();
    headList.forEach(headProperty -> {
      Object value = getValue(targetAccountVo, headProperty.getProperty());
      if (value != null && value instanceof Date) {
        value = DateUtils.formatShortSlashDateTime((Date) value);
      }
      dataList.add(value);
    });
    return dataList;
  }

  private Object getValue(TargetAccountVo targetAccountVo, String property) {
    try {
      Field field = targetAccountVo.getClass().getDeclaredField(property);
      if (Modifier.isStatic(field.getModifiers())) {
        return null;
      }
      PropertyDescriptor descriptor = new PropertyDescriptor(field.getName(),
          targetAccountVo.getClass());
      Method readMethod = descriptor.getReadMethod();
      Object fieldValue = readMethod.invoke(targetAccountVo);
      return fieldValue;
    } catch (Exception e) {
      return null;
    }
  }
}
