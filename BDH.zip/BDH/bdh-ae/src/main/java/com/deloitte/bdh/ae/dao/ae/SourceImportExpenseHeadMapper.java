package com.deloitte.bdh.ae.dao.ae;

import com.deloitte.bdh.ae.model.SourceImportExpenseHead;
import com.deloitte.bdh.common.base.Mapper;

/**
 * <p>
 * 员工费用报销申请头 Mapper 接口
 * </p>
 *
 * @author Ashen
 * @since 2021-03-24
 */
public interface SourceImportExpenseHeadMapper extends Mapper<SourceImportExpenseHead> {

}
