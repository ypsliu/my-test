package com.deloitte.bdh.engine.config;

import com.deloitte.bdh.engine.config.entity.Config;

/**
 * 读取配置信息
 *
 * @author Ashen
 * @date 04/12/2019
 */
public interface ConfigReader {

  /**
   * 读取事件信息
   */
  void readEvent(Config config);

  /**
   * 读取日记账行信息
   */
  void readJournal(Config config);

  /**
   * 读取日记账说明信息
   */
  void readJournalExplain(Config config);

  /**
   * 读取推导规则
   */
  void readJournalRule(Config config);

  /**
   * 读取日记账行类型
   */
  void readJournalType(Config config);

  /**
   * 读取映射集
   */
  void readMapSet(Config config);

  /**
   * 读取目标
   */
  void readTarget(Config config);

  /**
   * 读取来源
   */
  void readSource(Config config);
}
