package com.deloitte.bdh.ae.model.io.ebsar;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

/**
 * @author Ashen
 * @date 21/04/2020
 */
@Data
public class ArInvoicesInput {

  @JSONField(name = "CREATE_TRXS_Input")
  private CREATE_TRXS_Input CREATE_TRXS_Input;

}
