package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.deloitte.bdh.ae.dao.ae.AeApplicationMapper;
import com.deloitte.bdh.ae.model.AeApplication;
import com.deloitte.bdh.ae.service.AeApplicationService;
import com.deloitte.bdh.common.base.ServiceTransactionalImpl;
import com.deloitte.bdh.common.constant.DSConstant;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Service
@DS(DSConstant.AE_DB)
public class AeApplicationServiceImpl extends
    ServiceTransactionalImpl<AeApplicationMapper, AeApplication> implements AeApplicationService {

  @Override
  public List<AeApplication> selectByTenantId(String tenantId) {
    return baseMapper.selectByTenantId(tenantId);
  }

  @Override
  public Integer selectTenantAndApplicationCode(String tenantId, String applicationCode) {
    return baseMapper.selectTenantAndApplicationCode(tenantId, applicationCode);
  }
}
