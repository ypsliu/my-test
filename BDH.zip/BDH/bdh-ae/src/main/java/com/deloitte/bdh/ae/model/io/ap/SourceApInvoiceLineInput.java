package com.deloitte.bdh.ae.model.io.ap;

import com.deloitte.bdh.ae.model.SourceApInvoiceLine;

/**
 * @author Ashen
 * @date 20/04/2020
 */
public class SourceApInvoiceLineInput extends SourceApInvoiceLine {

}
