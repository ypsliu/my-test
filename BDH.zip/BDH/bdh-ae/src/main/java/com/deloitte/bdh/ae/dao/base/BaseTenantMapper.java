package com.deloitte.bdh.ae.dao.base;

import com.deloitte.bdh.ae.model.BaseTenant;
import com.deloitte.bdh.common.base.Mapper;

/**
 * <p>
 * 租户表 Mapper 接口
 * </p>
 *
 * @author Ashen
 * @since 2020-09-09
 */
public interface BaseTenantMapper extends Mapper<BaseTenant> {

}
