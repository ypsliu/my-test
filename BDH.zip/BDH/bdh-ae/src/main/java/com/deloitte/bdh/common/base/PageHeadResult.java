package com.deloitte.bdh.common.base;

import com.deloitte.bdh.ae.model.vo.HeadProperty;
import com.github.pagehelper.PageInfo;
import java.util.List;

/**
 * @author Ashen
 * @date 07/05/2018
 */
public class PageHeadResult<T> {

  long total;
  List<HeadProperty> headList;
  List<T> list;

  public PageHeadResult() {
  }

  public PageHeadResult(PageInfo<T> pageInfo, List<HeadProperty> headPropertyList) {
    this.total = pageInfo.getTotal();
    this.list = pageInfo.getList();
    this.headList = headPropertyList;
  }

  public long getTotal() {
    return total;
  }

  public void setTotal(long total) {
    this.total = total;
  }

  public List<T> getList() {
    return list;
  }

  public void setList(List<T> list) {
    this.list = list;
  }

  public List<HeadProperty> getHeadList() {
    return headList;
  }

  public void setHeadList(List<HeadProperty> headList) {
    this.headList = headList;
  }
}
