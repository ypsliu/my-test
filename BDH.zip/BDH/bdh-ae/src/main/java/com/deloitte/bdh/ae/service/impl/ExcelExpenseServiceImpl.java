package com.deloitte.bdh.ae.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.deloitte.bdh.ae.client.FeignClientService;
import com.deloitte.bdh.ae.client.vo.OrganizationClientVo;
import com.deloitte.bdh.ae.model.AeSourceBatch;
import com.deloitte.bdh.ae.model.SourceImportExpenseHead;
import com.deloitte.bdh.ae.model.SourceImportExpenseLine;
import com.deloitte.bdh.ae.model.bo.ExcelModelExpense;
import com.deloitte.bdh.ae.model.vo.CompanyDataPermissionVo;
import com.deloitte.bdh.ae.properties.ApplicationCodeProperties;
import com.deloitte.bdh.ae.service.AeSourceBatchService;
import com.deloitte.bdh.ae.service.SourceImportExpenseHeadService;
import com.deloitte.bdh.ae.service.SourceImportExpenseLineService;
import com.deloitte.bdh.common.context.ThreadContextHolder;
import com.deloitte.bdh.common.exception.BizException;
import com.deloitte.bdh.common.util.StringUtil;
import com.deloitte.bdh.excel.context.ExcelModelServiceContext;
import com.deloitte.bdh.excel.model.ExcelData;
import com.deloitte.bdh.excel.service.AbstractExcelModelService;
import com.deloitte.bdh.excel.service.ExcelModelService;
import com.deloitte.bdh.excel.service.ExcelService;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

/**
 * @author Ashen
 * @date 26/11/2020
 */
@Component
public class ExcelExpenseServiceImpl {

  @Autowired
  private ExcelService excelService;

  @Autowired
  private FeignClientService feignClientService;

  @Autowired
  private AeSourceBatchService aeSourceBatchService;

  @Autowired
  private ApplicationCodeProperties applicationCodeProperties;

  @Autowired
  private SourceImportExpenseHeadService sourceImportExpenseHeadService;

  @Autowired
  private SourceImportExpenseLineService sourceImportExpenseLineService;

  private final String TEMP_FIELD_ORGANIZATION_ID = "TEMP_FIELD_ORGANIZATION_ID";
  private final String TEMP_FIELD_BATCH_ID = "TEMP_FIELD_BATCH_ID";

  @Bean("AE_IMPORT_EXPENSE" + ExcelModelServiceContext.SERVICE_SUFFIX)
  public ExcelModelService<ExcelModelExpense> employeeModelService() {
    return new AbstractExcelModelService<ExcelModelExpense>() {

      @Override
      public void verifyUploadData(ExcelData<ExcelModelExpense> excelData) {
        List<CompanyDataPermissionVo> companyDataPermissionVoList = feignClientService
            .getUserDataPermissions();
        if (companyDataPermissionVoList.size() == 0) {
          throw new BizException("您没有授权公司信息，不能进行导入操作！");
        }
        Set<String> organizationIdSet = companyDataPermissionVoList.stream()
            .map(CompanyDataPermissionVo::getOrganizationId).collect(Collectors.toSet());

        for (int rowIndex = 0; rowIndex < excelData.getRows().size(); rowIndex++) {
          verifyUploadOneData(excelData, rowIndex, organizationIdSet);
        }
      }

      public void verifyUploadOneData(ExcelData<ExcelModelExpense> excelData, int rowIndex,
          Set<String> organizationIdSet) {
        ExcelModelExpense excelModelExpense = excelData.getRows().get(rowIndex);
        String organizationId = null;
        try {
          OrganizationClientVo organizationClientVo = feignClientService
              .selectOrganizationByCode(excelModelExpense.getOrganizationNumber());
          if (organizationClientVo == null) {
            excelService.addErrorMessage(excelData, rowIndex, "[{}]匹配公司失败",
                excelService.getTitleName(excelData, "organizationNumber"));
          }
          if (organizationClientVo != null) {
            if (!"2".equals(organizationClientVo.getOrganizationTypeEnumVal())) {
              excelService.addErrorMessage(excelData, rowIndex, "{}[{}]匹配公司失败",
                  excelService.getTitleName(excelData, "organizationNumber"),
                  excelModelExpense.getOrganizationNumber());
            } else if (StringUtil.isNotEmpty(organizationId)
                && !organizationId.equals(organizationClientVo.getOrganizationId())) {
              excelService.addErrorMessage(excelData, rowIndex, "同一批次不能导入多个公司数据");
            } else if (!organizationIdSet.contains(organizationClientVo.getOrganizationId())) {
              excelService.addErrorMessage(excelData, rowIndex, "没有公司[{}]数据权限",
                  excelModelExpense.getOrganizationNumber());
            }
            organizationId = organizationClientVo.getOrganizationId();
            excelData.getTempRows().get(rowIndex).put(TEMP_FIELD_ORGANIZATION_ID, organizationId);
          }
        } catch (BizException e) {
          excelService.addErrorMessage(excelData, rowIndex, e.getMessage());
        }
      }


      @Override
      public void saveUploadData(ExcelData<ExcelModelExpense> excelData) {
        String aeBatchId = aeSourceBatchService.getSequence();
        String organizationId = excelData.getTempRows().get(0).get(TEMP_FIELD_ORGANIZATION_ID);
        List<ExcelModelExpense> list = excelData.getRows();
        for (int rowIndex = 0; list != null && rowIndex < list.size(); rowIndex++) {
          excelData.getTempRows().get(rowIndex).put(TEMP_FIELD_BATCH_ID, aeBatchId);
          saveUploadOneData(excelData, rowIndex);
        }
        AeSourceBatch aeSourceBatch = new AeSourceBatch();
        aeSourceBatch.setAeBatchId(aeBatchId);
        aeSourceBatch.setSourceBatchId(aeBatchId);
        aeSourceBatch.setActiveFlag(1);
        aeSourceBatch.setApplicationCode(
            applicationCodeProperties.getApplicationCodeImportExpense());
        aeSourceBatch.setTenantId(ThreadContextHolder.getTenantId());
        aeSourceBatch.setOrganizationId(organizationId);
        aeSourceBatch.setAeBatchCode(aeSourceBatchService.selectAeBatchCode());
        aeSourceBatchService.save(aeSourceBatch);
      }

      public void saveUploadOneData(ExcelData<ExcelModelExpense> excelData, int rowIndex) {
        try {
          ExcelModelExpense excelModelExpense = excelData.getRows().get(rowIndex);
          String sourceBatchId = excelData.getTempRows().get(rowIndex).get(TEMP_FIELD_BATCH_ID);
          String sourceOrganizationId = excelData.getTempRows().get(rowIndex)
              .get(TEMP_FIELD_ORGANIZATION_ID);
          List<SourceImportExpenseHead> list = sourceImportExpenseHeadService
              .list(new LambdaQueryWrapper<SourceImportExpenseHead>()
                  .eq(SourceImportExpenseHead::getSourceBatchId, sourceBatchId)
                  .eq(SourceImportExpenseHead::getDocumentNumber,
                      excelModelExpense.getDocumentNumber()));
          SourceImportExpenseHead sourceImportExpenseHead = null;
          if (list.size() == 1) {
            //保存头信息
            sourceImportExpenseHead = list.get(0);
          } else if (list.size() > 1) {
            throw new BizException("导入多个头数据,系统异常");
          } else {
            sourceImportExpenseHead = new SourceImportExpenseHead();
            BeanUtils.copyProperties(excelModelExpense, sourceImportExpenseHead);
            sourceImportExpenseHead.setSourceHeadId(sourceImportExpenseHeadService.getSequence());
            sourceImportExpenseHead.setSourceBatchId(sourceBatchId);
            sourceImportExpenseHead.setOrganizationId(sourceOrganizationId);
            sourceImportExpenseHeadService.save(sourceImportExpenseHead);
          }
          //保存行信息
          SourceImportExpenseLine sourceImportExpenseLine = new SourceImportExpenseLine();
          BeanUtils.copyProperties(excelModelExpense, sourceImportExpenseLine);
          sourceImportExpenseLine.setSourceBatchId(sourceBatchId);
          sourceImportExpenseLine.setSourceHeadId(sourceImportExpenseHead.getSourceHeadId());
          sourceImportExpenseLine.setSourceLineId(sourceImportExpenseLineService.getSequence());
          sourceImportExpenseLineService.save(sourceImportExpenseLine);
        } catch (BizException e) {
          excelService.addErrorMessage(excelData, rowIndex, e.getMessage());
        }
      }
    };
  }

}
