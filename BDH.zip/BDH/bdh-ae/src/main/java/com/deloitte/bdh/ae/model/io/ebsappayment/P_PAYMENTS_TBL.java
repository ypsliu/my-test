package com.deloitte.bdh.ae.model.io.ebsappayment;

import com.alibaba.fastjson.annotation.JSONField;
import java.util.List;
import lombok.Data;

/**
 * @author Ashen
 * @date 21/04/2020
 */
@Data
public class P_PAYMENTS_TBL {

  @JSONField(name = "P_PAYMENTS_TBL_ITEM")
  private List<P_PAYMENTS_TBL_ITEM> P_PAYMENTS_TBL_ITEM;

}
