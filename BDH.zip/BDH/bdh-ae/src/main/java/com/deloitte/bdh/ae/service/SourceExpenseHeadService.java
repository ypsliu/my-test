package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.SourceExpenseHead;
import com.deloitte.bdh.ae.model.io.DataOutput;
import com.deloitte.bdh.ae.model.io.OneDataInput;
import com.deloitte.bdh.ae.model.io.expense.ExpenseDataInput;
import com.deloitte.bdh.ae.model.io.expense.ExpenseDataOutput;
import com.deloitte.bdh.ae.model.io.target.TargetDataOutput;
import com.deloitte.bdh.common.base.Service;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface SourceExpenseHeadService extends Service<SourceExpenseHead> {

  ExpenseDataOutput putData(ExpenseDataInput expenseDataInput);

  TargetDataOutput getTargetDate(OneDataInput oneDataInput);

  DataOutput revertData(OneDataInput oneDataInput);
}
