package com.deloitte.bdh.ae.model.io.ebsgl;

import com.alibaba.fastjson.annotation.JSONField;
import java.util.List;
import lombok.Data;

/**
 * @author Ashen
 * @date 09/02/2021
 */
@Data
public class P_PROCESS_DATA_DEL {

  @JSONField(name = "P_PROCESS_DATA_DEL_ITEM")
  private List<P_PROCESS_DATA_DEL_ITEM> p_process_data_del_itemList;
}
