package com.deloitte.bdh.ae.client.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2020-08-18
 */
@ApiModel(value = "查询系统值列表请求视图")
@Data
public class BaseEnumValueDto implements Serializable {

  @ApiModelProperty(value = "CODE")
  private String code;
}
