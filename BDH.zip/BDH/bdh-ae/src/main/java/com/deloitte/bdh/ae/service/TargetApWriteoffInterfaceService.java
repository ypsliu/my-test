package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.TargetApWriteoffInterface;
import com.deloitte.bdh.ae.model.TargetSourceBasicInfo;
import com.deloitte.bdh.ae.model.io.ebsapwriteoff.P_APPLY_PREPAY_TBL_ITEM;
import com.deloitte.bdh.common.base.Service;
import java.util.List;
import java.util.Set;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface TargetApWriteoffInterfaceService extends Service<TargetApWriteoffInterface> {

  /**
   * 查询AP 核销信息
   *
   * @param aeBatchId
   * @return
   */
  List<P_APPLY_PREPAY_TBL_ITEM> queryInvoicesItem(String aeBatchId);

  /**
   * 查询目标数据
   *
   * @param lineNumberSet
   * @param aeBatchId
   * @return
   */
  List<TargetSourceBasicInfo> selectByLineNumberSet(Set<String> lineNumberSet,
      String aeBatchId);
}
