package com.deloitte.bdh.ae.service;

/**
 * @author Ashen
 * @date 21/04/2020
 */
public interface EbsDataArService {

  /**
   * 推送数据到EBS Ar
   *
   * @param aeBatchId
   */
  void putDataToEbsAr(String aeBatchId);
}
