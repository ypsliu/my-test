package com.deloitte.bdh.engine.config.entity;

import lombok.Data;

/**
 * 日记账定义下的规则信息
 *
 * @author Ashen
 * @date 20/12/2019
 */
@Data
public class JournalAndRule {

  private String ruleId;

  private JournalRule journalRule;

}
