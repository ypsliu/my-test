package com.deloitte.bdh.ae.model.io.ap;

import com.deloitte.bdh.ae.model.SourceApInvoiceHead;

/**
 * @author Ashen
 * @date 20/04/2020
 */
public class SourceApInvoiceHeadInput extends SourceApInvoiceHead {

}
