package com.deloitte.bdh.ae.model.io.ebsar;

import com.alibaba.fastjson.annotation.JSONField;
import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

/**
 * @author Ashen
 * @date 21/04/2020
 */
@Data
public class P_TRX_TBL_ITEM {

  @JSONField(name = "ORG_NAME", ordinal = 1)
  private String ORG_NAME;

  @JSONField(name = "SOURCE_NAME", ordinal = 2)
  private String SOURCE_NAME;

  @JSONField(name = "CLASS_MEANING", ordinal = 3)
  private String CLASS_MEANING;

  @JSONField(name = "TRX_NUMBER", ordinal = 4)
  private String TRX_NUMBER;

  @JSONField(name = "TRX_TYPE_NAME", ordinal = 5)
  private String TRX_TYPE_NAME;

  @JSONField(name = "TRX_DATE", format = "yyyy-MM-dd", ordinal = 6)
  private Date TRX_DATE;

  @JSONField(name = "GL_DATE", format = "yyyy-MM-dd", ordinal = 7)
  private Date GL_DATE;

  @JSONField(name = "CURRENCY_CODE", ordinal = 8)
  private String CURRENCY_CODE;

  @JSONField(name = "RATE_DATE", format = "yyyy-MM-dd", ordinal = 9)
  private Date RATE_DATE;

  @JSONField(name = "RATE_TYPE", ordinal = 10)
  private String RATE_TYPE;

  @JSONField(name = "RATE_RATE", ordinal = 11)
  private String RATE_RATE;

  @JSONField(name = "CUSTOMER_NUMBER", ordinal = 12)
  private String CUSTOMER_NUMBER;

  @JSONField(name = "CUSTOMER_NAME", ordinal = 13)
  private String CUSTOMER_NAME;

  @JSONField(name = "ADDRESS_NAME", ordinal = 14)
  private String ADDRESS_NAME;

  @JSONField(name = "ADDRESS_LINE1", ordinal = 15)
  private String ADDRESS_LINE1;

  @JSONField(name = "TERM_NAME", ordinal = 16)
  private String TERM_NAME;

  @JSONField(name = "DESCRIPTION", ordinal = 17)
  private String DESCRIPTION;

  @JSONField(name = "EN_COMMENTS", ordinal = 18)
  private String EN_COMMENTS;

  @JSONField(name = "VAT_TYPE", ordinal = 19)
  private String VAT_TYPE;

  @JSONField(name = "LINE_NUMBER", ordinal = 20)
  private String LINE_NUMBER;

  @JSONField(name = "MEMO_LINE", ordinal = 21)
  private String MEMO_LINE;

  @JSONField(name = "QUANTITY", ordinal = 22)
  private BigDecimal QUANTITY;

  @JSONField(name = "PRICE", ordinal = 23)
  private BigDecimal PRICE;

  @JSONField(name = "AMOUNT", ordinal = 24)
  private BigDecimal AMOUNT;

  @JSONField(name = "TAX_CODE", ordinal = 25)
  private String TAX_CODE;

  @JSONField(name = "SALE_NUM", ordinal = 26)
  private String SALE_NUM;

  @JSONField(name = "LINE_TYPE", ordinal = 49)
  private String LINE_TYPE;

  @JSONField(name = "ITEM_NUMBER", ordinal = 50)
  private String ITEM_NUMBER;
}
