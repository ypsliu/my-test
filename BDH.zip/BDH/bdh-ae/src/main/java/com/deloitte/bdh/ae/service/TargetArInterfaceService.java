package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.TargetArInterface;
import com.deloitte.bdh.ae.model.TargetSourceBasicInfo;
import com.deloitte.bdh.ae.model.io.ebsar.P_TRX_TBL_ITEM;
import com.deloitte.bdh.common.base.Service;
import java.util.List;
import java.util.Set;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface TargetArInterfaceService extends Service<TargetArInterface> {

  /**
   * 根据LineNo 查询目标数据的来源基本信息
   *
   * @param lineNumberSet
   * @return
   */
  List<TargetSourceBasicInfo> selectByLineNumberSet(Set<String> lineNumberSet);

  List<P_TRX_TBL_ITEM> queryInvoicesItem(String aeBatchId);
}
