package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.deloitte.bdh.ae.dao.ae.SourcePaymentHeadMapper;
import com.deloitte.bdh.ae.model.AeSourceBatch;
import com.deloitte.bdh.ae.model.SourcePaymentHead;
import com.deloitte.bdh.ae.model.io.OneDataInput;
import com.deloitte.bdh.ae.model.io.payment.PaymentDataInput;
import com.deloitte.bdh.ae.model.io.payment.PaymentDataLineInput;
import com.deloitte.bdh.ae.model.io.payment.PaymentDataOutput;
import com.deloitte.bdh.ae.model.io.target.TargetDataHeadOutput;
import com.deloitte.bdh.ae.model.io.target.TargetDataLineOutput;
import com.deloitte.bdh.ae.model.io.target.TargetDataOutput;
import com.deloitte.bdh.ae.properties.ApplicationCodeProperties;
import com.deloitte.bdh.ae.service.AeSourceBatchService;
import com.deloitte.bdh.ae.service.AeTenantMethodService;
import com.deloitte.bdh.ae.service.SourcePaymentHeadService;
import com.deloitte.bdh.ae.service.SourcePaymentLineService;
import com.deloitte.bdh.ae.service.TargetGlInterfaceService;
import com.deloitte.bdh.common.base.ServiceTransactionalImpl;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.common.exception.BizException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Resource;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Service
@DS(DSConstant.AE_DB)
public class SourcePaymentHeadServiceImpl extends
    ServiceTransactionalImpl<SourcePaymentHeadMapper, SourcePaymentHead> implements
    SourcePaymentHeadService {

  @Autowired
  private AeSourceBatchService aeSourceBatchService;

  @Resource
  private SourcePaymentLineService sourcePaymentLineService;

  @Resource
  private SourcePaymentHeadService sourcePaymentHeadService;

  @Resource
  private TargetGlInterfaceService targetGlInterfaceService;

  @Autowired
  private AeTenantMethodService aeTenantMethodService;

  @Autowired
  private ApplicationCodeProperties applicationCodeProperties;

  @Override
  @Transactional(rollbackFor = Exception.class)
  public PaymentDataOutput putData(PaymentDataInput paymentDataInput) {
    aeTenantMethodService.verifyTenantApplication(paymentDataInput.getTenantId(),
        paymentDataInput.getApplicationCode(),
        applicationCodeProperties.getApplicationCodePayment());
    PaymentDataOutput paymentDataOutput = new PaymentDataOutput();
    if (paymentDataInput == null || paymentDataInput.getLineList() == null
        || paymentDataInput.getLineList().size() == 0) {
      throw new BizException("行信息不能为空");
    }
    String aeBatchCode = aeSourceBatchService.selectAeBatchCode();
    String aeBatchId = this.getSequence();
    insertHeadList(paymentDataInput.getLineList(), aeBatchId);
    insertLineList(paymentDataInput.getLineList(), aeBatchId);
    AeSourceBatch aeSourceBatch = new AeSourceBatch();
    aeSourceBatch.setAeBatchId(aeBatchId);
    aeSourceBatch.setSourceBatchId(aeBatchId);
    aeSourceBatch.setActiveFlag(1);
    aeSourceBatch.setApplicationCode(paymentDataInput.getApplicationCode());
    aeSourceBatch.setTenantId(paymentDataInput.getTenantId());
    aeSourceBatch.setOrganizationId(paymentDataInput.getOrganizationId());
    aeSourceBatch.setAeBatchCode(aeBatchCode);
    aeSourceBatchService.save(aeSourceBatch);
    paymentDataOutput.setAeBatchId(aeBatchId);
    paymentDataOutput.setMessage("成功");
    paymentDataOutput.setStatus("OK");
    return paymentDataOutput;
  }

  private void insertLineList(List<PaymentDataLineInput> lineList, String aeBatchId) {
    lineList.forEach(paymentDataLineInput -> {
      paymentDataLineInput.setSourceBatchId(aeBatchId);
      sourcePaymentLineService.save(paymentDataLineInput);
    });
  }

  private void insertHeadList(List<PaymentDataLineInput> lineList, String aeBatchId) {
    lineList.forEach(paymentDataLineInput -> {
      SourcePaymentHead sourcePaymentHead = new SourcePaymentHead();
      BeanUtils.copyProperties(paymentDataLineInput, sourcePaymentHead);
      sourcePaymentHead.setSourceBatchId(aeBatchId);
      sourcePaymentHeadService.save(sourcePaymentHead);
    });
  }


  @Override
  public TargetDataOutput getTargetDate(OneDataInput oneDataInput) {
    TargetDataOutput targetDataOutput = new TargetDataOutput();
    try {
      AeSourceBatch aeSourceBatch = aeSourceBatchService.getById(oneDataInput.getAeBatchId());
      if (aeSourceBatch == null) {
        throw new BizException("查询批次信息失败！");
      }
      if (!"OK".equals(aeSourceBatch.getEbsStatus())) {
        throw new BizException("目标数据还在生成中...");
      }
      List<TargetDataHeadOutput> targetDataHeadOutputList = targetGlInterfaceService
          .queryTargetHeadList(oneDataInput.getAeBatchId(),
              oneDataInput.getSourceHeadId());
      targetDataOutput.setHeadList(targetDataHeadOutputList);
      if (targetDataHeadOutputList.size() == 0) {
        throw new BizException("单据头列表不能为空");
      }
      List<TargetDataLineOutput> targetDataLineOutputList = targetGlInterfaceService
          .queryTargetLineList(oneDataInput.getAeBatchId(),
              oneDataInput.getSourceHeadId());
      if (targetDataLineOutputList.size() == 0) {
        throw new BizException("单据行信息不能为空");
      }
      Map<String, List<TargetDataLineOutput>> lineMap = targetDataLineOutputList.stream().collect(
          Collectors.groupingBy(TargetDataLineOutput::getAeEbsHeadId));
      targetDataHeadOutputList.forEach(targetDataHeadOutput -> {
        targetDataHeadOutput.setOrganizationId(aeSourceBatch.getOrganizationId());
        targetDataHeadOutput.setTenantId(aeSourceBatch.getTenantId());
        List<TargetDataLineOutput> lineList = lineMap.get(targetDataHeadOutput.getAeEbsHeadId());
        if (lineList == null || lineList.size() == 0) {
          throw new BizException("单据编号：" + targetDataHeadOutput.getAeEbsNumber() + "的行信息不能为空！");
        }
        targetDataHeadOutput.setLineList(lineList);
      });
      targetDataOutput.setStatus("OK");
    } catch (Exception e) {
      targetDataOutput.setStatus("FAIL");
      targetDataOutput.setMessage("获取目标数据失败:" + e.getMessage());
    }
    return targetDataOutput;
  }

}
