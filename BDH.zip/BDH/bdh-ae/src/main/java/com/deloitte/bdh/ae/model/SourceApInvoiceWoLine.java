package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "SourceApInvoiceWoLine对象", description = "")
public class SourceApInvoiceWoLine extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableField("REQUEST_HEADER_ID")
  private String requestHeaderId;

  @TableField("WRITEOFF_ID")
  private String writeoffId;

  @TableField("AP_PAY_HEADER_ID")
  private String apPayHeaderId;

  @TableField("AP_PAY_NUMBER")
  private String apPayNumber;

  @TableField("AP_PAY_LINE_ID")
  private String apPayLineId;

  @TableField("PREPEMENTS_AMOUNT")
  private BigDecimal prepementsAmount;

  @TableField("WRITE_OFF_AMOUNT")
  private BigDecimal writeOffAmount;

  @TableField("COMMENTS")
  private String comments;

  @TableField("SOURCE_DOC_NUMBER")
  private String sourceDocNumber;

  @TableField("AE_ROW_ID")
  private String aeRowId;

  @TableField("AE_STATUS")
  private String aeStatus;

  @TableField("SOURCE_BATCH_ID")
  private String sourceBatchId;

  @TableField("SOURCE_HEAD_ID")
  private String sourceHeadId;

  @TableField("SOURCE_LINE_ID")
  private String sourceLineId;


}
