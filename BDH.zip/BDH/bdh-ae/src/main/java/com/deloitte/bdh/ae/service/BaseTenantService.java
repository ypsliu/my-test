package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.BaseTenant;
import com.deloitte.bdh.common.base.Service;

/**
 * <p>
 * 租户表 服务类
 * </p>
 *
 * @author Ashen
 * @since 2020-09-09
 */
public interface BaseTenantService extends Service<BaseTenant> {

  /**
   * 根据租户code查询租户信息
   *
   * @param tenantCode
   * @return
   */
  BaseTenant getTenantByCode(String tenantCode);
}
