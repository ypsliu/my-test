package com.deloitte.bdh.ae.dao.ae;

import com.deloitte.bdh.ae.model.SourcePsSalaryLine;
import com.deloitte.bdh.common.base.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface SourcePsSalaryLineMapper extends Mapper<SourcePsSalaryLine> {

  /**
   * 查询一条最大版本的数据
   *
   * @param psCompanyId
   * @param period
   * @return
   */
  SourcePsSalaryLine selectOneDataMaxVersion(@Param("psCompanyId") String psCompanyId,
      @Param("period") String period);
}
