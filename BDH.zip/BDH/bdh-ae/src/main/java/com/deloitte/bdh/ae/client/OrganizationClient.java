package com.deloitte.bdh.ae.client;

import com.deloitte.bdh.ae.client.dto.FndPortalOrganizationDto;
import com.deloitte.bdh.ae.client.vo.OrganizationClientVo;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.RetResult;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * @author Ashen
 * @date 17/12/2020
 */
@FeignClient(value = "bdh-platform", contextId = "organization-client")
@Component
public interface OrganizationClient {

  /**
   * 获取公司列表
   *
   * @param retRequest
   * @return
   */
  @PostMapping("/platform/commonDatas/tenantOrganizations")
  RetResult<List<OrganizationClientVo>> getTenantCompanyList(RetRequest<Void> retRequest);


  /**
   * 获取公司列表
   *
   * @param retRequest
   * @return
   */
  @PostMapping("/platform/organizations/selectOneByCode")
  RetResult<OrganizationClientVo> selectOneByCode(RetRequest<FndPortalOrganizationDto> retRequest);
}
