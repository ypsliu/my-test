package com.deloitte.bdh.ae.client.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.LocalDate;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * BI公司与其他系统 映射
 * </p>
 *
 * @author Ashen
 * @since 2020-12-10
 */
@Data
public class BiDataCompanySystemVo extends BaseModel {

  private String companySystemId;
  private String systemName;
  private String systemCode;
  private String segment1Name;
  private String segment1Code;
  @ApiModelProperty(value = "系统枚举值：EBS;PS;")
  private String systemType;

  private Integer activeFlag;

  private LocalDate startDateActive;

  private LocalDate endDateActive;

  @ApiModelProperty(value = "portal公司ID")
  private String organizationId;

  @ApiModelProperty(value = "公司段英文")
  private String segment1NameEn;

  @ApiModelProperty(value = "portal公司中文名")
  private String companyNameCn;

  @ApiModelProperty(value = "portal公司英文名")
  private String companyNameEn;

}
