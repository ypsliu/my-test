package com.deloitte.bdh.ae.model;

import java.math.BigDecimal;
import com.deloitte.bdh.common.base.BaseModel;
import java.time.LocalDate;
import com.baomidou.mybatisplus.annotation.TableField;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 借款付款行信息
 * </p>
 *
 * @author Ashen
 * @since 2021-03-24
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "SourceImportPaymentLine对象", description = "借款付款行信息")
public class SourceImportPaymentLine extends BaseModel {

  private static final long serialVersionUID = 1L;

  @ApiModelProperty(value = "申请单据编号")
  @TableField("DOCUMENT_NUMBER")
  private String documentNumber;

  @ApiModelProperty(value = "申请人名称")
  @TableField("REQUEST_USER_NAME")
  private String requestUserName;

  @ApiModelProperty(value = "申请日期")
  @TableField("LINE_DATE")
  private LocalDate lineDate;

  @ApiModelProperty(value = "付款申请金额")
  @TableField("LINE_AMOUNT")
  private BigDecimal lineAmount;

  @ApiModelProperty(value = "备注")
  @TableField("LINE_COMMENTS")
  private String lineComments;

  @TableField("SOURCE_BATCH_ID")
  private String sourceBatchId;

  @TableField("SOURCE_HEAD_ID")
  private String sourceHeadId;

  @TableField("SOURCE_LINE_ID")
  private String sourceLineId;

  @TableField("AE_ROW_ID")
  private String aeRowId;

  @TableField("AE_STATUS")
  private String aeStatus;


}
