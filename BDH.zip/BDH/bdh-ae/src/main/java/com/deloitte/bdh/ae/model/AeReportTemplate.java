package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.deloitte.bdh.ae.model.vo.CompanyDataPermissionVo;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "AeReportTemplate对象", description = "")
public class AeReportTemplate extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableId("REPORT_ID")
  private String reportId;

  @TableField("APPLICATION_ID")
  private String applicationId;

  @TableField("REPORT_NAME")
  private String reportName;

  @TableField("REPORT_CODE")
  private String reportCode;

  @TableField("AUTH_FLAG")
  private String authFlag;

  @TableField("LANG")
  private String lang;

  @TableField("ACTIVE_FLAG")
  private Integer activeFlag;

  @TableField("OWNER_ID")
  private String ownerId;

  @TableField("OWNER_TYPE")
  private String ownerType;

  @TableField(exist = false)
  @ApiModelProperty(value = "所有者显示值")
  private String ownerTypeShow;

  @TableField(exist = false)
  @ApiModelProperty(value = "公司ID")
  private String organizationId;

  @TableField(exist = false)
  @ApiModelProperty(value = "选择公司列表")
  private List<CompanyDataPermissionVo> organizationList;

  @TableField(exist = false)
  @ApiModelProperty(value = "选择字段列表")
  private List<AeReportTempField> fieldList;

  @TableField(exist = false)
  @ApiModelProperty(value = "语言显示值")
  private String langShow;

  @TableField(exist = false)
  @ApiModelProperty(value = "应用产品名称")
  private String applicationName;
}
