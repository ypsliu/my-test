package com.deloitte.bdh.common.properties;


import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

/**
 * oss属性配置
 *
 * @author pengdh
 * @date 2018/05/24
 */
@RefreshScope
@Configuration
@Data
public class OssProperties {

  @Value("${oss.endpoint}")
  private String ossEndpoint;
  @Value("${target.endpoint}")
  private String targetEndpoint;
  @Value("${replacement.endpoint}")
  private String replacementEndpoint;
  @Value("${oss.accessKeyId}")
  private String ossAccesskeyId;
  @Value("${oss.accessKeySecret}")
  private String ossAccesskeySecret;
  @Value("${oss.bucketName}")
  private String ossBucketName;
  @Value("${oss.filepath}")
  private String ossFilepath;
  @Value("${modules.ocr.expense}")
  private String modulesOcrExpense;
}
