package com.deloitte.bdh.common.properties;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * rediskey配置类
 *
 * @author pengdh
 * @date 2018/05/17
 */
@Component
@RefreshScope
@Data
public class BdhProperties {

  @Value("${portal.temp.dir}")
  private String portalTempDir;

}
