package com.deloitte.bdh.ae.model.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author dahpeng
 * @date 2019/05/09
 */
@ApiModel(description = "枚举值列表响应视图")
public class EnumValueVo implements Serializable {

  private static final long serialVersionUID = 8674206075037771240L;
  @ApiModelProperty("值id")
  private String valueId;
  @ApiModelProperty("值内容")
  private String value;
  @ApiModelProperty("值含义")
  private String meaning;
  @ApiModelProperty("显示顺序")
  private BigDecimal displayOrder;
  @ApiModelProperty("枚举code")
  private String enumCode;

  public String getValueId() {
    return valueId;
  }

  public void setValueId(String valueId) {
    this.valueId = valueId;
  }

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  public String getMeaning() {
    return meaning;
  }

  public void setMeaning(String meaning) {
    this.meaning = meaning;
  }

  public BigDecimal getDisplayOrder() {
    return displayOrder;
  }

  public void setDisplayOrder(BigDecimal displayOrder) {
    this.displayOrder = displayOrder;
  }

  public String getEnumCode() {
    return enumCode;
  }

  public void setEnumCode(String enumCode) {
    this.enumCode = enumCode;
  }

  @Override
  public String toString() {
    return "EnumValueVo{" +
        "valueId=" + valueId +
        ", value='" + value + '\'' +
        ", meaning='" + meaning + '\'' +
        ", displayOrder=" + displayOrder +
        ", enumCode='" + enumCode + '\'' +
        '}';
  }
}
