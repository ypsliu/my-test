package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.ae.model.SourceImportPaymentLine;
import com.deloitte.bdh.ae.dao.ae.SourceImportPaymentLineMapper;
import com.deloitte.bdh.ae.service.SourceImportPaymentLineService;
import com.deloitte.bdh.common.base.ServiceTransactionalImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 借款付款行信息 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2021-03-24
 */
@Service
@DS(DSConstant.AE_DB)
public class SourceImportPaymentLineServiceImpl extends
    ServiceTransactionalImpl<SourceImportPaymentLineMapper, SourceImportPaymentLine> implements
    SourceImportPaymentLineService {

}
