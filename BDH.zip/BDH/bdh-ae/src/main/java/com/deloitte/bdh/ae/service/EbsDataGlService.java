package com.deloitte.bdh.ae.service;

/**
 * @author Ashen
 * @date 21/04/2020
 */
public interface EbsDataGlService {

  /**
   * 调用接口读取EBS GL数据
   *
   * @param aeBatchId
   */
  void getDataFromEbsGl(String aeBatchId);

  /**
   * 推送数据到EBS GL
   *
   * @param aeBatchId
   */
  void putDataToEbsGl(String aeBatchId);
}
