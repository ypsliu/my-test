package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "AeJournalDefine对象", description = "")
public class AeJournalDefine extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableId("JOURNAL_ID")
  private String journalId;

  @TableField("JOURNAL_CODE")
  private String journalCode;

  @TableField("JOURNAL_NAME")
  private String journalName;

  @TableField("ACTIVE_FLAG")
  private Integer activeFlag;

  @TableField("DESCRIPTION")
  private String description;

  @TableField("EVENT_TYPE_ID")
  private String eventTypeId;

  @TableField("APPLICATION_ID")
  private String applicationId;


}
