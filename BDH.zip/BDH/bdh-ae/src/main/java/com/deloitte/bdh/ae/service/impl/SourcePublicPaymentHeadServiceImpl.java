package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.deloitte.bdh.ae.dao.ae.SourcePublicPaymentHeadMapper;
import com.deloitte.bdh.ae.model.AeSourceBatch;
import com.deloitte.bdh.ae.model.SourcePublicPaymentHead;
import com.deloitte.bdh.ae.model.TargetApPaymentInterface;
import com.deloitte.bdh.ae.model.io.DataOutput;
import com.deloitte.bdh.ae.model.io.OneDataInput;
import com.deloitte.bdh.ae.model.io.publicpayment.PublicPaymentDataInput;
import com.deloitte.bdh.ae.model.io.publicpayment.SourcePublicPaymentHeadInput;
import com.deloitte.bdh.ae.model.io.publicpayment.SourcePublicPaymentLineInput;
import com.deloitte.bdh.ae.model.io.target.TargetDataOutput;
import com.deloitte.bdh.ae.properties.ApplicationCodeProperties;
import com.deloitte.bdh.ae.service.AeSourceBatchService;
import com.deloitte.bdh.ae.service.AeTenantMethodService;
import com.deloitte.bdh.ae.service.SourcePublicPaymentHeadService;
import com.deloitte.bdh.ae.service.SourcePublicPaymentLineService;
import com.deloitte.bdh.ae.service.TargetApPaymentInterfaceService;
import com.deloitte.bdh.common.base.ServiceTransactionalImpl;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.common.exception.BizException;
import java.util.List;
import javax.annotation.Resource;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Service
@DS(DSConstant.AE_DB)
public class SourcePublicPaymentHeadServiceImpl extends
    ServiceTransactionalImpl<SourcePublicPaymentHeadMapper, SourcePublicPaymentHead> implements
    SourcePublicPaymentHeadService {

  @Autowired
  private AeTenantMethodService aeTenantMethodService;

  @Autowired
  private ApplicationCodeProperties applicationCodeProperties;

  @Autowired
  private AeSourceBatchService aeSourceBatchService;

  @Resource
  private SourcePublicPaymentHeadService sourcePublicPaymentHeadService;

  @Resource
  private SourcePublicPaymentLineService sourcePublicPaymentLineService;

  @Resource
  private TargetApPaymentInterfaceService targetApPaymentInterfaceService;


  @Override
  @Transactional(rollbackFor = Exception.class)
  public DataOutput putData(PublicPaymentDataInput publicPaymentDataInput) {
    aeTenantMethodService
        .verifyTenantApplication(publicPaymentDataInput.getTenantId(),
            publicPaymentDataInput.getApplicationCode(),
            applicationCodeProperties.getApplicationCodeScmPublicPayment());
    DataOutput dataOutput = new DataOutput();
    if (publicPaymentDataInput == null || publicPaymentDataInput.getHeadList() == null
        || publicPaymentDataInput.getHeadList().size() == 0) {
      throw new BizException("头信息不能为空");
    }
    if (publicPaymentDataInput.getLineList() == null
        || publicPaymentDataInput.getLineList().size() == 0) {
      throw new BizException("行信息不能为空");
    }
    String aeBatchCode = aeSourceBatchService.selectAeBatchCode();
    String aeBatchId = this.getSequence();
    insertHeadList(publicPaymentDataInput.getHeadList(), aeBatchId);
    insertLineList(publicPaymentDataInput.getLineList(), aeBatchId);
    AeSourceBatch aeSourceBatch = new AeSourceBatch();
    aeSourceBatch.setAeBatchId(aeBatchId);
    aeSourceBatch.setSourceBatchId(aeBatchId);
    aeSourceBatch.setActiveFlag(1);
    aeSourceBatch.setApplicationCode(publicPaymentDataInput.getApplicationCode());
    aeSourceBatch.setTenantId(publicPaymentDataInput.getTenantId());
    aeSourceBatch.setOrganizationId(publicPaymentDataInput.getOrganizationId());
    aeSourceBatch.setAeBatchCode(aeBatchCode);
    aeSourceBatchService.save(aeSourceBatch);
    dataOutput.setAeBatchId(aeBatchId);
    dataOutput.setMessage("成功");
    dataOutput.setStatus("OK");
    return dataOutput;
  }

  private void insertHeadList(List<SourcePublicPaymentHeadInput> headList, String aeBatchId) {
    headList.forEach(sourcePublicPaymentHeadInput -> {
      sourcePublicPaymentHeadInput.setSourceBatchId(aeBatchId);
      if (Strings.isEmpty(sourcePublicPaymentHeadInput.getSourceHeadId())) {
        throw new BizException("来源头ID不能为空");
      }
      sourcePublicPaymentHeadService.save(sourcePublicPaymentHeadInput);
    });
  }

  private void insertLineList(List<SourcePublicPaymentLineInput> lineList, String aeBatchId) {
    lineList.forEach(sourcePublicPaymentLineInput -> {
      sourcePublicPaymentLineInput.setSourceBatchId(aeBatchId);
      if (Strings.isEmpty(sourcePublicPaymentLineInput.getSourceHeadId())) {
        throw new BizException("来源头ID不能为空");
      }
      if (Strings.isEmpty(sourcePublicPaymentLineInput.getSourceLineId())) {
        throw new BizException("来源行ID不能为空");
      }
      sourcePublicPaymentLineService.save(sourcePublicPaymentLineInput);
    });
  }

  @Override
  public DataOutput revertData(OneDataInput oneDataInput) {
    return null;
  }

  @Override
  public TargetDataOutput getTargetDate(OneDataInput oneDataInput) {
    TargetDataOutput targetDataOutput = new TargetDataOutput();
    AeSourceBatch aeSourceBatch = aeSourceBatchService.getById(oneDataInput.getAeBatchId());
    if (aeSourceBatch == null) {
      throw new BizException("查询批次信息失败！");
    }
    if (!"OK".equals(aeSourceBatch.getEbsStatus())) {
      throw new BizException("目标数据还在生成中...");
    }
    //查询该批次该头ID的目标数据量
    Integer targetCount = targetApPaymentInterfaceService
        .count(new LambdaQueryWrapper<TargetApPaymentInterface>()
            .eq(TargetApPaymentInterface::getAeBatchId, oneDataInput.getAeBatchId())
            .eq(TargetApPaymentInterface::getSourceHeadId, oneDataInput.getSourceHeadId()));
    if (targetCount == null || targetCount == 0) {
      throw new BizException("没查询到生成的目标数据");
    }
    targetDataOutput.setStatus("OK");
    return targetDataOutput;
  }
}
