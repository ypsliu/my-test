package com.deloitte.bdh.ae.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Ashen
 * @date 14/04/2020
 */
@Data
@ApiModel(description = "报表模板参数")
public class ReportDto {

  @ApiModelProperty(value = "报表Id")
  private String reportId;

}
