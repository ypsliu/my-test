package com.deloitte.bdh.ae.model.dto;

import lombok.Data;

/**
 * @author Ashen
 * @date 24/04/2020
 */
@Data
public class SourceQueryDto {

  private String aeBatchId;

  private String sourceHeadId;

  private String sourceLineId;

  public SourceQueryDto(String aeBatchId, String sourceHeadId, String sourceLineId) {
    this.aeBatchId = aeBatchId;
    this.sourceHeadId = sourceHeadId;
    this.sourceLineId = sourceLineId;
  }
}
