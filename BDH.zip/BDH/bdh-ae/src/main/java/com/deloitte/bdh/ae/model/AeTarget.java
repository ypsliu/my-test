package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "AeTarget对象", description = "")
public class AeTarget extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableId("TARGET_ID")
  private String targetId;

  @TableField("TABLE_ID")
  private String tableId;

  @TableField("APPLICATION_ID")
  private String applicationId;

  @TableField("TARGET_NAME")
  private String targetName;

  @TableField("TARGET_DESCRIPTION")
  private String targetDescription;

  @TableField("TARGET_DATA_TYPE")
  private String targetDataType;

  @TableField("ACCOUTING_FLAG")
  private BigDecimal accoutingFlag;

  @TableField("ACCOUTING_FIELD")
  private String accoutingField;

  @TableField("DISPLAY_CODE")
  private String displayCode;

  @TableField("DISPLAY_NAME")
  private String displayName;

  @TableField("ACTIVE_FLAG")
  private Integer activeFlag;

  @TableField("MERGE_FLAG")
  private Integer mergeFlag;

  @TableField("SWITCH_TARGET_NAME")
  private String switchTargetName;

  @TableField("REPORT_FLAG")
  private Integer reportFlag;


}
