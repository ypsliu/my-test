package com.deloitte.bdh.ae.dao.platform;

import com.deloitte.bdh.ae.model.CuxGlCoaList;
import com.deloitte.bdh.common.base.Mapper;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface CuxGlCoaListMapper extends Mapper<CuxGlCoaList> {

  List<CuxGlCoaList> selectListByCoaValue(@Param("ledgerId") String ledgerId,
      @Param("coaValueList") List<CuxGlCoaList> coaValueList);
}
