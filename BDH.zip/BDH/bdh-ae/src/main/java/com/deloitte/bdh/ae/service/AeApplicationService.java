package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.AeApplication;
import com.deloitte.bdh.common.base.Service;
import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface AeApplicationService extends Service<AeApplication> {

  /**
   * 查找租户下的应用产品
   *
   * @param tenantId
   * @return
   */
  List<AeApplication> selectByTenantId(String tenantId);

  /**
   * 查找租户和应用产品的数量
   *
   * @param tenantId
   * @param applicationCode
   * @return
   */
  Integer selectTenantAndApplicationCode(String tenantId, String applicationCode);
}
