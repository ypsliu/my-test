package com.deloitte.bdh.ae.model.io.ebsappayment;

import com.alibaba.fastjson.annotation.JSONField;
import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

/**
 * @author Ashen
 * @date 21/04/2020
 */
@Data
public class P_PAYMENTS_TBL_ITEM {

  @JSONField(name = "ORG_NAME", ordinal = 1)
  private String ORG_NAME;

  @JSONField(name = "AP_GRP_NUM ", ordinal = 2)
  private String AP_GRP_NUM;

  @JSONField(name = "VENDOR_NAME", ordinal = 3)
  private String VENDOR_NAME;

  @JSONField(name = "VENDOR_NUMBER", ordinal = 4)
  private String VENDOR_NUMBER;

  @JSONField(name = "VENDOR_SITE_CODE", ordinal = 5)
  private String VENDOR_SITE_CODE;

  @JSONField(name = "PAYMENT_DATE", format = "yyyy-MM-dd", ordinal = 6)
  private Date PAYMENT_DATE;

  @JSONField(name = "BANK_NAME", ordinal = 7)
  private String BANK_NAME;

  @JSONField(name = "PAYMENT_AMOUNT", ordinal = 8)
  private BigDecimal PAYMENT_AMOUNT;

  @JSONField(name = "INVOICE_CURRENCY", ordinal = 9)
  private String INVOICE_CURRENCY;

  @JSONField(name = "RATE_TYPE", ordinal = 10)
  private String RATE_TYPE;

  @JSONField(name = "EXCHANGE_DATE", format = "yyyy-MM-dd", ordinal = 14)
  private Date EXCHANGE_DATE;

  @JSONField(name = "EXCHANGE_RATE", ordinal = 15)
  private BigDecimal EXCHANGE_RATE;

  @JSONField(name = "PAYMENT_METHOD", ordinal = 16)
  private String PAYMENT_METHOD;

  @JSONField(name = "ATTACH_NUM", ordinal = 17)
  private String ATTACH_NUM;

  @JSONField(name = "CASHFLOW_ITEM", ordinal = 18)
  private String CASHFLOW_ITEM;

  @JSONField(name = "EN_COMMENTS", ordinal = 22)
  private String EN_COMMENTS;

  @JSONField(name = "DOCNUM", ordinal = 23)
  private String DOCNUM;

  @JSONField(name = "INVOICE_NUM", ordinal = 26)
  private String INVOICE_NUM;

  @JSONField(name = "LINE_AMOUNT", ordinal = 27)
  private BigDecimal LINE_AMOUNT;

  @JSONField(name = "PAYMENT_PROFILE", ordinal = 29)
  private String PAYMENT_PROFILE;
}
