package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.deloitte.bdh.ae.service.AeApplicationService;
import com.deloitte.bdh.ae.service.AeTenantMethodService;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.common.context.ThreadContextHolder;
import com.deloitte.bdh.common.exception.BizException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Ashen
 * @date 03/04/2020
 */
@Service
@DS(DSConstant.AE_DB)
public class AeTenantMethodServiceImpl implements AeTenantMethodService {

  @Autowired
  private AeApplicationService aeApplicationService;

  @Override
  public void verifyTenantApplication(String tenantId, String applicationCode,
      String applicationCodeStandard) {
    if (applicationCodeStandard == null || !applicationCodeStandard.equals(applicationCode)) {
      throw new BizException("应用产品代码不准确");
    }
    Integer result = aeApplicationService
        .selectTenantAndApplicationCode(ThreadContextHolder.getTenantId(), applicationCode);
    if (result == null) {
      throw new BizException("当前租户没有权限使用会计引擎产品：" + applicationCode);
    }
  }
}
