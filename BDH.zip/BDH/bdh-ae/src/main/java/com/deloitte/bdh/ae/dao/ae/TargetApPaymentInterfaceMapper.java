package com.deloitte.bdh.ae.dao.ae;

import com.deloitte.bdh.ae.model.TargetApPaymentInterface;
import com.deloitte.bdh.ae.model.TargetSourceBasicInfo;
import com.deloitte.bdh.ae.model.io.ebsappayment.P_PAYMENTS_TBL_ITEM;
import com.deloitte.bdh.common.base.Mapper;
import java.util.List;
import java.util.Set;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface TargetApPaymentInterfaceMapper extends Mapper<TargetApPaymentInterface> {

  /**
   * 查询AP支付信息
   *
   * @param aeBatchId
   * @return
   */
  List<P_PAYMENTS_TBL_ITEM> queryPaymentsItem(@Param("aeBatchId") String aeBatchId);

  /**
   * 根据apGrpNum 查询目标数据的来源基本信息
   *
   * @param apGrpNumSet
   * @param aeBatchId
   * @return
   */
  List<TargetSourceBasicInfo> selectByLineNumberSet(
      @Param("apGrpNumSet") Set<String> apGrpNumSet, @Param("aeBatchId") String aeBatchId);

}
