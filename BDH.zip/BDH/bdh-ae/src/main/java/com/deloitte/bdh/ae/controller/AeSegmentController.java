package com.deloitte.bdh.ae.controller;

import com.deloitte.bdh.ae.model.io.segment.SourceInput;
import com.deloitte.bdh.ae.model.io.segment.SourceOutput;
import com.deloitte.bdh.ae.service.AeSegmentService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Ashen
 * @date 24/04/2020
 */
@RestController
@Api(tags = "目标段值")
@RequestMapping("/aeSegment")
public class AeSegmentController {

  @Autowired
  private AeSegmentService aeSegmentService;

  @PostMapping("getSegment")
  @ApiOperation(value = "分页查看批次下单据信息")
  public SourceOutput getSegment(@RequestBody SourceInput sourceInput) {
    SourceOutput sourceOutput = null;
    try {
      sourceOutput = aeSegmentService.getSegment(sourceInput);
      sourceOutput.setStatus("OK");
    } catch (Exception e) {
      sourceOutput = new SourceOutput();
      sourceOutput.setStatus("FAIL");
      sourceOutput.setMessage(e.getMessage());
    }
    return sourceOutput;
  }

}
