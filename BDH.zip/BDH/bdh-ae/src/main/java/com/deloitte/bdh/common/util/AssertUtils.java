package com.deloitte.bdh.common.util;

import com.deloitte.bdh.common.exception.BizException;
import java.util.Collection;

/**
 * @author wangjq
 */
public class AssertUtils {

  /**
   * 判断是否为NULL
   *
   * @param obj
   */
  public static void assertNotEmpty(String obj, String message, String... params) {
    if (StringUtil.isEmpty(obj)) {
      throw new BizException(StringUtil.replaceParams(message, params));
    }
  }

  /**
   * 判断对象是否为NULL
   *
   * @param obj
   */

  public static void assertNotNull(Object obj, String message) {
    if (obj == null) {
      throw new BizException(message);
    }
  }

  /**
   * 判断对象是否为NULL
   *
   * @param obj
   */

  public static void assertNotNull(Object obj, String message, String... params) {
    if (obj == null) {
      throw new BizException(StringUtil.replaceParams(message, params));
    }
  }


  /**
   * 判读列表为空抛出异常
   *
   * @param collection
   * @return
   */
  public static void assertNotEmpty(Collection<?> collection, String message,
      String... params) {
    if (collection == null || collection.isEmpty()) {
      throw new BizException(StringUtil.replaceParams(message, params));
    }
  }

  /**
   * 判读列表为不为空抛出异常
   *
   * @param collection
   * @return
   */
  public static void assertEmpty(Collection<?> collection, String message,
      String... params) {
    if (collection != null && !collection.isEmpty()) {
      throw new BizException(StringUtil.replaceParams(message, params));
    }
  }
}
