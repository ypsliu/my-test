package com.deloitte.bdh.engine.config.entity;

import java.math.BigDecimal;
import java.util.List;
import lombok.Data;

/**
 * 条件
 *
 * @author Ashen
 * @date 04/12/2019
 */
@Data
public class JournalCondition {

  private String parentId;

  /**
   * 优先级
   */
  private BigDecimal priorityLevel;
  /**
   * 操作
   */
  private String operator;

  /**
   * 来源ID
   */
  private String sourceId;

  /**
   * 值类型
   */
  private String valueType;

  /**
   * LOV 代码
   */
  private String lovCode;

  /**
   * 结果值
   */
  private String valueData;

  /**
   * 多值列表
   */
  private List<String> valueList;
}
