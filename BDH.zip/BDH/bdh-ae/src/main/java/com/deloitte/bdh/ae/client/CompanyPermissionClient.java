package com.deloitte.bdh.ae.client;

import com.deloitte.bdh.ae.model.vo.CompanyDataPermissionVo;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.RetResult;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * @author Ashen
 * @date 04/02/2021
 */
@FeignClient(value = "bdh-platform", contextId = "company-permission-client")
@Component
public interface CompanyPermissionClient {

  @PostMapping("/platform/commonDatas/userApprovalDataPermissions")
  RetResult<List<CompanyDataPermissionVo>> getUserDataPermissions(RetRequest<Void> retRequest);
}
