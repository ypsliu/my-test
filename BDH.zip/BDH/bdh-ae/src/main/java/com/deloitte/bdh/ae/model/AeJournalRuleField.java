package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "AeJournalRuleField对象", description = "")
public class AeJournalRuleField extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableId("RULE_FIELD_ID")
  private String ruleFieldId;

  @TableField("RULE_ID")
  private String ruleId;

  @TableField("SEGMENT1")
  private String segment1;

  @TableField("SEGMENT2")
  private String segment2;

  @TableField("SEGMENT3")
  private String segment3;

  @TableField("SEGMENT4")
  private String segment4;

  @TableField("SEGMENT5")
  private String segment5;

  @TableField("SEGMENT6")
  private String segment6;

  @TableField("SEGMENT7")
  private String segment7;

  @TableField("SEGMENT8")
  private String segment8;

  @TableField("SEGMENT9")
  private String segment9;

  @TableField("SEGMENT10")
  private String segment10;

  @TableField("SEGMENT11")
  private String segment11;

  @TableField("SEGMENT12")
  private String segment12;

  @TableField("SEGMENT13")
  private String segment13;

  @TableField("SEGMENT14")
  private String segment14;

  @TableField("SEGMENT15")
  private String segment15;

  @TableField("DESCRIPTION1")
  private String description1;

  @TableField("DESCRIPTION2")
  private String description2;

  @TableField("DESCRIPTION3")
  private String description3;

  @TableField("DESCRIPTION4")
  private String description4;

  @TableField("DESCRIPTION5")
  private String description5;

  @TableField("DESCRIPTION6")
  private String description6;

  @TableField("DESCRIPTION7")
  private String description7;

  @TableField("DESCRIPTION8")
  private String description8;

  @TableField("DESCRIPTION9")
  private String description9;

  @TableField("DESCRIPTION10")
  private String description10;

  @TableField("DESCRIPTION11")
  private String description11;

  @TableField("DESCRIPTION12")
  private String description12;

  @TableField("DESCRIPTION13")
  private String description13;

  @TableField("DESCRIPTION14")
  private String description14;

  @TableField("DESCRIPTION15")
  private String description15;

  @TableField("ACTIVE_FLAG")
  private Integer activeFlag;

  @TableField("DESCRIPTION")
  private String description;


}
