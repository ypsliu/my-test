package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "SourceExpenseReceivableLine对象", description = "")
public class SourceExpenseReceivableLine extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableField("RECEIVABLE_APPL_LINE_ID")
  private String receivableApplLineId;

  @TableField("LINE_NUM")
  private BigDecimal lineNum;

  @TableField("LOAN_REQ_HEADER_ID")
  private String loanReqHeaderId;

  @TableField("SOURCE_TYPE")
  private String sourceType;

  @TableField("SOURCE_ID")
  private String sourceId;

  @TableField("CURRENCY_CODE")
  private String currencyCode;

  @TableField("APPL_AMOUNT")
  private BigDecimal applAmount;

  @TableField("TENANT_ID")
  private String tenantId;

  @TableField("ACTIVE_FLAG")
  private BigDecimal activeFlag;

  @TableField("AE_ROW_ID")
  private String aeRowId;

  @TableField("AE_STATUS")
  private String aeStatus;

  @TableField("SOURCE_BATCH_ID")
  private String sourceBatchId;

  @TableField("SOURCE_HEAD_ID")
  private String sourceHeadId;

  @TableField("SOURCE_LINE_ID")
  private String sourceLineId;

  @TableField("LOAN_DOCUMENT_NUMBER")
  private String loanDocumentNumber;


}
