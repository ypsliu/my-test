package com.deloitte.bdh.ae.client;

import com.deloitte.bdh.ae.client.dto.BaseEnumValueDto;
import com.deloitte.bdh.ae.model.vo.EnumValueVo;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.RetResult;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * @author Ashen
 * @date 12/11/2020
 */
@FeignClient(value = "bdh-platform", contextId = "enum-value-client")
@Component
public interface EnumValueClient {

  @PostMapping("/platform/basePortalEnumValue/getPortalEnumValueList")
  RetResult<List<EnumValueVo>> getPortalEnumValueList(RetRequest<BaseEnumValueDto> retRequest);


  @PostMapping("/platform/admPortalEnumValues/systemValues")
  RetResult<List<EnumValueVo>> getSystemEnumValueList(RetRequest<BaseEnumValueDto> retRequest);

}
