package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "SourceArInvoiceHead对象", description = "")
public class SourceArInvoiceHead extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableField("REQUEST_HEADER_ID")
  private String requestHeaderId;

  @TableField("DOCUMENT_NUMBER")
  private String documentNumber;

  @TableField("TENANT_ID")
  private String tenantId;

  @TableField("ORGANIZATION_ID")
  private String organizationId;

  @TableField("ORGANIZATION_DEPT_ID")
  private String organizationDeptId;

  @TableField("PREPARED_USER")
  private BigDecimal preparedUser;

  @TableField("REQUEST_USER_ID")
  private String requestUserId;

  @TableField("REQUEST_DATE")
  private LocalDate requestDate;

  @TableField("REQUEST_PURPOSES")
  private String requestPurposes;

  @TableField("ATTACHMENT_NUMBER")
  private BigDecimal attachmentNumber;

  @TableField("WF_ITEM_TYPE")
  private String wfItemType;

  @TableField("STATUS_CODE")
  private String statusCode;

  @TableField("ACTIVE_FLAG")
  private BigDecimal activeFlag;

  @TableField("COMMENTS")
  private String comments;

  @TableField("PROCESS_MESSAGE")
  private String processMessage;

  @TableField("CUSTOMER_ID")
  private String customerId;

  @TableField("CUSTOMER_SITE_ID")
  private String customerSiteId;

  @TableField("BANK_BRANCH_ID")
  private String bankBranchId;

  @TableField("BANK_ACCOUNT_NUMBER")
  private String bankAccountNumber;

  @TableField("TAX_REG_NUMBER")
  private String taxRegNumber;

  @TableField("CUSTOMER_ADDRESS")
  private String customerAddress;

  @TableField("CUSTOMER_PHONE_NUMBER")
  private BigDecimal customerPhoneNumber;

  @TableField("INVOICE_TYPE")
  private String invoiceType;

  @TableField("REQUEST_TYPE")
  private String requestType;

  @TableField("INVOICE_CLASS")
  private String invoiceClass;

  @TableField("INVOICE_STATUS")
  private String invoiceStatus;

  @TableField("FINANCE_STATUS")
  private BigDecimal financeStatus;

  @TableField("FINANCIAL_DATE")
  private LocalDate financialDate;

  @TableField("ACCOUNT_TYPE")
  private String accountType;

  @TableField("ACCOUNT_STATUS")
  private BigDecimal accountStatus;

  @TableField("ACCOUNT_DATE")
  private LocalDate accountDate;

  @TableField("PRE_SUBMIT")
  private BigDecimal preSubmit;

  @TableField("RATE_TYPE")
  private String rateType;

  @TableField("RATE_DATE")
  private LocalDate rateDate;

  @TableField("RATE")
  private BigDecimal rate;

  @TableField("STARD_CURRENCY")
  private String stardCurrency;

  @TableField("STARD_TAX_IN_AMOUNT")
  private BigDecimal stardTaxInAmount;

  @TableField("STARD_TAX_FREE_AMOUNT")
  private BigDecimal stardTaxFreeAmount;

  @TableField("STARD_TAX_AMOUNT")
  private BigDecimal stardTaxAmount;

  @TableField("ORIGL_CURRENCY")
  private String origlCurrency;

  @TableField("ORIGL_TAX_IN_AMOUNT")
  private BigDecimal origlTaxInAmount;

  @TableField("ORIGL_TAX_FREE_AMOUNT")
  private BigDecimal origlTaxFreeAmount;

  @TableField("ORIGL_TAX_AMOUNT")
  private BigDecimal origlTaxAmount;

  @TableField("ORGANIZATION_NAME")
  private String organizationName;

  @TableField("CUSTOMER_NAME")
  private String customerName;

  @TableField("AE_ROW_ID")
  private String aeRowId;

  @TableField("AE_STATUS")
  private String aeStatus;

  @TableField("SOURCE_BATCH_ID")
  private String sourceBatchId;

  @TableField("SOURCE_HEAD_ID")
  private String sourceHeadId;


}
