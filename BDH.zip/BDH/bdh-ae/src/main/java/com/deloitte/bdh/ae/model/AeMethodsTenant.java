package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "AeMethodsTenant对象", description = "")
public class AeMethodsTenant extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableId("METHOD_TENANT_ID")
  private String methodTenantId;

  @TableField("METHOD_ID")
  private String methodId;

  @TableField("TENANT_ID")
  private String tenantId;

  @TableField("DESCRIPTION")
  private String description;

  @TableField("ACTIVE_FLAG")
  private Integer activeFlag;


}
