package com.deloitte.bdh.ae.controller;

import com.deloitte.bdh.ae.model.io.DataOutput;
import com.deloitte.bdh.ae.model.io.OneDataInput;
import com.deloitte.bdh.ae.service.SourceExpenseHeadService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Ashen
 * @date 19/06/2020
 */
@RestController
@Api(tags = "数据同步:公共接口")
@RequestMapping("/aeData")
public class AeDataController {

  @Autowired
  private SourceExpenseHeadService sourceExpenseHeadService;

  /**
   * @Description: 接口数据
   * @Reutrn
   */
  @PostMapping("revertData")
  @ApiOperation(value = "数据撤销接口")
  public DataOutput revertData(
      @RequestBody OneDataInput oneDataInput) {
    try {
      DataOutput dataOutput = sourceExpenseHeadService.revertData(oneDataInput);
      return dataOutput;
    } catch (Exception e) {
      e.printStackTrace();
      DataOutput dataOutput = new DataOutput();
      dataOutput.setStatus("FAIL");
      dataOutput.setMessage("撤销数据失败：" + e.getMessage());
      return dataOutput;
    }
  }
}
