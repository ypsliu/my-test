package com.deloitte.bdh.ae.dao.ae;

import com.deloitte.bdh.ae.model.AeMethodsTenant;
import com.deloitte.bdh.common.base.Mapper;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface AeMethodsTenantMapper extends Mapper<AeMethodsTenant> {

}
