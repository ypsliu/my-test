package com.deloitte.bdh.engine.config.entity;

import java.util.List;
import lombok.Data;

/**
 * 日记账
 *
 * @author Ashen
 * @date 02/12/2019
 */
@Data
public class Journal {

  /**
   * 事件类型ID
   */
  private String eventTypeId;

  /**
   * 日记账行分配行ID
   */
  private String journalLineId;

  /**
   * 日记账行类型ID
   */
  private String journalTypeId;

  /**
   * 日记账说明ID
   */
  private String explainId;
  /**
   * 日记账类型
   */
  private JournalType journalType;

  /**
   * 日记账说明
   */
  private JournalExplain journalExplain;

  /**
   * 日记账推导规则
   */
  private List<JournalAndRule> journalAndRuleList;

}
