package com.deloitte.bdh.ae.model;

import java.math.BigDecimal;
import com.deloitte.bdh.common.base.BaseModel;
import java.time.LocalDate;
import com.baomidou.mybatisplus.annotation.TableField;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 员工费用报销申请头
 * </p>
 *
 * @author Ashen
 * @since 2021-03-24
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "SourceImportExpenseHead对象", description = " 员工费用报销申请头")
public class SourceImportExpenseHead extends BaseModel {

  private static final long serialVersionUID = 1L;

  @ApiModelProperty(value = "单据编号")
  @TableField("DOCUMENT_NUMBER")
  private String documentNumber;

  @ApiModelProperty(value = "公司ID")
  @TableField("ORGANIZATION_ID")
  private String organizationId;

  @ApiModelProperty(value = "公司编码")
  @TableField("ORGANIZATION_NUMBER")
  private String organizationNumber;

  @ApiModelProperty(value = "公司名称")
  @TableField("ORGANIZATION_NAME")
  private String organizationName;

  @ApiModelProperty(value = "申请人名称")
  @TableField("REQUEST_USER_NAME")
  private String requestUserName;

  @ApiModelProperty(value = "申请日期")
  @TableField("REQUEST_DATE")
  private LocalDate requestDate;

  @ApiModelProperty(value = "报销类型名称")
  @TableField("EXPENSE_REQ_TYPE_NAME")
  private String expenseReqTypeName;

  @ApiModelProperty(value = "报销说明")
  @TableField("EXPENSE_COMMENTS")
  private String expenseComments;

  @ApiModelProperty(value = "报销总金额（本位币）")
  @TableField("TOTAL_AMOUNT")
  private BigDecimal totalAmount;

  @ApiModelProperty(value = "入账日期")
  @TableField("GL_DATE")
  private LocalDate glDate;

  @ApiModelProperty(value = "系统字段：ID")
  @TableField("AE_ROW_ID")
  private String aeRowId;

  @ApiModelProperty(value = "系统字段：会计引擎中的状态")
  @TableField("AE_STATUS")
  private String aeStatus;

  @ApiModelProperty(value = "系统字段：来源产品批次ID")
  @TableField("SOURCE_BATCH_ID")
  private String sourceBatchId;

  @ApiModelProperty(value = "系统字段：来源产品头ID")
  @TableField("SOURCE_HEAD_ID")
  private String sourceHeadId;


}
