package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "SourceArInvoiceLine对象", description = "")
public class SourceArInvoiceLine extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableField("LINE_ID")
  private String lineId;

  @TableField("REQUEST_HEADER_ID")
  private String requestHeaderId;

  @TableField("LINE_NUMBER")
  private BigDecimal lineNumber;

  @TableField("LINE_TYPE")
  private String lineType;

  @TableField("PRODUCT_DESC")
  private String productDesc;

  @TableField("SPEC_MODEL")
  private String specModel;

  @TableField("CONTRACT_ID")
  private String contractId;

  @TableField("CONTRACT_LINE_ID")
  private String contractLineId;

  @TableField("OUT_HEADER_ID")
  private String outHeaderId;

  @TableField("OUT_LINE_ID")
  private String outLineId;

  @TableField("UNIT_PRICE")
  private BigDecimal unitPrice;

  @TableField("RELATED_QUANTITY")
  private BigDecimal relatedQuantity;

  @TableField("INVOICE_QUANTITY")
  private BigDecimal invoiceQuantity;

  @TableField("TAX_CODE")
  private String taxCode;

  @TableField("STARD_TAX_IN_AMOUNT")
  private BigDecimal stardTaxInAmount;

  @TableField("STARD_TAX_FREE_AMOUNT")
  private BigDecimal stardTaxFreeAmount;

  @TableField("STARD_TAX_AMOUNT")
  private BigDecimal stardTaxAmount;

  @TableField("ORIGL_TAX_IN_AMOUNT")
  private BigDecimal origlTaxInAmount;

  @TableField("ORIGL_TAX_FREE_AMOUNT")
  private BigDecimal origlTaxFreeAmount;

  @TableField("ORIGL_TAX_AMOUNT")
  private BigDecimal origlTaxAmount;

  @TableField("TAX_FREE_AMOUNT_BALANCE")
  private BigDecimal taxFreeAmountBalance;

  @TableField("TAX_AMOUNT_BALANCE")
  private BigDecimal taxAmountBalance;

  @TableField("AE_ROW_ID")
  private String aeRowId;

  @TableField("AE_STATUS")
  private String aeStatus;

  @TableField("SOURCE_BATCH_ID")
  private String sourceBatchId;

  @TableField("SOURCE_HEAD_ID")
  private String sourceHeadId;

  @TableField("SOURCE_LINE_ID")
  private String sourceLineId;

  @TableField("EBS_ITEM_NUM")
  private String ebsItemNum;

  @TableField("CATEGORY_SEGMENT1")
  private String categorySegment1;

  @TableField("CATEGORY_SEGMENT2")
  private String categorySegment2;

  @TableField("CATEGORY_SEGMENT3")
  private String categorySegment3;

  @TableField("CATEGORY_SEGMENT1_NAME")
  private String categorySegment1Name;

  @TableField("CATEGORY_SEGMENT2_NAME")
  private String categorySegment2Name;

  @TableField("CATEGORY_SEGMENT3_NAME")
  private String categorySegment3Name;


}
