package com.deloitte.bdh.ae.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.deloitte.bdh.ae.client.FeignClientService;
import com.deloitte.bdh.ae.model.vo.EnumValueVo;
import com.deloitte.bdh.ae.service.EnumService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Ashen
 * @date 04/02/2021
 */
@Service
public class EnumServiceImpl implements EnumService {

  @Autowired
  private FeignClientService feignClientService;

  @Override
  public String getSystemEnumValueShow(String enumTypeCode, String enumValue) {
    Map<String, String> valueMap = getSystemEnumValueMap(enumTypeCode);
    return valueMap.get(enumValue);
  }

  @Override
  public Map<String, String> getSystemEnumValueMap(String enumTypeCode) {
    List<EnumValueVo> valueList = feignClientService.getSystemEnumValueList(enumTypeCode);
    if (CollectionUtil.isEmpty(valueList)) {
      return new HashMap<>();
    }
    Map<String, String> valueMap = valueList.stream().collect(
        Collectors.toMap(EnumValueVo::getValue, EnumValueVo::getMeaning));
    return valueMap;
  }
}
