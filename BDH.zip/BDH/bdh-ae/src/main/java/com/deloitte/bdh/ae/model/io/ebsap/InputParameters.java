package com.deloitte.bdh.ae.model.io.ebsap;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

/**
 * @author Ashen
 * @date 21/04/2020
 */
@Data
public class InputParameters {

  @JSONField(name = "P_INVOICES_TBL")
  private P_INVOICES_TBL P_INVOICES_TBL;

}
