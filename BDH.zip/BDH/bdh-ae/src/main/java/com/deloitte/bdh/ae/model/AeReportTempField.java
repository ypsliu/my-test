package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import javax.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "AeReportTempField对象", description = "")
public class AeReportTempField extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableId("FIELD_ID")
  private String fieldId;

  @TableField("REPORT_ID")
  private String reportId;

  @TableField("TARGET_ID")
  private String targetId;

  @TableField("FIELD_NAME")
  private String fieldName;

  @TableField("WIDTH")
  private BigDecimal width;

  @TableField("PRIORITY_LEVEL")
  private BigDecimal priorityLevel;

  @TableField("ACTIVE_FLAG")
  private Integer activeFlag;

  @TableField(exist = false)
  @NotNull(message = "字段代码")
  private String displayCode;

  @TableField(exist = false)
  @NotNull(message = "字段说明")
  private String displayName;

  @TableField(exist = false)
  @NotNull(message = "字段类型")
  private String targetDataType;

  @TableField(exist = false)
  @NotNull(message = "固定字段")
  private Boolean flexFlag = false;


}
