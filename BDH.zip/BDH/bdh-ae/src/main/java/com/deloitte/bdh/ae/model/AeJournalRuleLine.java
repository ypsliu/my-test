package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "AeJournalRuleLine对象", description = "")
public class AeJournalRuleLine extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableId("RULE_LINE_ID")
  private String ruleLineId;

  @TableField("RULE_ID")
  private String ruleId;

  @TableField("TYPE")
  private String type;

  @TableField("SOURCE_ID")
  private String sourceId;

  @TableField("SET_ID")
  private String setId;

  @TableField("CONSTANT")
  private String constant;

  @TableField("ACTIVE_FLAG")
  private Integer activeFlag;

  @TableField("DESCRIPTION")
  private String description;

  @TableField("PRIORITY_LEVEL")
  private BigDecimal priorityLevel;


}
