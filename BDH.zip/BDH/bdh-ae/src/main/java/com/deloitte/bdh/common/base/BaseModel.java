package com.deloitte.bdh.common.base;

import com.alibaba.fastjson.annotation.JSONField;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.Data;

/**
 * 基础信息字段
 *
 * @author jinqwang
 */
@Data
public class BaseModel implements Serializable {

  /**
   * 创建人
   */
  @ApiModelProperty(value = "创建人")
  @TableField(value = "CREATE_USER", fill = FieldFill.INSERT)
  protected String createUser;

  /**
   * 创建时间
   */
  @JSONField(format = "yyyy/MM/dd HH:mm:ss")
  @ApiModelProperty(value = "创建时间")
  @TableField(value = "CREATE_DATE", fill = FieldFill.INSERT)
  protected LocalDateTime createDate;

  /**
   * 修改人
   */
  @ApiModelProperty(value = "修改人")
  @TableField(value = "MODIFIED_USER", fill = FieldFill.INSERT_UPDATE)
  protected String modifiedUser;

  /**
   * 修改时间
   */
  @JSONField(format = "yyyy/MM/dd HH:mm:ss")
  @ApiModelProperty(value = "修改时间")
  @TableField(value = "MODIFIED_DATE", fill = FieldFill.INSERT_UPDATE)
  protected LocalDateTime modifiedDate;

  /**
   * 请求IP
   */
  @ApiModelProperty(value = "请求IP")
  @TableField(value = "IP", fill = FieldFill.INSERT_UPDATE)
  @JsonIgnore
  protected String ip;


}
