package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@Accessors(chain = true)
@ApiModel(value = "SourcePsSalaryLine对象", description = "")
public class SourcePsSalaryLine {

  private static final long serialVersionUID = 1L;

  @TableField("AE_ROW_ID")
  private String aeRowId;

  @TableField("AE_STATUS")
  private String aeStatus;

  @TableField("SOURCE_BATCH_ID")
  private String sourceBatchId;

  @TableField("SOURCE_HEAD_ID")
  private String sourceHeadId;

  @TableField("SOURCE_LINE_ID")
  private String sourceLineId;

  @TableField("CURRENCY_CD")
  private String currencyCd;

  @TableField("CAL_PRD_ID")
  private String calPrdId;

  @TableField("COMPANY")
  private String company;

  @TableField("COMPANY_DESCR")
  private String companyDescr;

  @TableField("C_COST_CENTER")
  private String cCostCenter;

  @TableField("C_COST_CENTER_DESC")
  private String cCostCenterDesc;

  @TableField("PIN_NM")
  private String pinNm;

  @TableField("C_PIN_DESCR")
  private String cPinDescr;

  @TableField("CALC_RSLT_VAL")
  private BigDecimal calcRsltVal;

  @TableField("VERSION")
  private String version;

  @TableField("CREATEDTTM")
  private LocalDate createdttm;

  @TableField("LASTUPDDTTM")
  private LocalDate lastupddttm;

  @TableField("PYMT_DT")
  private LocalDate pymtDt;


}
