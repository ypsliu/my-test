package com.deloitte.bdh.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.deloitte.bdh.entity.AeEventType;

/**
 * 应用产品事件类型(AeEventType)表数据库访问层
 *
 * @author makejava
 * @since 2022-06-07 11:11:55
 */
public interface AeEventTypeDao extends BaseMapper<AeEventType> {

}

