package com.deloitte.bdh.ae.service;


/**
 * @author Ashen
 * @date 09/03/2020
 */
public interface AeDataToEbsService {


  /**
   * 调用接口数据同步到EBS表
   *
   * @param aeBatchId
   * @param applicationCode
   */
  void putDataToEbs(String aeBatchId, String applicationCode);

  /**
   * 调用接口同步EBS数据到会计引擎
   *
   * @param aeBatchId
   * @param applicationCode
   */
  void getDataFromEbs(String aeBatchId, String applicationCode);
}
