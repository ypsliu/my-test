package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.deloitte.bdh.ae.dao.ae.TargetApPaymentInterfaceMapper;
import com.deloitte.bdh.ae.model.TargetApPaymentInterface;
import com.deloitte.bdh.ae.model.TargetSourceBasicInfo;
import com.deloitte.bdh.ae.model.io.ebsappayment.P_PAYMENTS_TBL_ITEM;
import com.deloitte.bdh.ae.service.TargetApPaymentInterfaceService;
import com.deloitte.bdh.common.base.ServiceTransactionalImpl;
import com.deloitte.bdh.common.constant.DSConstant;
import java.util.List;
import java.util.Set;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Service
@DS(DSConstant.AE_DB)
public class TargetApPaymentInterfaceServiceImpl extends
    ServiceTransactionalImpl<TargetApPaymentInterfaceMapper, TargetApPaymentInterface> implements
    TargetApPaymentInterfaceService {

  @Override
  public List<P_PAYMENTS_TBL_ITEM> queryPaymentsItem(String aeBatchId) {
    return baseMapper.queryPaymentsItem(aeBatchId);
  }

  @Override
  public List<TargetSourceBasicInfo> selectByLineNumberSet(Set<String> apGrpNumSet,
      String aeBatchId) {
    return baseMapper.selectByLineNumberSet(apGrpNumSet, aeBatchId);
  }
}
