package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.deloitte.bdh.ae.dao.ae.SourceApInvoiceWoLineMapper;
import com.deloitte.bdh.ae.model.SourceApInvoiceWoLine;
import com.deloitte.bdh.ae.service.SourceApInvoiceWoLineService;
import com.deloitte.bdh.common.base.ServiceTransactionalImpl;
import com.deloitte.bdh.common.constant.DSConstant;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Service
@DS(DSConstant.AE_DB)
public class SourceApInvoiceWoLineServiceImpl extends
    ServiceTransactionalImpl<SourceApInvoiceWoLineMapper, SourceApInvoiceWoLine> implements
    SourceApInvoiceWoLineService {

}
