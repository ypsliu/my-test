package com.deloitte.bdh.ae.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.deloitte.bdh.ae.client.FeignClientService;
import com.deloitte.bdh.ae.dao.ae.AeSourceBatchMapper;
import com.deloitte.bdh.ae.model.AeApplication;
import com.deloitte.bdh.ae.model.AeSourceBatch;
import com.deloitte.bdh.ae.model.AeSourceLoadTable;
import com.deloitte.bdh.ae.model.dto.ApplicationDto;
import com.deloitte.bdh.ae.model.dto.BatchDto;
import com.deloitte.bdh.ae.model.dto.BatchListGenerateDto;
import com.deloitte.bdh.ae.model.dto.BatchQueryDto;
import com.deloitte.bdh.ae.model.vo.CompanyDataPermissionVo;
import com.deloitte.bdh.ae.model.vo.UserVo;
import com.deloitte.bdh.ae.properties.ApplicationCodeProperties;
import com.deloitte.bdh.ae.service.AeApplicationService;
import com.deloitte.bdh.ae.service.AeDataService;
import com.deloitte.bdh.ae.service.AeSourceBatchService;
import com.deloitte.bdh.ae.service.AeSourceLoadTableService;
import com.deloitte.bdh.ae.service.EnumService;
import com.deloitte.bdh.ae.service.LocaleMessageSourceService;
import com.deloitte.bdh.common.base.PageRequest;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.ServiceTransactionalImpl;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.common.context.ThreadContextHolder;
import com.deloitte.bdh.common.exception.BizException;
import com.deloitte.bdh.common.util.DateUtils;
import com.github.pagehelper.PageHelper;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import javax.annotation.Resource;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Service
@DS(DSConstant.AE_DB)
public class AeSourceBatchServiceImpl extends
    ServiceTransactionalImpl<AeSourceBatchMapper, AeSourceBatch> implements AeSourceBatchService {

  @Resource
  private AeSourceBatchMapper aeSourceBatchMapper;

  @Autowired
  private LocaleMessageSourceService localeMessageSourceService;

  @Autowired
  private AeApplicationService aeApplicationService;

  @Autowired
  private FeignClientService feignClientService;

  @Autowired
  private EnumService EnumService;

  @Autowired
  private ApplicationCodeProperties applicationCodeProperties;

  @Autowired
  private AeSourceLoadTableService aeSourceLoadTableService;

  @Autowired
  private AeDataService aeDataService;

  @Override
  @Transactional(rollbackFor = Exception.class)
  public void generateData(RetRequest<BatchListGenerateDto> batchDtoRetRequest) {
    BatchListGenerateDto batchListGenerateDto = batchDtoRetRequest.getData();
    if (batchListGenerateDto == null || batchListGenerateDto.getBatchList() == null
        || batchListGenerateDto.getBatchList().size() == 0) {
      throw new BizException("没有选中任何批次信息！");
    }
    if ("DRAFT_ACCOUNT".equalsIgnoreCase(batchListGenerateDto.getEntryType()) || "FINAL_ACCOUNT"
        .equalsIgnoreCase(batchListGenerateDto.getEntryType())) {
      // 拟定入账
      batchListGenerateDto.getBatchList().forEach(batchDto -> {
        AeSourceBatch dbBatch = aeSourceBatchMapper.selectById(batchDto.getAeBatchId());
        if ("TO_DO".equalsIgnoreCase(dbBatch.getAeStatus()) || "DOING"
            .equalsIgnoreCase(dbBatch.getAeStatus())) {
          // 如果批次在正在创建或创建中状态，不能再次提交创建数据
          throw new BizException(
              "批号：" + dbBatch.getAeBatchCode() + "的状态为：" + localeMessageSourceService
                  .getMessage("ae.batch.aeStatus." + dbBatch.getAeStatus(),
                      batchDtoRetRequest.getLang()) + "，不能被再次提交！");
        }

        if (("OK".equals(dbBatch.getEbsStatus()) || "DOING".equals(dbBatch.getEbsStatus())
            || "DOING_OK".equals(dbBatch.getEbsStatus()) || "DOING_DATA"
            .equals(dbBatch.getEbsStatus()))
            && "FINAL_ACCOUNT".equalsIgnoreCase(dbBatch.getEntryType())) {
          throw new BizException(
              "最终入账批号：" + dbBatch.getAeBatchCode() + "已经同步成功或正在同步中数据,不能被再次提交！");
        }
        dbBatch.setAeStatus("TO_DO");
        dbBatch.setEbsStatus("");
        dbBatch.setEntryUserId(batchDtoRetRequest.getOperator());
        dbBatch.setEntryDate(LocalDate.now());
        dbBatch.setEntryType(batchListGenerateDto.getEntryType());
        dbBatch.setAccountingDate(batchListGenerateDto.getAccountingDate());
        aeSourceBatchMapper.update(dbBatch, new LambdaUpdateWrapper<AeSourceBatch>()
            .set(!ObjectUtils.isEmpty(batchListGenerateDto.getAccountingDate()),
                AeSourceBatch::getAccountingDate, batchListGenerateDto.getAccountingDate())
            .eq(AeSourceBatch::getAeBatchId, batchDto.getAeBatchId()));
      });
    } else {
      throw new BizException("请选择创建会计科目的类型！");
    }
  }

  @Override
  public List<AeSourceBatch> selectByPageRequest(PageRequest<BatchQueryDto> pageRequest) {
    BatchQueryDto batchQueryDto = pageRequest.getData();

    List<CompanyDataPermissionVo> companyDataPermissionVoList = feignClientService
        .getUserDataPermissions();
    if (companyDataPermissionVoList.size() == 0) {
      throw new BizException("您当前没有授权公司信息，查询失败！");
    }
    Map<String, String> organizationMap = companyDataPermissionVoList.stream().collect(
        Collectors.toMap(CompanyDataPermissionVo::getOrganizationId,
            CompanyDataPermissionVo::getOrganizationName));

    //分页插件
    PageHelper.startPage(pageRequest.getPage(), pageRequest.getSize());
    List<AeSourceBatch> aeSourceBatchList = this.list(new LambdaQueryWrapper<AeSourceBatch>()
        .in(AeSourceBatch::getOrganizationId, organizationMap.keySet())
        .eq(AeSourceBatch::getApplicationCode, batchQueryDto.getApplicationCode())
        .like(Strings.isNotEmpty(batchQueryDto.getAeBatchCode()), AeSourceBatch::getAeBatchCode,
            batchQueryDto.getAeBatchCode())
        .eq(Strings.isNotEmpty(batchQueryDto.getEntryUserId()), AeSourceBatch::getEntryUserId,
            batchQueryDto.getEntryUserId())
        .ge(batchQueryDto.getCreateDateFrom() != null, AeSourceBatch::getCreateDate,
            batchQueryDto.getCreateDateFrom())
        .ge(batchQueryDto.getCreateDateTo() != null, AeSourceBatch::getCreateDate,
            batchQueryDto.getCreateDateTo() != null ?
                batchQueryDto.getCreateDateTo().plusDays(1)
                : null)
        .eq(Strings.isNotEmpty(batchQueryDto.getOrganizationId()), AeSourceBatch::getOrganizationId,
            batchQueryDto.getOrganizationId())
        .eq(Strings.isNotEmpty(batchQueryDto.getAeStatus()), AeSourceBatch::getAeStatus,
            batchQueryDto.getAeStatus())
        .eq(Strings.isNotEmpty(batchQueryDto.getEntryType()), AeSourceBatch::getEntryType,
            batchQueryDto.getEntryType())
        .ge(batchQueryDto.getEntryDateFrom() != null, AeSourceBatch::getEntryDate,
            batchQueryDto.getEntryDateFrom())
        .le(batchQueryDto.getEntryDateTo() != null, AeSourceBatch::getEntryDate,
            batchQueryDto.getEntryDateTo() != null ?
                batchQueryDto.getEntryDateTo().plusDays(1)
                : null)
        .orderByDesc(AeSourceBatch::getCreateDate));

    Set<String> userIdSet = aeSourceBatchList.stream().map(AeSourceBatch::getEntryUserId)
        .collect(Collectors.toSet());

    List<AeApplication> aeApplicationList = aeApplicationService
        .list(new LambdaQueryWrapper<AeApplication>()
            .eq(AeApplication::getApplicationCode, batchQueryDto.getApplicationCode()));
    if (aeApplicationList.size() != 1) {
      throw new BizException("查询应用产品失败");
    }

    Map<String, String> userNameMap = feignClientService.getUserNameMapByIdSet(userIdSet);
    aeSourceBatchList.forEach(aeSourceBatch -> {
      aeSourceBatch.setOrganizationName(organizationMap.get(aeSourceBatch.getOrganizationId()));
      aeSourceBatch.setEntryUserName(userNameMap.get(aeSourceBatch.getEntryUserId()));
      aeSourceBatch.setSourceShow(EnumService
          .getSystemEnumValueShow("AE_EVENT_SOURCE_TARGET", aeApplicationList.get(0).getSource()));
      aeSourceBatch.setAeStatusShow(localeMessageSourceService.getMessage(
          "ae.batch.aeStatus." + aeSourceBatch.getAeStatus(), pageRequest.getLang()));
      aeSourceBatch.setEntryTypeShow(localeMessageSourceService.getMessage(
          "ae.batch.entryType." + aeSourceBatch.getEntryType(), pageRequest.getLang()));
      aeSourceBatch.setEbsStatusShow(localeMessageSourceService.getMessage(
          "ae.batch.ebsStatus." + aeSourceBatch.getEbsStatus(), pageRequest.getLang()));
    });
    return aeSourceBatchList;
  }

  @Override
  public Boolean updateBatchStatus(String aeBatchId, String fromStatus, String toStatus) {
    return this.update(new LambdaUpdateWrapper<AeSourceBatch>()
        .set(AeSourceBatch::getAeStatus, toStatus)
        .eq(AeSourceBatch::getAeBatchId, aeBatchId)
        .eq(AeSourceBatch::getAeStatus, fromStatus));
  }

  @Override
  public List<UserVo> selectEntryUserList(RetRequest<ApplicationDto> retRequest) {
    List<UserVo> userList = new ArrayList<>();
    ApplicationDto dto = retRequest.getData();
    List<CompanyDataPermissionVo> companyDataPermissionVoList = feignClientService
        .getUserDataPermissions();
    List<String> organizationIdList = companyDataPermissionVoList.stream()
        .map(CompanyDataPermissionVo::getOrganizationId).collect(Collectors.toList());
    if (organizationIdList.size() == 0) {
      return userList;
    }
    Set<String> userIdSet = this.list(new LambdaQueryWrapper<AeSourceBatch>()
        .eq(AeSourceBatch::getApplicationCode, dto.getApplicationCode())
        .in(AeSourceBatch::getOrganizationId, organizationIdList))
        .stream().map(AeSourceBatch::getEntryUserId).collect(Collectors.toSet());
    if (CollectionUtil.isEmpty(userIdSet)) {
      return userList;
    }
    Map<String, String> userNameMap = feignClientService.getUserNameMapByIdSet(userIdSet);
    if (CollectionUtil.isNotEmpty(userNameMap)) {
      userNameMap.forEach((userId, userName) -> {
        UserVo userVo = new UserVo();
        userVo.setUserId(userId);
        userVo.setFullName(userName);
        userList.add(userVo);
      });
    }
    return userList;
  }

  @Override
  public Boolean updateBatchEbsStatus(String aeBatchId, String entryType, String fromStatus,
      String toStatus) {
    return this.update(new LambdaUpdateWrapper<AeSourceBatch>()
        .set(AeSourceBatch::getEbsStatus, toStatus)
        .eq(AeSourceBatch::getAeBatchId, aeBatchId)
        .eq(AeSourceBatch::getEbsStatus, fromStatus)
        .eq(AeSourceBatch::getEntryType, entryType));
  }

  @Override
  public String selectAeBatchCode() {
    String startValue = "0001";
    String aeBatchCodeLeft = DateUtils.formatShortDate(new Date())
        + ThreadContextHolder.getTenant().getTenantCode();
    PageHelper.startPage(1, 1);
    List<AeSourceBatch> aeSourceBatchList = this.list(new LambdaQueryWrapper<AeSourceBatch>()
        .likeRight(AeSourceBatch::getAeBatchCode, aeBatchCodeLeft)
        .orderByDesc(AeSourceBatch::getAeBatchCode));
    if (CollectionUtil.isNotEmpty(aeSourceBatchList)) {
      {
        String aeBatchCode = aeSourceBatchList.get(0).getAeBatchCode();
        String startCode = aeBatchCode.replace(aeBatchCodeLeft, "");
        startValue = String.valueOf(Long.valueOf(startCode) + 1L);
        while (startValue.length() < 4) {
          startValue = "0" + startValue;
        }
      }
    }
    return aeBatchCodeLeft + startValue;
  }

  @Override
  @Transactional(rollbackFor = Exception.class)
  public void deleteData(BatchDto dto) {
    AeSourceBatch aeSourceBatch = aeSourceBatchMapper.selectById(dto.getAeBatchId());
    if (aeSourceBatch == null) {
      return;
    }
    if (!applicationCodeProperties.getApplicationCodeImportExpense()
        .equals(aeSourceBatch.getApplicationCode())
        && !applicationCodeProperties.getApplicationCodeImportExpensePayment()
        .equals(aeSourceBatch.getApplicationCode())
    ) {
      throw new BizException("只有手工导入的数据才能删除！");
    }
    if (!(Strings.isEmpty(aeSourceBatch.getEbsStatus()) || "FAIL"
        .equals(aeSourceBatch.getEbsStatus()))) {
      throw new BizException("已经开始进行EBS同步，无法进行撤销操作！");
    }
    List<AeApplication> aeApplicationList = aeApplicationService
        .list(new LambdaQueryWrapper<AeApplication>()
            .eq(AeApplication::getApplicationCode, aeSourceBatch.getApplicationCode()));
    if (aeApplicationList.size() != 1) {
      throw new BizException("查询应用产品信息失败");
    }
    // 删除来源数据上该头信息的数据
    List<AeSourceLoadTable> tableList = aeSourceLoadTableService
        .list(new LambdaQueryWrapper<AeSourceLoadTable>()
            .eq(AeSourceLoadTable::getApplicationId,
                aeApplicationList.get(0).getApplicationId()));
    // 删除目标数据上该头信息的数据
    tableList.forEach(aeSourceLoadTable -> {
      if ("SOURCE".equalsIgnoreCase(aeSourceLoadTable.getDirection())) {
        deleteSourceData(aeSourceLoadTable.getTableName(), aeSourceBatch.getSourceBatchId());
      } else if ("TARGET".equalsIgnoreCase(aeSourceLoadTable.getDirection())) {
        deleteTargetData(aeSourceLoadTable.getTableName(), aeSourceBatch.getAeBatchId());
      } else {
        throw new BizException("表方向异常");
      }
    });
    this.removeById(aeSourceBatch.getAeBatchId());
  }

  /**
   * 删除来源数据
   *
   * @param tableName     表名
   * @param sourceBatchId 批次ID
   */
  private void deleteSourceData(String tableName, String sourceBatchId) {
    if (Strings.isEmpty(tableName)) {
      throw new BizException("表信息不能为空!");
    }
    if (Strings.isEmpty(sourceBatchId)) {
      throw new BizException("批次不能为空!");
    }
    StringBuffer sql = new StringBuffer();
    sql.append("DELETE FROM ").append(tableName);
    sql.append(" WHERE SOURCE_BATCH_ID = '").append(sourceBatchId).append("'");
    aeDataService.deleteData(sql.toString());
  }

  /**
   * 删除目标数据
   *
   * @param tableName 表名
   * @param aeBatchId 批次ID
   */
  private void deleteTargetData(String tableName, String aeBatchId) {
    if (Strings.isEmpty(tableName)) {
      throw new BizException("表信息不能为空!");
    }
    if (aeBatchId == null) {
      throw new BizException("批次不能为空!");
    }
    StringBuffer sql = new StringBuffer();
    sql.append("DELETE FROM ").append(tableName);
    sql.append(" WHERE AE_BATCH_ID = '").append(aeBatchId).append("'");
    aeDataService.deleteData(sql.toString());
  }
}