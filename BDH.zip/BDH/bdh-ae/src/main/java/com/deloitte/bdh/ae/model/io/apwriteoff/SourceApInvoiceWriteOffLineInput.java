package com.deloitte.bdh.ae.model.io.apwriteoff;

import com.deloitte.bdh.ae.model.SourceApInvoiceWoLine;

/**
 * @author Ashen
 * @date 20/04/2020
 */
public class SourceApInvoiceWriteOffLineInput extends SourceApInvoiceWoLine {

}
