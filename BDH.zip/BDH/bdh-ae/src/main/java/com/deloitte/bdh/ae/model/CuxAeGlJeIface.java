package com.deloitte.bdh.ae.model;

import lombok.Data;

/**
 * @author Ashen
 * @date 10/03/2020
 */
@Data
public class CuxAeGlJeIface {

  private String sourceBatchId;

  private String sourceHeadId;

  private String sourceLineId;

  private String aeRowId;

  private String aeBatchId;

  private String importStatusCode;

  private String importErrorMessage;

  private String importJeHeaderId;

  private String importJeLineNum;

  private String importDocSequenceValue;

}
