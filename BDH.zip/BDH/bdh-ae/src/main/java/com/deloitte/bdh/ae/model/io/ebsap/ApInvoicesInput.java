package com.deloitte.bdh.ae.model.io.ebsap;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

/**
 * @author Ashen
 * @date 21/04/2020
 */
@Data
public class ApInvoicesInput {

  @JSONField(name = "CREATE_INVOICES_Input")
  private CREATE_INVOICES_Input CREATE_INVOICES_Input;

}
