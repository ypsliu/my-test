package com.deloitte.bdh.ae.service;

/**
 * @author Ashen
 * @date 14/07/2020
 */
public interface EbsDataApWriteOffService {

  /**
   * 推送数据到EBS Ap核销
   *
   * @param aeBatchId
   */
  void putDataToEbsApWriteOff(String aeBatchId);
}
