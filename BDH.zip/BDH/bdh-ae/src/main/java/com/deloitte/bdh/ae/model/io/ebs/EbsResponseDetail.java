package com.deloitte.bdh.ae.model.io.ebs;

import lombok.Data;

/**
 * @author Ashen
 * @date 12/03/2020
 */
@Data
public class EbsResponseDetail {

  private String X_RETURN_STATUS;

  private String X_RETURN_MESSAGE;
}
