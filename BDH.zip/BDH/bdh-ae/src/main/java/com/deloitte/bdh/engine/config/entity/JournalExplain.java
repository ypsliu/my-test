package com.deloitte.bdh.engine.config.entity;

import java.util.List;
import lombok.Data;

/**
 * 日记账说明
 *
 * @author Ashen
 * @date 02/12/2019
 */
@Data
public class JournalExplain {

  private String explainId;

  private List<JournalExplainLine> journalExplainLineList;

}
