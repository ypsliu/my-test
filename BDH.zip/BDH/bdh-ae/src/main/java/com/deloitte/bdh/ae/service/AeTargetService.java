package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.AeTarget;
import com.deloitte.bdh.ae.model.dto.BatchDocumentDto;
import com.deloitte.bdh.ae.model.dto.BatchDto;
import com.deloitte.bdh.ae.model.dto.BatchListExportDto;
import com.deloitte.bdh.ae.model.vo.TargetAccountVo;
import com.deloitte.bdh.common.base.PageHeadResult;
import com.deloitte.bdh.common.base.PageRequest;
import com.deloitte.bdh.common.base.Service;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface AeTargetService extends Service<AeTarget> {

  /**
   * 根据批次信息查询账务信息
   */
  PageHeadResult<TargetAccountVo> queryAccountingByBatch(PageRequest<BatchDto> pageRequest);

  /**
   * 根据单据信息查询账务信息
   */
  PageHeadResult<TargetAccountVo> queryAccountingByDocument(
      PageRequest<BatchDocumentDto> pageRequest);

  /**
   * 导出
   *
   * @param batchListExportDto
   * @return
   */
  PageHeadResult<TargetAccountVo> exportData(BatchListExportDto batchListExportDto);
}
