package com.deloitte.bdh.ae.dao.ae;

import com.deloitte.bdh.ae.model.AeApplication;
import com.deloitte.bdh.common.base.Mapper;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface AeApplicationMapper extends Mapper<AeApplication> {

  /**
   * 根据租户和应用产品查询信息
   *
   * @param tenantId
   * @param applicationCode
   * @return
   */
  Integer selectTenantAndApplicationCode(@Param("tenantId") String tenantId,
      @Param("applicationCode") String applicationCode);

  List<AeApplication> selectByTenantId(@Param("tenantId") String tenantId);
}
