package com.deloitte.bdh.common.base;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import lombok.Data;

/**
 * @author dahpeng
 * @date 2018/11/19
 */
@ApiModel(description = "接口请求基类")
@Data
public class RetRequest<T> implements Serializable {

  private static final long serialVersionUID = 5162177108958838841L;
  @ApiModelProperty(value = "请求标识号")
  private String sid;

  @ApiModelProperty(value = "当前操作用户ID", example = "1")
  @NotEmpty(message = "当前操作用户ID不能为空")
  private String operator;

  @ApiModelProperty(value = "国际化语言标识", example = "cn")
  @NotEmpty(message = "国际化语言标识不能为空")
  private String lang;

  @ApiModelProperty(value = "来源平台", allowableValues = "PC, IOS, Android", example = "PC")
  private String source;

  @ApiModelProperty(value = "来源平台版本号,PC 从 1.0开始, IOS, Android 传当前版本号", example = "1.0")
  private String version;

  @ApiModelProperty(value = "请求对象数据")
  @Valid
  private T data;

}