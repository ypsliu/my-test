package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.deloitte.bdh.ae.dao.platform.CuxGlCoaListMapper;
import com.deloitte.bdh.ae.model.CuxGlCoaList;
import com.deloitte.bdh.ae.service.CuxGlCoaListService;
import com.deloitte.bdh.common.base.ServiceNoTransactionalImpl;
import com.deloitte.bdh.common.constant.DSConstant;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Service
@DS(DSConstant.PLATFORM_DB)
public class CuxGlCoaListServiceImpl extends
    ServiceNoTransactionalImpl<CuxGlCoaListMapper, CuxGlCoaList> implements CuxGlCoaListService {

  @Override
  public List<CuxGlCoaList> selectList(String ledgerId, List<CuxGlCoaList> coaValueList) {
    return baseMapper.selectListByCoaValue(ledgerId, coaValueList);
  }
}
