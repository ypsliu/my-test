package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "AeJournalType对象", description = "")
public class AeJournalType extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableId("JOURNAL_TYPE_ID")
  private String journalTypeId;

  @TableField("APPLICATION_ID")
  private String applicationId;

  @TableField("EVENT_TYPE_ID")
  private String eventTypeId;

  @TableField("SIDE_CODE")
  private String sideCode;

  @TableField("SWITCH_SIDE_FLAG")
  private Integer switchSideFlag;

  @TableField("MERGE_LINE")
  private String mergeLine;

  @TableField("ACTIVE_FLAG")
  private Integer activeFlag;

  @TableField("DESCRIPTION")
  private String description;

  @TableField("TYPE_CODE")
  private String typeCode;

  @TableField("TYPE_NAME")
  private String typeName;


}
