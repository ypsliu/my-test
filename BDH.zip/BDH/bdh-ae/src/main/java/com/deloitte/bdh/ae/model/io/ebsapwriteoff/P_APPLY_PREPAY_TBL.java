package com.deloitte.bdh.ae.model.io.ebsapwriteoff;

import com.alibaba.fastjson.annotation.JSONField;
import java.util.List;
import lombok.Data;

/**
 * @author Ashen
 * @date 14/07/2020
 */
@Data
public class P_APPLY_PREPAY_TBL {

  @JSONField(name = "P_APPLY_PREPAY_TBL_ITEM")
  private List<P_APPLY_PREPAY_TBL_ITEM> P_APPLY_PREPAY_TBL_ITEM;
}
