package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.deloitte.bdh.ae.dao.ae.AeTargetMapper;
import com.deloitte.bdh.ae.model.AeSourceBatch;
import com.deloitte.bdh.ae.model.AeTarget;
import com.deloitte.bdh.ae.model.dto.BatchDocumentDto;
import com.deloitte.bdh.ae.model.dto.BatchDto;
import com.deloitte.bdh.ae.model.dto.BatchListExportDto;
import com.deloitte.bdh.ae.model.vo.HeadProperty;
import com.deloitte.bdh.ae.model.vo.TargetAccountVo;
import com.deloitte.bdh.ae.properties.ApplicationCodeProperties;
import com.deloitte.bdh.ae.service.AeSourceBatchService;
import com.deloitte.bdh.ae.service.AeTargetService;
import com.deloitte.bdh.ae.service.LocaleMessageSourceService;
import com.deloitte.bdh.ae.service.TargetGlInterfaceService;
import com.deloitte.bdh.common.base.PageHeadResult;
import com.deloitte.bdh.common.base.PageRequest;
import com.deloitte.bdh.common.base.ServiceTransactionalImpl;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.common.context.ThreadContextHolder;
import com.deloitte.bdh.common.exception.BizException;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Service
@DS(DSConstant.AE_DB)
public class AeTargetServiceImpl extends
    ServiceTransactionalImpl<AeTargetMapper, AeTarget> implements
    AeTargetService {

  @Autowired
  ApplicationCodeProperties applicationCodeProperties;
  @Autowired
  private LocaleMessageSourceService localeMessageSourceService;
  @Resource
  private AeSourceBatchService aeSourceBatchService;
  @Resource
  private TargetGlInterfaceService targetGlInterfaceService;
//  @Resource
//  private PortalDataResourceMapper portalDataResourceMapper;


  @Override
  public PageHeadResult<TargetAccountVo> queryAccountingByBatch(PageRequest<BatchDto> pageRequest) {
    AeSourceBatch aeSourceBatch = aeSourceBatchService
        .getById(pageRequest.getData().getAeBatchId());
    if (aeSourceBatch == null) {
      throw new BizException("批次信息查询失败");
    }
    List<HeadProperty> headPropertyList = createHeadPropertyList(
        aeSourceBatch.getApplicationCode(), pageRequest.getLang());
    PageHelper.startPage(pageRequest.getPage(), pageRequest.getSize());
    List<TargetAccountVo> list = targetGlInterfaceService
        .queryAccountingByParam(aeSourceBatch.getSourceBatchId(), null,
            aeSourceBatch.getApplicationCode(), pageRequest.getLang());
    PageInfo<TargetAccountVo> pageInfo = new PageInfo<>(list);
    PageHeadResult pageHeadResult = new PageHeadResult(pageInfo, headPropertyList);
    return pageHeadResult;
  }

  @Override
  public PageHeadResult<TargetAccountVo> queryAccountingByDocument(
      PageRequest<BatchDocumentDto> pageRequest) {
    AeSourceBatch aeSourceBatch = aeSourceBatchService
        .getById(pageRequest.getData().getAeBatchId());
    if (aeSourceBatch == null) {
      throw new BizException("批次信息查询失败");
    }
//    暂时关闭权限认证
//    //权限验证
//    List<CompanyDataPermissionVo> companyDataPermissionVoList = portalDataResourceMapper
//        .selectCompanyDataPermission(pageRequest.getOperator(), pageRequest.getLang());
//    List<String> orgIdList = companyDataPermissionVoList.stream()
//        .map(CompanyDataPermissionVo::getOrganizationId).collect(Collectors.toList());
//    if (orgIdList.isEmpty() || !orgIdList.contains(aeSourceBatch.getOrganizationId())) {
//      throw new BizException(localeMessageSourceService
//          .getMessage("NO_DATA_PERMISSION", pageRequest.getLang()));
//    }

    List<HeadProperty> headPropertyList = createHeadPropertyList(
        aeSourceBatch.getApplicationCode(), pageRequest.getLang());
    PageHelper.startPage(pageRequest.getPage(), pageRequest.getSize());
    List<TargetAccountVo> list = targetGlInterfaceService
        .queryAccountingByParam(aeSourceBatch.getSourceBatchId(),
            pageRequest.getData().getSourceHeadId(),
            aeSourceBatch.getApplicationCode(), pageRequest.getLang());
    PageInfo<TargetAccountVo> pageInfo = new PageInfo<>(list);
    PageHeadResult pageHeadResult = new PageHeadResult(pageInfo, headPropertyList);
    return pageHeadResult;
  }

  @Override
  public PageHeadResult<TargetAccountVo> exportData(
      BatchListExportDto batchListExportDto) {
    if (CollectionUtils.isEmpty(batchListExportDto.getBatchIdList())) {
      throw new BizException("批次信息不能为空！");
    }
    List<AeSourceBatch> batchList = aeSourceBatchService
        .list(new LambdaQueryWrapper<AeSourceBatch>()
            .in(AeSourceBatch::getAeBatchId, batchListExportDto.getBatchIdList()));
    if (batchList.size() == 0) {
      throw new BizException("批次信息查询失败");
    }
    String applicationCode = null;
    for (int i = 0; i < batchList.size(); i++) {
      AeSourceBatch aeSourceBatch = batchList.get(i);
      if (applicationCode != null && !aeSourceBatch.getApplicationCode().equals(applicationCode)) {
        throw new BizException("多批次数据只能在一个应用产品下!");
      }
      applicationCode = aeSourceBatch.getApplicationCode();
    }
    List<HeadProperty> headPropertyList = createHeadPropertyList(
        applicationCode, ThreadContextHolder.getLang());
    List<TargetAccountVo> list = targetGlInterfaceService
        .exportAccountingByParam(batchListExportDto.getBatchIdList(), batchListExportDto.getType(),
            applicationCode, ThreadContextHolder.getLang());
    PageInfo<TargetAccountVo> pageInfo = new PageInfo<>(list);
    PageHeadResult pageHeadResult = new PageHeadResult(pageInfo, headPropertyList);
    return pageHeadResult;
  }

  private List<HeadProperty> createHeadPropertyList(String applicationCode, String lang) {
    List<HeadProperty> headPropertyList = null;
    if (applicationCode.equalsIgnoreCase(applicationCodeProperties.getApplicationCodeExpense()) ||
        applicationCode.equalsIgnoreCase(applicationCodeProperties.getApplicationCodePayment()) ||
        applicationCode.equalsIgnoreCase(applicationCodeProperties.getApplicationCodePsSalary()) ||
        applicationCode.equalsIgnoreCase(applicationCodeProperties.getApplicationCodeImportExpense()) ||
        applicationCode.equalsIgnoreCase(applicationCodeProperties.getApplicationCodeImportExpensePayment())) {
      headPropertyList = createGLHeadPropertyList(lang);
    } else if (applicationCode
        .equalsIgnoreCase(applicationCodeProperties.getApplicationCodeScmAp())) {
      headPropertyList = createGLHeadPropertyList(lang);
    } else {
      throw new BizException("未匹配到该应用的头信息");
    }
    return headPropertyList;
  }

  /**
   * 总账目标表的查询字段信息
   *
   * @param lang
   */
  private List<HeadProperty> createGLHeadPropertyList(String lang) {
    List<HeadProperty> headPropertyList = new ArrayList<>();
    headPropertyList.add(new HeadProperty("aeEbsNumber",
        localeMessageSourceService.getMessage("ae.account.title.aeEbsNumber", lang)));
    headPropertyList.add(new HeadProperty("aeHeadDescription",
        localeMessageSourceService.getMessage("ae.account.title.aeHeadDescription", lang)));
    headPropertyList.add(new HeadProperty("accountingDate",
        localeMessageSourceService.getMessage("ae.account.title.accountingDate", lang)));
    headPropertyList.add(new HeadProperty("currencyCode",
        localeMessageSourceService.getMessage("ae.account.title.currencyCode", lang)));
    headPropertyList.add(new HeadProperty("currencyConversionRate",
        localeMessageSourceService.getMessage("ae.account.title.currencyConversionRate", lang)));
    headPropertyList.add(new HeadProperty("aeLineNum",
        localeMessageSourceService.getMessage("ae.account.title.aeLineNum", lang)));
    headPropertyList.add(new HeadProperty("segment",
        localeMessageSourceService.getMessage("ae.account.title.segment", lang)));
    headPropertyList.add(new HeadProperty("segmentDescription",
        localeMessageSourceService.getMessage("ae.account.title.segmentDescription", lang)));
    headPropertyList.add(new HeadProperty("enteredDr",
        localeMessageSourceService.getMessage("ae.account.title.enteredDr", lang)));
    headPropertyList.add(new HeadProperty("enteredCr",
        localeMessageSourceService.getMessage("ae.account.title.enteredCr", lang)));
    headPropertyList.add(new HeadProperty("accountedDr",
        localeMessageSourceService.getMessage("ae.account.title.accountedDr", lang)));
    headPropertyList.add(new HeadProperty("accountedCr",
        localeMessageSourceService.getMessage("ae.account.title.accountedCr", lang)));
    headPropertyList.add(new HeadProperty("aeLineDescription",
        localeMessageSourceService.getMessage("ae.account.title.aeLineDescription", lang)));
    return headPropertyList;
  }

}
