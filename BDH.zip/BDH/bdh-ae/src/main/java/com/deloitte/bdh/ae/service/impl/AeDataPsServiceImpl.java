package com.deloitte.bdh.ae.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.deloitte.bdh.ae.client.FeignClientService;
import com.deloitte.bdh.ae.client.vo.BiDataCompanySystemVo;
import com.deloitte.bdh.ae.model.AeSourceBatch;
import com.deloitte.bdh.ae.model.SourcePsSalaryHead;
import com.deloitte.bdh.ae.model.SourcePsSalaryLine;
import com.deloitte.bdh.ae.model.dto.PsDto;
import com.deloitte.bdh.ae.properties.ApplicationCodeProperties;
import com.deloitte.bdh.ae.service.AeBatchSyncLogService;
import com.deloitte.bdh.ae.service.AeDataPsService;
import com.deloitte.bdh.ae.service.AeSourceBatchService;
import com.deloitte.bdh.ae.service.AeTenantMethodService;
import com.deloitte.bdh.ae.service.PsSalaryService;
import com.deloitte.bdh.ae.service.SourcePsSalaryHeadService;
import com.deloitte.bdh.ae.service.SourcePsSalaryLineService;
import com.deloitte.bdh.ae.service.TargetGlInterfaceService;
import com.deloitte.bdh.common.base.RetCode;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.RetResponse;
import com.deloitte.bdh.common.base.RetResult;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.common.context.ThreadContextHolder;
import com.deloitte.bdh.common.exception.BizException;
import com.deloitte.bdh.common.util.AssertUtils;
import com.deloitte.bdh.common.util.StringUtil;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import javax.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Ashen
 * @date 06/03/2020
 */
@Service
@DS(DSConstant.AE_DB)
@Transactional(rollbackFor = Exception.class)
public class AeDataPsServiceImpl implements AeDataPsService {

  @Autowired
  private SourcePsSalaryHeadService sourcePsSalaryHeadService;

  @Autowired
  private SourcePsSalaryLineService sourcePsSalaryLineService;

  @Autowired
  private PsSalaryService psSalaryService;

  @Autowired
  private AeSourceBatchService aeSourceBatchService;

  @Autowired
  private TargetGlInterfaceService targetGlInterfaceService;

  @Autowired
  private AeTenantMethodService aeTenantMethodService;

  @Autowired
  private AeBatchSyncLogService aeBatchSyncLogService;

  @Autowired
  private ApplicationCodeProperties applicationCodeProperties;

  @Autowired
  private FeignClientService feignClientService;

  @Override
  public RetResult<PsDto> putData(RetRequest<PsDto> retRequest) {
    PsDto dto = retRequest.getData();
    LocalDateTime startTime = LocalDateTime.now();
    PsDto resultVo = new PsDto();
    resultVo.setOverlayFlag("N");
    RetResult<PsDto> result = RetResponse.makeSuccessRsp(resultVo);
    try {
      AssertUtils.assertNotEmpty(dto.getOrganizationId(), "您没有选择公司信息！");
      aeTenantMethodService
          .verifyTenantApplication(ThreadContextHolder.getTenantId(),
              applicationCodeProperties.getApplicationCodePsSalary(),
              applicationCodeProperties.getApplicationCodePsSalary());
      List<BiDataCompanySystemVo> companySystemList = feignClientService
          .getSystemByCompanyId(dto.getOrganizationId());
      if (CollectionUtil.isNotEmpty(companySystemList)) {
        companySystemList = companySystemList.stream()
            .filter(biDataCompanySystemVo -> "PS".equals(biDataCompanySystemVo.getSystemType()))
            .collect(Collectors.toList());
      }
      if (CollectionUtil.isEmpty(companySystemList)) {
        throw new BizException("没有查询到您选择公司的PS映射公司信息！");
      }
      //PS系统中公司ID值
      String psCompanyId = companySystemList.get(0).getSystemCode();
      String period = retRequest.getData().getPeriod();

      //查询一条已经同步的最大版本数据信息
      SourcePsSalaryLine sourcePsSalaryLine = sourcePsSalaryLineService
          .selectOneDataMaxVersion(psCompanyId, period);
      //查询一条待同步的数据信息
      SourcePsSalaryLine salaryLineOfPs = psSalaryService
          .selectOneDataMaxVersionFromPs(psCompanyId, period);

      if (salaryLineOfPs == null) {
        throw new BizException(
            "未获取到PS系统中的该公司该期间的数据信息！");
      }
      String deleteBatchId = "";
      if (sourcePsSalaryLine != null) {
        //已经有该批次的数据
        AeSourceBatch aeSourceBatch = aeSourceBatchService
            .getById(sourcePsSalaryLine.getSourceBatchId());
        if (StringUtil.isNotEmpty(aeSourceBatch.getEbsStatus()) && !"FAIL"
            .equals(aeSourceBatch.getEbsStatus())) {
          throw new BizException(
              "当前选择的公司和期间数据在 同步EBS中或EBS同步成功,不允许再次同步!批次编号为：" + aeSourceBatch.getAeBatchCode());
        }

        if (salaryLineOfPs != null && salaryLineOfPs.getVersion()
            .equals(sourcePsSalaryLine.getVersion())) {
          throw new BizException(
              "当前选择的公司和期间数据已经有同步的最新数据,不允许再次同步!批次编号为：" + aeSourceBatch.getAeBatchCode());
        }

        if (!"Y".equals(retRequest.getData().getOverlayFlag())) {
          resultVo.setOverlayFlag("Y");
          throw new BizException(
              "当前选择的公司和期间数据已经同步到会计引擎模块，必须选择强制覆盖该批次的数据!批次编号为：" + aeSourceBatch.getAeBatchCode());
        } else {
          deleteBatchId = aeSourceBatch.getAeBatchId();
        }
      }
      AeSourceBatch aeSourceBatch = dealData(psCompanyId, period, dto.getOrganizationId(),
          ThreadContextHolder.getTenantId(), deleteBatchId, salaryLineOfPs.getVersion());
      aeBatchSyncLogService
          .insertSyncLog(aeSourceBatch.getAeBatchId(), retRequest.getOperator(), period,
              startTime, LocalDateTime.now(), "1", null);
    } catch (Exception e) {
      e.printStackTrace();
      return result.setCode(RetCode.FAIL).setMessage(e.getMessage());
    }
    result.setMessage("同步数据成功！");
    return result;
  }

  /**
   * 数据处理函数，如果异常将回滚
   *
   * @param psCompanyId
   * @param period
   * @param organizationId
   * @param tenantId
   * @param deleteBatchId
   * @param version
   */
  @Transactional(rollbackFor = Exception.class)
  @DS(DSConstant.AE_DB)
  public AeSourceBatch dealData(String psCompanyId, String period,
      @NotNull(message = "公司不能为空") String organizationId,
      String tenantId, String deleteBatchId, String version) {
    String aeBatchCode = aeSourceBatchService.selectAeBatchCode();
    if (StringUtil.isNotEmpty(deleteBatchId)) {
      //先删除原来的所有数据
      aeSourceBatchService.removeById(deleteBatchId);
      sourcePsSalaryHeadService.remove(new LambdaQueryWrapper<SourcePsSalaryHead>()
          .eq(SourcePsSalaryHead::getSourceBatchId, deleteBatchId));
      sourcePsSalaryLineService.remove(new LambdaQueryWrapper<SourcePsSalaryLine>()
          .eq(SourcePsSalaryLine::getSourceBatchId, deleteBatchId));
      targetGlInterfaceService.deleteTargetByBatchId(deleteBatchId);
    }

    String aeBatchId = aeSourceBatchService.getSequence();
    AeSourceBatch aeSourceBatch = new AeSourceBatch();
    aeSourceBatch.setAeBatchId(aeBatchId);
    aeSourceBatch.setSourceBatchId(aeBatchId);
    aeSourceBatch.setActiveFlag(1);
    aeSourceBatch.setApplicationCode(applicationCodeProperties.getApplicationCodePsSalary());
    aeSourceBatch.setTenantId(tenantId);
    aeSourceBatch.setOrganizationId(organizationId);
    aeSourceBatch.setAeBatchCode(aeBatchCode);
    aeSourceBatchService.save(aeSourceBatch);

    //插入头信息
    List<SourcePsSalaryHead> psHeadList = psSalaryService
        .selectHeadDataFromPs(psCompanyId, period, version);
    psHeadList.forEach(psSalaryHead -> {
      psSalaryHead.setSourceBatchId(aeBatchId);
      StringBuffer headId = new StringBuffer();
      headId.append(psSalaryHead.getCalPrdId()).append("#");
      headId.append(psSalaryHead.getCompany()).append("#");
      headId.append(psSalaryHead.getCCostCenter());
      psSalaryHead.setSourceHeadId(headId.toString());
      psSalaryHead.setOrganizationId(organizationId);
      sourcePsSalaryHeadService.save(psSalaryHead);
    });

    Long sourceLineId = 1L;
    //插入行信息
    List<SourcePsSalaryLine> psLineList = psSalaryService
        .selectLineDataFromPs(psCompanyId, period, version);
    for (SourcePsSalaryLine psSalaryLine : psLineList) {
      psSalaryLine.setSourceBatchId(aeBatchId);
      StringBuffer headId = new StringBuffer();
      headId.append(psSalaryLine.getCalPrdId()).append("#");
      headId.append(psSalaryLine.getCompany()).append("#");
      headId.append(psSalaryLine.getCCostCenter());
      psSalaryLine.setSourceHeadId(headId.toString());
      psSalaryLine.setSourceLineId(String.valueOf(sourceLineId++));
      sourcePsSalaryLineService.save(psSalaryLine);
    }
    return aeSourceBatch;
  }
}
