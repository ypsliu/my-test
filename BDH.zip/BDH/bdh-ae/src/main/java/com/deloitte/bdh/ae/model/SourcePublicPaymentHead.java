package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "SourcePublicPaymentHead对象", description = "")
public class SourcePublicPaymentHead extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableField("PAYMENT_ID_T1")
  private BigDecimal paymentIdT1;

  @TableField("SOURCE_ID_T1")
  private BigDecimal sourceIdT1;

  @TableField("SOURCE_TYPE_T1")
  private String sourceTypeT1;

  @TableField("PAYMENT_METHOD_T1")
  private String paymentMethodT1;

  @TableField("CASH_FLOW_SEGMENT_T1")
  private String cashFlowSegmentT1;

  @TableField("BANK_ACCOUNT_ID_T1")
  private BigDecimal bankAccountIdT1;

  @TableField("CURRENCY_CODE_T1")
  private String currencyCodeT1;

  @TableField("PAYMENT_AMOUNT_T1")
  private BigDecimal paymentAmountT1;

  @TableField("PAYMENT_DATE_T1")
  private LocalDate paymentDateT1;

  @TableField("CREATE_DATE_T1")
  private LocalDate createDateT1;

  @TableField("CREATE_USER_T1")
  private BigDecimal createUserT1;

  @TableField("MODIFIED_DATE_T1")
  private LocalDate modifiedDateT1;

  @TableField("MODIFIED_USER_T1")
  private BigDecimal modifiedUserT1;

  @TableField("IP_T1")
  private String ipT1;

  @TableField("TENANT_ID_T1")
  private String tenantIdT1;

  @TableField("ACTIVE_FLAG_T1")
  private BigDecimal activeFlagT1;

  @TableField("BATCH_ID_T1")
  private BigDecimal batchIdT1;

  @TableField("BATCH_NAME_T1")
  private String batchNameT1;

  @TableField("LEDGER_STATUS_T1")
  private BigDecimal ledgerStatusT1;

  @TableField("ACTION_TYPE_T1")
  private String actionTypeT1;

  @TableField("GL_DATE_T1")
  private LocalDate glDateT1;

  @TableField("PAYMENT_TOTAL_AMOUNT_T1")
  private BigDecimal paymentTotalAmountT1;

  @TableField("PAYMENT_STATUS_T1")
  private String paymentStatusT1;

  @TableField("PAY_SERIAL_NUM_T1")
  private String paySerialNumT1;

  @TableField("INSTRUCTION_ID_T1")
  private String instructionIdT1;

  @TableField("PAY_MESSAGE_T1")
  private String payMessageT1;

  @TableField("ACCEPTANCE_BILL_NO_T1")
  private String acceptanceBillNoT1;

  @TableField("BANK_INSTRUCTION_NUM_T1")
  private String bankInstructionNumT1;

  @TableField("REQUEST_HEADER_ID_T2")
  private BigDecimal requestHeaderIdT2;

  @TableField("DOCUMENT_NUMBER_T2")
  private String documentNumberT2;

  @TableField("TENANT_ID_T2")
  private String tenantIdT2;

  @TableField("ORGANIZATION_ID_T2")
  private String organizationIdT2;

  @TableField("ORGANIZATION_DEPT_ID_T2")
  private BigDecimal organizationDeptIdT2;

  @TableField("PREPARED_USER_T2")
  private BigDecimal preparedUserT2;

  @TableField("REQUEST_USER_ID_T2")
  private BigDecimal requestUserIdT2;

  @TableField("REQUEST_DATE_T2")
  private LocalDate requestDateT2;

  @TableField("REQUEST_PURPOSES_T2")
  private String requestPurposesT2;

  @TableField("ATTACHMENT_NUMBER_T2")
  private BigDecimal attachmentNumberT2;

  @TableField("WF_ITEM_TYPE_T2")
  private String wfItemTypeT2;

  @TableField("STATUS_CODE_T2")
  private String statusCodeT2;

  @TableField("ACTIVE_FLAG_T2")
  private BigDecimal activeFlagT2;

  @TableField("COMMENTS_T2")
  private String commentsT2;

  @TableField("PROCESS_MESSAGE_T2")
  private String processMessageT2;

  @TableField("VENDOR_ID_T2")
  private BigDecimal vendorIdT2;

  @TableField("VENDOR_SITE_ID_T2")
  private BigDecimal vendorSiteIdT2;

  @TableField("BANK_BRANCH_ID_T2")
  private BigDecimal bankBranchIdT2;

  @TableField("BANK_ACCOUNT_NUMBER_T2")
  private String bankAccountNumberT2;

  @TableField("FINANCE_STATUS_T2")
  private BigDecimal financeStatusT2;

  @TableField("FINANCIAL_DATE_T2")
  private LocalDate financialDateT2;

  @TableField("PAYMENT_STATUS_T2")
  private BigDecimal paymentStatusT2;

  @TableField("PLAN_PAYMENT_DATE_T2")
  private LocalDate planPaymentDateT2;

  @TableField("PAYMENT_DATE_T2")
  private LocalDate paymentDateT2;

  @TableField("ACCOUNT_TYPE_T2")
  private String accountTypeT2;

  @TableField("ACCOUNT_STATUS_T2")
  private BigDecimal accountStatusT2;

  @TableField("ACCOUNT_DATE_T2")
  private LocalDate accountDateT2;

  @TableField("CREATE_DATE_T2")
  private LocalDate createDateT2;

  @TableField("CREATE_USER_T2")
  private BigDecimal createUserT2;

  @TableField("MODIFIED_DATE_T2")
  private LocalDate modifiedDateT2;

  @TableField("MODIFIED_USER_T2")
  private BigDecimal modifiedUserT2;

  @TableField("IP_T2")
  private String ipT2;

  @TableField("PRE_SUBMIT_T2")
  private BigDecimal preSubmitT2;

  @TableField("OCCUPIED_AMOUNT_T2")
  private BigDecimal occupiedAmountT2;

  @TableField("SWFT_T2")
  private String swftT2;

  @TableField("BANK_BRANCH_CODE_T2")
  private String bankBranchCodeT2;

  @TableField("PAYMENT_METHOD_T2")
  private String paymentMethodT2;

  @TableField("PREPAYMENT_FLAG_T2")
  private BigDecimal prepaymentFlagT2;

  @TableField("RATE_TYPE_T2")
  private String rateTypeT2;

  @TableField("RATE_DATE_T2")
  private LocalDate rateDateT2;

  @TableField("RATE_T2")
  private BigDecimal rateT2;

  @TableField("STARD_CURRENCY_T2")
  private String stardCurrencyT2;

  @TableField("STARD_TAX_IN_AMOUNT_T2")
  private BigDecimal stardTaxInAmountT2;

  @TableField("STARD_TAX_FREE_AMOUNT_T2")
  private BigDecimal stardTaxFreeAmountT2;

  @TableField("STARD_TAX_AMOUNT_T2")
  private BigDecimal stardTaxAmountT2;

  @TableField("ORIGL_CURRENCY_T2")
  private String origlCurrencyT2;

  @TableField("ORIGL_TAX_IN_AMOUNT_T2")
  private BigDecimal origlTaxInAmountT2;

  @TableField("ORIGL_TAX_FREE_AMOUNT_T2")
  private BigDecimal origlTaxFreeAmountT2;

  @TableField("ORIGL_TAX_AMOUNT_T2")
  private BigDecimal origlTaxAmountT2;

  @TableField("PAYMENT_TYPE_T2")
  private String paymentTypeT2;

  @TableField("CASH_FLOW_T2")
  private String cashFlowT2;

  @TableField("PAYMENT_PERIOD_T2")
  private String paymentPeriodT2;

  @TableField("BANK_ACCOUNT_TYPE_T2")
  private String bankAccountTypeT2;

  @TableField("BANK_ACCOUNT_ID_T2")
  private BigDecimal bankAccountIdT2;

  @TableField("PAYMENT_TOTAL_AMOUNT_T2")
  private BigDecimal paymentTotalAmountT2;

  @TableField("AP_INVOICE_AUTO_T2")
  private BigDecimal apInvoiceAutoT2;

  @TableField("AP_REQUEST_HEADER_ID_T2")
  private BigDecimal apRequestHeaderIdT2;

  @TableField("VENDOR_NAME")
  private String vendorName;

  @TableField("TENANT_NAME")
  private String tenantName;

  @TableField("ORGANIZATION_NAME")
  private String organizationName;

  @TableField("ORGANIZATION_DEPT_NAME")
  private String organizationDeptName;

  @TableField("REQUEST_USER_NAME")
  private String requestUserName;

  @TableField("AE_ROW_ID")
  private String aeRowId;

  @TableField("AE_STATUS")
  private String aeStatus;

  @TableField("SOURCE_BATCH_ID")
  private String sourceBatchId;

  @TableField("SOURCE_HEAD_ID")
  private String sourceHeadId;


}
