package com.deloitte.bdh.ae.controller;

import com.deloitte.bdh.ae.model.AeBatchSyncLog;
import com.deloitte.bdh.ae.service.AeBatchSyncLogService;
import com.deloitte.bdh.common.base.PageRequest;
import com.deloitte.bdh.common.base.PageResult;
import com.deloitte.bdh.common.base.RetResponse;
import com.deloitte.bdh.common.base.RetResult;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author dahpeng
 * @Description: AeBatchSyncLogController类
 * @date 2020/04/09 11:22
 */
@RestController
@RequestMapping("/aeBatchSyncLog")
@Api(tags = "同步数据日志接口")
public class AeBatchSyncLogController {

  @Autowired
  private AeBatchSyncLogService aeBatchSyncLogService;

  /**
   * @Description: 分页查询
   * @Reutrn RetResult<PageInfo < AeBatchSyncLog>>
   */
  @PostMapping("queryPage")
  @ApiOperation(value = "查看数据同步记录")
  public RetResult<PageResult<AeBatchSyncLog>> list(
      @RequestBody @Validated PageRequest<Void> pageRequest) {
    List<AeBatchSyncLog> list = aeBatchSyncLogService.selectList(pageRequest);
    PageInfo<AeBatchSyncLog> pageInfo = new PageInfo<AeBatchSyncLog>(list);
    PageResult pageResult = new PageResult(pageInfo);
    return RetResponse.makeOKRsp(pageResult);
  }

}