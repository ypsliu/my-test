package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "AeBatchSyncLog对象", description = "")
public class AeBatchSyncLog extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableId("LOG_ID")
  private String logId;

  @TableField("AE_BATCH_ID")
  private String aeBatchId;

  @TableField("FAIL_REASON")
  private String failReason;

  @TableField("START_TIME")
  private LocalDateTime startTime;

  @TableField("END_TIME")
  private LocalDateTime endTime;

  @TableField("USER_ID")
  private String userId;

  @TableField("ACTIVE_FLAG")
  private Integer activeFlag;

  @TableField("PERIOD")
  private String period;

  @TableField("PARAMS")
  private String params;

  @TableField("STATUS")
  private String status;

  @TableField(exist = false)
  @ApiModelProperty(value = "运行时间(单位:秒)")
  private Long usedTime;

  @TableField(exist = false)
  @ApiModelProperty(value = "系统CODE")
  private String source;

  @TableField(exist = false)
  @ApiModelProperty(value = "系统名称")
  private String sourceShow;

  @TableField(exist = false)
  @ApiModelProperty(value = "状态-显示值")
  private String statusShow;

  @TableField(exist = false)
  private String organizationId;

  @TableField(exist = false)
  @ApiModelProperty(value = "公司")
  private String organizationName;

  @TableField(exist = false)
  @ApiModelProperty(value = "操作人显示值")
  private String userName;
}
