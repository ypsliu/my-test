package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.AeSourceBatch;
import com.deloitte.bdh.ae.model.dto.ApplicationDto;
import com.deloitte.bdh.ae.model.dto.BatchDto;
import com.deloitte.bdh.ae.model.dto.BatchListGenerateDto;
import com.deloitte.bdh.ae.model.dto.BatchQueryDto;
import com.deloitte.bdh.ae.model.vo.UserVo;
import com.deloitte.bdh.common.base.PageRequest;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.Service;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface AeSourceBatchService extends Service<AeSourceBatch> {

  void generateData(RetRequest<BatchListGenerateDto> batchDtoRetRequest);

  List<AeSourceBatch> selectByPageRequest(PageRequest<BatchQueryDto> pageRequest);

  /**
   * 更新批次的状态 从 2号参数状态更新为 3参数状态
   */
  Boolean updateBatchStatus(String aeBatchId, String fromStatus, String toStatus);

  /**
   * 查询用户列表
   */
  List<UserVo> selectEntryUserList(RetRequest<ApplicationDto> retRequest);

  Boolean updateBatchEbsStatus(String aeBatchId, String entryType, String fromStatus,
      String toStatus);

  String selectAeBatchCode();

  /**
   * 删除批次信息
   * @param dto
   */
  void deleteData(BatchDto dto);
}
