package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "SourceApInvoiceHead对象", description = "")
public class SourceApInvoiceHead extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableField("REQUEST_HEADER_ID")
  private String requestHeaderId;

  @TableField("DOCUMENT_NUMBER")
  private String documentNumber;

  @TableField("TENANT_ID")
  private String tenantId;

  @TableField("ORGANIZATION_ID")
  private String organizationId;

  @TableField("ORGANIZATION_DEPT_ID")
  private String organizationDeptId;

  @TableField("PREPARED_USER")
  private BigDecimal preparedUser;

  @TableField("REQUEST_USER_ID")
  private String requestUserId;

  @TableField("REQUEST_DATE")
  private LocalDate requestDate;

  @TableField("REQUEST_PURPOSES")
  private String requestPurposes;

  @TableField("ATTACHMENT_NUMBER")
  private BigDecimal attachmentNumber;

  @TableField("WF_ITEM_TYPE")
  private String wfItemType;

  @TableField("STATUS_CODE")
  private String statusCode;

  @TableField("ACTIVE_FLAG")
  private BigDecimal activeFlag;

  @TableField("COMMENTS")
  private String comments;

  @TableField("PROCESS_MESSAGE")
  private String processMessage;

  @TableField("AP_TYPE")
  private String apType;

  @TableField("VENDOR_ID")
  private String vendorId;

  @TableField("VENDOR_BANK_NAME")
  private String vendorBankName;

  @TableField("VENDOR_BANK_ACCOUNT")
  private String vendorBankAccount;

  @TableField("RATE_TYPE")
  private String rateType;

  @TableField("RATE_DATE")
  private LocalDate rateDate;

  @TableField("RATE")
  private BigDecimal rate;

  @TableField("STARD_CURRENCY")
  private String stardCurrency;

  @TableField("STARD_TAX_IN_AMOUNT")
  private BigDecimal stardTaxInAmount;

  @TableField("STARD_TAX_FREE_AMOUNT")
  private BigDecimal stardTaxFreeAmount;

  @TableField("STARD_TAX_AMOUNT")
  private BigDecimal stardTaxAmount;

  @TableField("ORIGL_CURRENCY")
  private String origlCurrency;

  @TableField("ORIGL_TAX_IN_AMOUNT")
  private BigDecimal origlTaxInAmount;

  @TableField("ORIGL_TAX_FREE_AMOUNT")
  private BigDecimal origlTaxFreeAmount;

  @TableField("ORIGL_TAX_AMOUNT")
  private BigDecimal origlTaxAmount;

  @TableField("PAYMENT_TOTAL_AMOUNT")
  private BigDecimal paymentTotalAmount;

  @TableField("SYNCHRONOUS_PAYMENT")
  private BigDecimal synchronousPayment;

  @TableField("FINANCE_STATUS")
  private BigDecimal financeStatus;

  @TableField("FINANCIAL_DATE")
  private LocalDate financialDate;

  @TableField("ACCOUNT_TYPE")
  private String accountType;

  @TableField("ACCOUNT_STATUS")
  private BigDecimal accountStatus;

  @TableField("ACCOUNT_DATE")
  private LocalDate accountDate;

  @TableField("PRE_SUBMIT")
  private BigDecimal preSubmit;

  @TableField("PAY_PERIOD")
  private String payPeriod;

  @TableField("AE_ROW_ID")
  private String aeRowId;

  @TableField("AE_STATUS")
  private String aeStatus;

  @TableField("SOURCE_BATCH_ID")
  private String sourceBatchId;

  @TableField("SOURCE_HEAD_ID")
  private String sourceHeadId;

  @TableField("ORGANIZATIOIN_NAME")
  private String organizatioinName;

  @TableField("VENDOR_NAME")
  private String vendorName;


}
