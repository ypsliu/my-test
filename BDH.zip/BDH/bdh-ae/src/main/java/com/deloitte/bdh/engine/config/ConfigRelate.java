package com.deloitte.bdh.engine.config;

import com.deloitte.bdh.engine.config.entity.Config;

/**
 * 将多个配置项信息关联起来
 *
 * @author Ashen
 * @date 18/12/2019
 */
public interface ConfigRelate {

  /**
   * 关联配置项信息
   *
   * @param config
   */
  void configRelate(Config config);
}
