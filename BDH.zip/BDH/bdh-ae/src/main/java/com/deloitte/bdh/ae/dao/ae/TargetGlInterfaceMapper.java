package com.deloitte.bdh.ae.dao.ae;

import com.deloitte.bdh.ae.model.AeTarget;
import com.deloitte.bdh.ae.model.TargetGlInterface;
import com.deloitte.bdh.ae.model.dto.SourceQueryDto;
import com.deloitte.bdh.ae.model.io.ebsgl.P_PROCESS_DATA_DEL_ITEM;
import com.deloitte.bdh.ae.model.io.target.TargetDataHeadOutput;
import com.deloitte.bdh.ae.model.io.target.TargetDataLineOutput;
import com.deloitte.bdh.ae.model.io.target.TargetSegmentDetail;
import com.deloitte.bdh.ae.model.vo.DocumentVo;
import com.deloitte.bdh.ae.model.vo.TargetAccountVo;
import com.deloitte.bdh.common.base.Mapper;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface TargetGlInterfaceMapper extends Mapper<TargetGlInterface> {

  /**
   * 查询账务信息
   */
  List<TargetAccountVo> queryAccountingByParam(@Param("sourceBatchId") String sourceBatchId,
      @Param("sourceHeadId") String sourceHeadId,
      @Param("applicationCode") String applicationCode, @Param("lang") String lang);

  /**
   * 查询单据信息
   */
  List<DocumentVo> queryDocumentBySql(@Param("sql") String sql);

  /**
   * 导出账务信息
   */
  List<TargetAccountVo> exportAccountingByParam(@Param("batchList") List<String> batchList,
      @Param("type") String type, @Param("applicationCode") String applicationCode,
      @Param("lang") String lang);

  /**
   * 更新目标数据中EBS的总账信息
   *
   * @param aeBatchId
   * @param sourceHeadId
   * @param sourceLineId
   * @param aeRowId
   * @param aeEbsHeadId
   * @param aeEbsLineOrder
   * @param aeEbsNumber
   */
  void updateTarget(@Param("aeBatchId") String aeBatchId,
      @Param("sourceHeadId") String sourceHeadId, @Param("sourceLineId") String sourceLineId,
      @Param("aeRowId") String aeRowId, @Param("aeEbsHeadId") String aeEbsHeadId,
      @Param("aeEbsLineOrder") String aeEbsLineOrder, @Param("aeEbsNumber") String aeEbsNumber);

  /**
   * 查询单据的凭证头信息
   *
   * @param aeBatchId
   * @param sourceHeadId
   * @return
   */
  List<TargetDataHeadOutput> queryTargetHeadList(@Param("aeBatchId") String aeBatchId,
      @Param("sourceHeadId") String sourceHeadId);

  /**
   * 查询单据的凭证行信息
   *
   * @param aeBatchId
   * @param sourceHeadId
   * @return
   */
  List<TargetDataLineOutput> queryTargetLineList(@Param("aeBatchId") String aeBatchId,
      @Param("sourceHeadId") String sourceHeadId);

  /**
   * 删除批次的目标总账数据
   *
   * @param aeBatchId
   */
  void deleteTargetByBatchId(@Param("aeBatchId") String aeBatchId);

  /**
   * 查询单据行的目标段信息
   *
   * @param queryDtoList
   * @param aeTargetList
   * @return
   */
  List<TargetSegmentDetail> queryTargetSegmentList(
      @Param("queryDtoList") List<SourceQueryDto> queryDtoList,
      @Param("targetList") List<AeTarget> aeTargetList);

  List<P_PROCESS_DATA_DEL_ITEM> queryGlItem(@Param("aeBatchId") String aeBatchId);
}
