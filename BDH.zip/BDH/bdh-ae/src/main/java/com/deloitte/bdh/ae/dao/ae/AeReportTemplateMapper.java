package com.deloitte.bdh.ae.dao.ae;

import com.deloitte.bdh.ae.model.AeReportTemplate;
import com.deloitte.bdh.common.base.Mapper;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface AeReportTemplateMapper extends Mapper<AeReportTemplate> {

  List<AeReportTemplate> selectByApplicationAndOrganization(
      @Param("applicationId") String applicationId,
      @Param("organizationId") String organizationId,
      @Param("lang") String lang);
}
