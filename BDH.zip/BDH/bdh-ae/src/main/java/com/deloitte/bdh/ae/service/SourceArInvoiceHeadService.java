package com.deloitte.bdh.ae.service;

import com.deloitte.bdh.ae.model.SourceArInvoiceHead;
import com.deloitte.bdh.ae.model.io.DataOutput;
import com.deloitte.bdh.ae.model.io.OneDataInput;
import com.deloitte.bdh.ae.model.io.ar.ArDataInput;
import com.deloitte.bdh.ae.model.io.target.TargetDataOutput;
import com.deloitte.bdh.common.base.Service;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface SourceArInvoiceHeadService extends Service<SourceArInvoiceHead> {

  DataOutput putData(ArDataInput arDataInput);

  TargetDataOutput getTargetDate(OneDataInput oneDataInput);
}
