package com.deloitte.bdh.ae.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.deloitte.bdh.ae.dao.ae.SourceApInvoiceHeadMapper;
import com.deloitte.bdh.ae.model.AeSourceBatch;
import com.deloitte.bdh.ae.model.SourceApInvoiceHead;
import com.deloitte.bdh.ae.model.TargetApInterface;
import com.deloitte.bdh.ae.model.io.DataOutput;
import com.deloitte.bdh.ae.model.io.OneDataInput;
import com.deloitte.bdh.ae.model.io.ap.ApDataInput;
import com.deloitte.bdh.ae.model.io.ap.SourceApInvoiceHeadInput;
import com.deloitte.bdh.ae.model.io.ap.SourceApInvoiceLineInput;
import com.deloitte.bdh.ae.model.io.target.TargetDataOutput;
import com.deloitte.bdh.ae.properties.ApplicationCodeProperties;
import com.deloitte.bdh.ae.service.AeSourceBatchService;
import com.deloitte.bdh.ae.service.AeTenantMethodService;
import com.deloitte.bdh.ae.service.SourceApInvoiceHeadService;
import com.deloitte.bdh.ae.service.SourceApInvoiceLineService;
import com.deloitte.bdh.ae.service.TargetApInterfaceService;
import com.deloitte.bdh.common.base.ServiceTransactionalImpl;
import com.deloitte.bdh.common.constant.DSConstant;
import com.deloitte.bdh.common.exception.BizException;
import java.util.List;
import javax.annotation.Resource;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Service
@DS(DSConstant.AE_DB)
public class SourceApInvoiceHeadServiceImpl extends
    ServiceTransactionalImpl<SourceApInvoiceHeadMapper, SourceApInvoiceHead> implements
    SourceApInvoiceHeadService {

  @Resource
  private SourceApInvoiceHeadService sourceApInvoiceHeadService;

  @Resource
  private SourceApInvoiceLineService sourceApInvoiceLineService;

  @Resource
  private AeSourceBatchService aeSourceBatchService;

  @Resource
  private TargetApInterfaceService targetApInterfaceService;

  @Autowired
  private AeTenantMethodService aeTenantMethodService;

  @Autowired
  private ApplicationCodeProperties applicationCodeProperties;

  @Override
  @Transactional(rollbackFor = Exception.class)
  public DataOutput putData(ApDataInput apDataInput) {
    aeTenantMethodService
        .verifyTenantApplication(apDataInput.getTenantId(), apDataInput.getApplicationCode(),
            applicationCodeProperties.getApplicationCodeScmAp());
    DataOutput dataOutput = new DataOutput();
    if (apDataInput == null || apDataInput.getHeadList() == null
        || apDataInput.getHeadList().size() == 0) {
      throw new BizException("头信息不能为空");
    }
    if (apDataInput.getLineList() == null
        || apDataInput.getLineList().size() == 0) {
      throw new BizException("行信息不能为空");
    }
    String aeBatchCode = aeSourceBatchService.selectAeBatchCode();
    String aeBatchId = this.getSequence();
    insertHeadList(apDataInput.getHeadList(), aeBatchId);
    insertLineList(apDataInput.getLineList(), aeBatchId);

    AeSourceBatch aeSourceBatch = new AeSourceBatch();
    aeSourceBatch.setAeBatchId(aeBatchId);
    aeSourceBatch.setSourceBatchId(aeBatchId);
    aeSourceBatch.setActiveFlag(1);
    aeSourceBatch.setApplicationCode(apDataInput.getApplicationCode());
    aeSourceBatch.setTenantId(apDataInput.getTenantId());
    aeSourceBatch.setOrganizationId(apDataInput.getOrganizationId());
    aeSourceBatch.setAeBatchCode(aeBatchCode);
    aeSourceBatchService.save(aeSourceBatch);
    dataOutput.setAeBatchId(aeBatchId);
    dataOutput.setMessage("成功");
    dataOutput.setStatus("OK");
    return dataOutput;
  }

  private void insertHeadList(List<SourceApInvoiceHeadInput> headList, String aeBatchId) {
    headList.forEach(sourceApInvoiceHeadInput -> {
      sourceApInvoiceHeadInput.setSourceBatchId(aeBatchId);
      if (Strings.isEmpty(sourceApInvoiceHeadInput.getSourceHeadId())) {
        throw new BizException("来源头ID不能为空");
      }
      sourceApInvoiceHeadService.save(sourceApInvoiceHeadInput);
    });

  }

  private void insertLineList(List<SourceApInvoiceLineInput> lineList, String aeBatchId) {
    lineList.forEach(sourceApInvoiceLineInput -> {
      sourceApInvoiceLineInput.setSourceBatchId(aeBatchId);
      if (Strings.isEmpty(sourceApInvoiceLineInput.getSourceHeadId())) {
        throw new BizException("来源头ID不能为空");
      }
      if (Strings.isEmpty(sourceApInvoiceLineInput.getSourceLineId())) {
        throw new BizException("来源行ID不能为空");
      }
      sourceApInvoiceLineService.save(sourceApInvoiceLineInput);
    });
  }

  @Override
  public TargetDataOutput getTargetDate(OneDataInput oneDataInput) {
    TargetDataOutput targetDataOutput = new TargetDataOutput();
    AeSourceBatch aeSourceBatch = aeSourceBatchService.getById(oneDataInput.getAeBatchId());
    if (aeSourceBatch == null) {
      throw new BizException("查询批次信息失败！");
    }
    if (!"OK".equals(aeSourceBatch.getEbsStatus())) {
      throw new BizException("目标数据还在生成中...");
    }
    //查询该批次该头ID的目标数据量
    Integer targetCount = targetApInterfaceService.count(new LambdaQueryWrapper<TargetApInterface>()
        .eq(TargetApInterface::getAeBatchId, oneDataInput.getAeBatchId())
        .eq(TargetApInterface::getSourceHeadId, oneDataInput.getSourceHeadId()));
    if (targetCount == null || targetCount == 0) {
      throw new BizException("没查询到生成的目标数据");
    }
    targetDataOutput.setStatus("OK");
    return targetDataOutput;
  }
}
