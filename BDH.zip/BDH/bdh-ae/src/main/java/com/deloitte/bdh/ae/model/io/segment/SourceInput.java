package com.deloitte.bdh.ae.model.io.segment;

import java.util.List;
import lombok.Data;

/**
 * @author Ashen
 * @date 24/04/2020
 */
@Data
public class SourceInput {

  private List<SourceDetail> list;

}
