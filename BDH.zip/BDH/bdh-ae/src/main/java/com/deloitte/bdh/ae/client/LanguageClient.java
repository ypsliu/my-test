package com.deloitte.bdh.ae.client;

import com.deloitte.bdh.ae.client.model.FndPortalLanguage;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.RetResult;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * @author Ashen
 * @date 17/12/2020
 */
@FeignClient(value = "bdh-platform", contextId = "language-client")
@Component
public interface LanguageClient {

  /**
   * 获取公司列表
   *
   * @param retRequest
   * @return
   */
  @PostMapping("/platform/fndPortalLanguages/languageList")
  RetResult<List<FndPortalLanguage>> getLanguageList(RetRequest<Void> retRequest);
}
