package com.deloitte.bdh.ae.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.deloitte.bdh.common.base.BaseModel;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(value = "CuxGlCoaList对象", description = "")
public class CuxGlCoaList extends BaseModel {

  private static final long serialVersionUID = 1L;

  @TableField("LEDGER_ID")
  private BigDecimal ledgerId;

  @TableField("LEDGERS_NAME")
  private String ledgersName;

  @TableField("SEGMENT_NUM")
  private Integer segmentNum;

  @TableField("FLEX_VALUE_SET_ID")
  private BigDecimal flexValueSetId;

  @TableField("FLEX_VALUE_SET_NAME")
  private String flexValueSetName;

  @TableField("FLEX_VALUE")
  private String flexValue;

  @TableField("DESCRIPTION")
  private String description;

  @TableField("DESC_EN")
  private String descEn;

  @TableField("SUMMARY_FLAG")
  private String summaryFlag;

  @TableField("ENABLED_FLAG")
  private String enabledFlag;

  @TableField("START_DATE_ACTIVE")
  private LocalDate startDateActive;

  @TableField("END_DATE_ACTIVE")
  private LocalDate endDateActive;

  @TableField("LAST_UPDATE_DATE")
  private LocalDate lastUpdateDate;

  @TableField("COMPANY_CODE")
  private String companyCode;


}
