package com.deloitte.bdh.ae.model.io.ebsapwriteoff;

import com.alibaba.fastjson.annotation.JSONField;
import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

/**
 * @author Ashen
 * @date 14/07/2020
 */
@Data
public class P_APPLY_PREPAY_TBL_ITEM {

  @JSONField(name = "ORG_NAME", ordinal = 1)
  private String ORG_NAME;

  @JSONField(name = "INVOICE_NUM", ordinal = 2)
  private String INVOICE_NUM;

  @JSONField(name = "VENDOR_NAME", ordinal = 3)
  private String VENDOR_NAME;

  @JSONField(name = "PREPAY_NUM", ordinal = 4)
  private String PREPAY_NUM;

  @JSONField(name = "APPLY_DATE", format = "yyyy-MM-dd", ordinal = 5)
  private Date APPLY_DATE;

  @JSONField(name = "APPLY_AMT", ordinal = 6)
  private BigDecimal APPLY_AMT;
}
