package com.deloitte.bdh.ae.model.io.apwriteoff;

import com.deloitte.bdh.ae.model.SourceApInvoiceWoHead;

/**
 * @author Ashen
 * @date 20/04/2020
 */
public class SourceApInvoiceWriteOffHeadInput extends SourceApInvoiceWoHead {

}
