package com.deloitte.bdh.ae.model.io.expense;

import com.deloitte.bdh.ae.model.SourceExpenseLine;

public class ExpExpenseCommonLinesInput extends SourceExpenseLine {


}