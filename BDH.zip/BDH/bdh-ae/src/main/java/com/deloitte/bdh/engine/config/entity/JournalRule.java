package com.deloitte.bdh.engine.config.entity;

import java.util.List;
import lombok.Data;

/**
 * 日记账推导规则
 *
 * @author Ashen
 * @date 02/12/2019
 */
@Data
public class JournalRule {

  private String ruleId;

  private String ruleCode;

  private String ruleName;

  private String returnType;

  private String returnCode;

  private List<JournalRuleLine> journalRuleLineList;

  private JournalRuleField journalRuleField;
}
