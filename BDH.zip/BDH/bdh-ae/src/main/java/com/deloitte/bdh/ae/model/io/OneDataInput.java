package com.deloitte.bdh.ae.model.io;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Ashen
 * @date 03/03/2020
 */
@Data
@ApiModel(description = "入口参数")
public class OneDataInput {

  @ApiModelProperty(value = "会计引擎批次信息")
  private String aeBatchId;

  @ApiModelProperty(value = "头ID")
  private String sourceHeadId;
}
