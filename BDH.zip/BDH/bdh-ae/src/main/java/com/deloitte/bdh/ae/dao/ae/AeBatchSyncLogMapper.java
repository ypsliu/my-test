package com.deloitte.bdh.ae.dao.ae;

import com.deloitte.bdh.ae.model.AeBatchSyncLog;
import com.deloitte.bdh.common.base.Mapper;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author Ashen
 * @since 2021-02-01
 */
public interface AeBatchSyncLogMapper extends Mapper<AeBatchSyncLog> {

  List<AeBatchSyncLog> selectListByOrganizationList(
      @Param("organizationIdList") List<String> organizationIdList);
}
