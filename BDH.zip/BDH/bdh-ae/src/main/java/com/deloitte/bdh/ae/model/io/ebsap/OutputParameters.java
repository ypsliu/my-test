package com.deloitte.bdh.ae.model.io.ebsap;

import lombok.Data;

/**
 * @author Ashen
 * @date 22/04/2020
 */
@Data
public class OutputParameters {

  private String X_RETURN_STATUS;
  private String X_MSG_DATA;

}
