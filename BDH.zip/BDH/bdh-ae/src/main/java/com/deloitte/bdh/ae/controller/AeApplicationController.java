package com.deloitte.bdh.ae.controller;

import com.deloitte.bdh.ae.model.AeApplication;
import com.deloitte.bdh.ae.service.AeApplicationService;
import com.deloitte.bdh.common.base.RetRequest;
import com.deloitte.bdh.common.base.RetResponse;
import com.deloitte.bdh.common.base.RetResult;
import com.deloitte.bdh.common.context.ThreadContextHolder;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author dahpeng
 * @Description: AeApplicationController类
 * @date 2019/11/26 14:15
 */
@RestController
@RequestMapping("/aeApplication")
@Api(tags = "应用产品接口")
public class AeApplicationController {

  @Autowired
  private AeApplicationService aeApplicationService;

  @PostMapping("/queryList")
  @ApiOperation(value = "查看产品列表")
  public RetResult<Object> generateData(
      @RequestBody @Validated RetRequest<Void> retRequest) {

    List<AeApplication> list = aeApplicationService
        .selectByTenantId(ThreadContextHolder.getTenantId());
    return RetResponse.makeOKRsp(list);
  }

}